/* ===== v12 · Character builder · Quick bar ===== */
(function(){
'use strict';
const T=R,isAr=()=>lang=='ar',tr=(en,ar)=>isAr()?ar:en;
const log=(m,ty)=>{try{window.MapStudioV9.log(m,ty)}catch(e){}};
const guard=(n,fn)=>{try{fn()}catch(e){log('v12 '+n+': '+(e&&e.message||e),'e')}};
const hx=h=>parseInt(String(h).replace('#',''),16)||0;
const ls={g(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
guard('character',()=>{
 const D={name:'Hero',gender:'girl',skin:'#f1c9a5',hair:'#3a2418',style:'long',shirt:'#ff8fb8',pants:'#4a5a9a',shoes:'#ffffff',face:'smile',build:'normal',h:1,acc:'none',accc:'#ffd24a'};
 const C=Object.assign({},D,ls.g('ms12:chr',{}));
 const OPT={gender:[['girl','👧','بنت','Girl'],['boy','👦','ولد','Boy']],
  style:[['short','✂️','قصير','Short'],['long','💇','طويل','Long'],['bun','🎀','كعكة','Bun'],['none','🥚','بدون','None']],
  face:[['smile','🙂','ابتسامة','Smile'],['happy','😄','سعيد','Happy'],['cool','😎','هادئ','Cool'],['sleepy','😴','نعسان','Sleepy']],
  build:[['slim','🧍','نحيف','Slim'],['normal','🙂','عادي','Normal'],['strong','💪','قوي','Strong']],
  acc:[['none','—','بدون','None'],['hat','🎩','قبعة','Hat'],['glasses','👓','نظارة','Glasses'],['wings','🪽','أجنحة','Wings'],['crown','👑','تاج','Crown']]};
 const COLS={skin:['#fde0c8','#f1c9a5','#d9a27a','#a8744f','#6b4430'],hair:['#1b1b1b','#3a2418','#8a5a2b','#e8c26a','#ff7aa8','#7a5cff'],shirt:['#ff8fb8','#ffffff','#e63946','#2e86de','#2ecc71','#f1c40f'],pants:['#4a5a9a','#222','#7a5a3a','#ffffff','#8e44ad'],shoes:['#ffffff','#222','#e63946','#8a5a2b']};
 const LB={skin:['Skin','البشرة'],hair:['Hair color','لون الشعر'],shirt:['Shirt','القميص'],pants:['Pants','البنطال'],shoes:['Shoes','الحذاء']};
 const TT={gender:['Gender','الجنس'],style:['Hair style','تسريحة الشعر'],face:['Face','الوجه'],build:['Body','الجسم'],acc:['Accessory','إكسسوار']};
 const pn=document.createElement('div');pn.id='chr';pn.className='pn';$('pane').appendChild(pn);
 const bt=document.createElement('button');bt.dataset.d='chr';$('tabs').appendChild(bt);
 function openTab(id){const b=document.querySelector('#tabs [data-d="'+id+'"]');if(!b)return;if(!b.classList.contains('on'))b.click();else $('dock').classList.remove('min')}
 bt.onclick=()=>{const was=bt.classList.contains('on');document.querySelectorAll('#tabs button').forEach(x=>x.classList.toggle('on',x==bt));document.querySelectorAll('.pn').forEach(x=>x.classList.toggle('on',x.id=='chr'));$('dock').classList.toggle('min',was&&!$('dock').classList.contains('min'));if(!was)render()};
 function render(){bt.textContent='🧍 '+tr('Character','الشخصية');
  const ch=k=>`<div class="nt">${tr(TT[k][0],TT[k][1])}</div><div class="chips">${OPT[k].map(o=>`<button data-o="${k}:${o[0]}" class="${C[k]==o[0]?'on':''}">${o[1]} ${isAr()?o[2]:o[3]}</button>`).join('')}</div>`;
  const cl=k=>`<div class="nt">${tr(LB[k][0],LB[k][1])}</div><div class="chips">${COLS[k].map(c=>`<button data-c="${k}:${c}" style="background:${c};width:34px;height:34px;padding:0;border:3px solid ${C[k]==c?'#fff':'#0006'}"></button>`).join('')}<input type="color" data-cc="${k}" value="${C[k]}" style="width:40px;height:34px;padding:0;border:0"></div>`;
  pn.innerHTML=`<div class="tbs"><input data-n value="${C.name}" placeholder="${tr('Character name','اسم الشخصية')}"></div>`+ch('gender')+cl('skin')+ch('style')+cl('hair')+ch('face')+cl('shirt')+cl('pants')+cl('shoes')+ch('build')+ch('acc')+
  `<div class="r"><label>${tr('Height','الطول')}</label><div class="v"><input type="range" data-h min=".6" max="1.6" step=".05" value="${C.h}"><output>${C.h}</output></div></div>
<div class="rw2"><button data-go class="on2">✔ ${tr('Place in map','ضعها في الماب')}</button><button data-new>➕ ${tr('Keep & new','احتفظ وأنشئ أخرى')}</button><button data-rnd>🎲</button></div>`}
 const pick=a=>a[Math.floor(Math.random()*a.length)];
 function parts(){const g=C.gender=='girl',w={slim:.8,normal:1,strong:1.25}[C.build],P=[];const add=(t,n,p,s,c,m)=>P.push({t,n,p,s,c,m:m||'SmoothPlastic'});
  const lg=1.6,tz=2.2*(g?.95:1);const cx=C.skin,sw=2*w;
  add('block','LeftLeg',[-.5*w,lg/2,0],[.95*w,lg,.95],C.pants);add('block','RightLeg',[.5*w,lg/2,0],[.95*w,lg,.95],C.pants);
  add('block','LeftShoe',[-.5*w,.2,.1],[1*w,.4,1.1],C.shoes);add('block','RightShoe',[.5*w,.2,.1],[1*w,.4,1.1],C.shoes);
  add('block','Torso',[0,lg+tz/2,0],[sw,tz,1],C.shirt);
  if(g)add('block','Skirt',[0,lg+.15,0],[sw*1.25,.6,1.25],C.pants);
  add('block','LeftArm',[-(sw/2+.5),lg+tz-.9,0],[.9,1.7,.9],C.skin);add('block','RightArm',[sw/2+.5,lg+tz-.9,0],[.9,1.7,.9],C.skin);
  const hy=lg+tz+1.05;add('ball','Head',[0,hy,0],[1.9,1.9,1.9],C.skin);
  const e=C.face=='sleepy'?[.28,.07,.1]:C.face=='happy'?[.2,.28,.1]:C.face=='cool'?[.34,.12,.1]:[.2,.2,.1];
  add('ball','LeftEye',[-.38,hy+.12,.88],e,'#222222');add('ball','RightEye',[.38,hy+.12,.88],e,'#222222');
  add('block','Mouth',[0,hy-.42,.9],C.face=='cool'?[.35,.06,.08]:[.5,.1,.08],C.face=='happy'?'#c0392b':'#7a2e2e');
  if(g)['L','R'].forEach((s,i)=>add('ball','Cheek'+s,[(i?1:-1)*.62,hy-.2,.8],[.28,.16,.1],'#ff9aa8'));
  const H=C.hair;if(C.style!='none'){add('ball','HairTop',[0,hy+.45,-.1],[2.1,1.5,2.1],H);
   if(C.style=='long'){add('block','HairBack',[0,hy-.9,-.75],[2.1,3,.7],H);}
   if(C.style=='bun')add('ball','HairBun',[0,hy+1.25,-.2],[.9,.9,.9],H);
   if(C.style=='short')add('block','Fringe',[0,hy+.55,.75],[1.7,.4,.5],H);}
  if(C.acc=='hat')add('cyl','Hat',[0,hy+1.15,0],[1.5,.9,1.5],C.accc);
  if(C.acc=='crown')add('cyl','Crown',[0,hy+1.1,0],[1.4,.5,1.4],'#ffd24a','Neon');
  if(C.acc=='glasses')add('block','Glasses',[0,hy+.15,.92],[1.4,.35,.1],'#111111');
  if(C.acc=='wings'){add('wedge','WingL',[-1.6,lg+tz-.2,-.7],[.2,2.2,1.6],'#ffffff','Neon');add('wedge','WingR',[1.6,lg+tz-.2,-.7],[.2,2.2,1.6],'#ffffff','Neon')}
  return P}
 let cur=[];
 const rm=m=>{sc.remove(m);const i=items.indexOf(m);if(i>=0)items.splice(i,1);sels.delete(m)};
 function place(){cur.forEach(rm);cur=[];const k=C.h,ox=cur.ox!=null?cur.ox:Math.round(tg.x),oz=Math.round(tg.z);let gy=0;try{gy=groundY(ox,oz)}catch(e){}
  const nm='Character_'+(C.name||'Hero').replace(/\s+/g,'');
  parts().forEach(p=>{cur.push(mk(p.t,{p:[ox+p.p[0]*k,gy+p.p[1]*k,oz+p.p[2]*k],r:[0,0,0],s:p.s.map(v=>v*k),n:nm+'_'+p.n,c:hx(p.c),m:p.m,co:false}))});cur.ox=ox;save();ls.s('ms12:chr',C)}
 pn.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;
  if(t.dataset.o){const[k,v]=t.dataset.o.split(':');C[k]=v;if(cur.length)place();render()}
  else if(t.dataset.c){const[k,v]=t.dataset.c.split(':');C[k]=v;if(cur.length)place();render()}
  else if('go' in t.dataset){place();toast(tr('Character placed','تم وضع الشخصية'))}
  else if('new' in t.dataset){cur=[];toast(tr('Saved. Build another','تم الحفظ، ابني شخصية جديدة'))}
  else if('rnd' in t.dataset){C.skin=pick(COLS.skin);C.hair=pick(COLS.hair);C.shirt=pick(COLS.shirt);C.pants=pick(COLS.pants);C.style=pick(OPT.style)[0];C.face=pick(OPT.face)[0];C.acc=pick(OPT.acc)[0];if(cur.length)place();render()}});
 pn.addEventListener('input',e=>{const t=e.target;if(t.dataset.cc){C[t.dataset.cc]=t.value;if(cur.length)place()}else if('h' in t.dataset){C.h=parseFloat(t.value);t.nextElementSibling.textContent=C.h;if(cur.length)place()}else if('n' in t.dataset){C.name=t.value}});
 window.MapStudioV12={openTab};
});

/* Quick bar: Maps · Play · Toolbox · Character */
guard('quickbar',()=>{
 const st=document.createElement('style');st.textContent='#qb{position:absolute;top:8px;left:8px;z-index:9;display:flex;gap:6px;flex-wrap:wrap;max-width:70%}#qb button{background:#000a;color:#fff;border:1px solid #fff4;border-radius:18px;padding:7px 12px;font-size:13px}body.playing #qb{display:none}';document.head.appendChild(st);
 const q=document.createElement('div');q.id='qb';$('vp').appendChild(q);
 const B=[['🏠','Maps','خرائطي',()=>showHome()],['▶','Play','تجربة',()=>$('playb')&&$('playb').click()],['🧰','Toolbox','الأدوات',()=>window.MapStudioV12.openTab('box')],['🧍','Character','الشخصية',()=>window.MapStudioV12.openTab('chr')]];
 function r(){q.innerHTML='';B.forEach(b=>{const e=document.createElement('button');e.textContent=b[0]+' '+tr(b[1],b[2]);e.onclick=()=>guard(b[1],b[3]);q.appendChild(e)})}
 r();$('lang').addEventListener('click',()=>setTimeout(r,60));
});
})();
