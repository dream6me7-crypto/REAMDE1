/* ===== v15 · Avatar Editor (Roblox-style catalog, 3D preview, animations) ===== */
(function(){
'use strict';
const isAr=()=>lang=='ar',tr=(en,ar)=>isAr()?ar:en;
const log=(m,ty)=>{try{window.MapStudioV9.log(m,ty)}catch(e){}};
const ls={g(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const hx=h=>parseInt(String(h).replace('#',''),16)||0;
const P={body:'M10 3a3 3 0 100 6 3 3 0 000-6zM4 17c0-4 2.5-6 6-6s6 2 6 6',skin:'M10 3a7 7 0 100 14 7 7 0 000-14zM10 3v14',face:'M10 3a7 7 0 100 14 7 7 0 000-14zM7 8v1M13 8v1M7 12c1 2 5 2 6 0',hair:'M4 11a6 6 0 0112 0v6H4zM4 11h12',shirt:'M7 3L3 6l2 3 2-1v9h6V8l2 1 2-3-4-3-3 2z',pants:'M6 3h8l1 14h-4l-1-8-1 8H5z',shoes:'M3 12h6l2 2h6v3H3z',hat:'M4 13a6 6 0 0112 0M2 13h16v3H2z',back:'M6 4h8v12H6zM8 8h4M6 10H4v5h2M14 10h2v5h-2',anim:'M3 15h14M5 15V9M10 15V5M15 15v-4M3 4l3 2 4-3 4 3 3-2',out:'M4 4h12v13H4zM8 4V2h4v2M7 9h6M7 12h4',x:'M5 5l10 10M15 5L5 15',save:'M4 3h10l3 3v11H4zM7 3v5h6V3M7 17v-5h6v5',place:'M10 17s-6-5-6-9a6 6 0 0112 0c0 4-6 9-6 9zM10 6a2 2 0 100 4 2 2 0 000-4z',dice:'M4 4h12v12H4zM8 8h.01M12 12h.01M12 8h.01M8 12h.01'};
const ic=(n,s)=>'<svg viewBox="0 0 20 20" width="'+(s||20)+'" height="'+(s||20)+'" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="'+(P[n]||P.body)+'"/></svg>';

/* ---------- catalog ---------- */
const CAT={
 body:[['classic','Classic','كلاسيك'],['slim','Slim','نحيف'],['stocky','Stocky','قوي'],['tall','Tall','طويل'],['kid','Kid','طفل'],['girl','Girl','بنت']],
 face:[['smile','Smile','ابتسامة'],['happy','Happy','سعيد'],['cool','Cool','هادئ'],['sleepy','Sleepy','نعسان'],['wink','Wink','غمزة'],['shock','Surprised','مندهش']],
 hair:[['none','None','بدون'],['short','Short','قصير'],['long','Long','طويل'],['bun','Bun','كعكة'],['twin','Twin tails','ضفيرتان'],['bob','Bob','بوب'],['spiky','Spiky','مدبب']],
 shirt:[['tee','T-Shirt','تيشيرت'],['long','Long sleeve','كم طويل'],['stripes','Stripes','خطوط'],['hoodie','Hoodie','هودي'],['jacket','Jacket','جاكيت'],['kimono','Kimono','كيمونو'],['dress','Dress','فستان']],
 pants:[['jeans','Jeans','جينز'],['shorts','Shorts','شورت'],['skirt','Skirt','تنورة'],['cargo','Cargo','كارغو'],['none','Bare legs','بدون']],
 hat:[['none','None','بدون'],['cap','Cap','كاب'],['beanie','Beanie','قبعة صوف'],['top','Top hat','قبعة عالية'],['crown','Crown','تاج'],['cat','Cat ears','أذن قطة'],['bunny','Bunny ears','أذن أرنب'],['halo','Halo','هالة'],['flower','Flower','زهرة']],
 back:[['none','None','بدون'],['wings','Wings','أجنحة'],['pack','Backpack','حقيبة'],['cape','Cape','عباءة']],
 anim:[['idle','Idle','وقوف'],['walk','Walk','مشي'],['run','Run','ركض'],['dance','Dance','رقص'],['wave','Wave','تحية'],['jump','Jump','قفز'],['sit','Sit','جلوس'],['cheer','Cheer','احتفال']]};
const COLS={skin:['#fde0c8','#f1c9a5','#d9a27a','#a8744f','#6b4430','#ffe9d6'],hair:['#1b1b1b','#3a2418','#8a5a2b','#e8c26a','#ff7aa8','#7a5cff','#f2f2f2'],shirt:['#ff8fb8','#ffffff','#e63946','#2e86de','#2ecc71','#f1c40f','#222222'],accent:['#ffffff','#222222','#ffd24a','#e63946','#2e86de','#ff8fb8'],pants:['#4a5a9a','#222222','#7a5a3a','#ffffff','#8e44ad','#2f6f4f'],shoes:['#ffffff','#222222','#e63946','#8a5a2b'],hatc:['#e63946','#222222','#ffd24a','#2e86de','#ffffff','#ff8fb8']};
const TABS=[['body','Body','الجسم',[]],['skin','Skin','البشرة',['skin']],['face','Face','الوجه',[]],['hair','Hair','الشعر',['hair']],['shirt','Shirts','القمصان',['shirt','accent']],['pants','Pants','البناطيل',['pants']],['shoes','Shoes','الأحذية',['shoes']],['hat','Hats','القبعات',['hatc']],['back','Back','الظهر',[]],['anim','Animations','الحركات',[]],['outs','Outfits','أطقمي',[]]];
const LB={skin:['Skin tone','لون البشرة'],hair:['Hair color','لون الشعر'],shirt:['Shirt color','لون القميص'],accent:['Accent','اللون الثاني'],pants:['Pants color','لون البنطال'],shoes:['Shoe color','لون الحذاء'],hatc:['Hat color','لون القبعة']};
const KEY={skin:'skin',hair:'hair',shirt:'shirt',accent:'accent',pants:'pants',shoes:'shoes',hatc:'hatc'};
const DEF={name:'Hero',body:'classic',skin:'#f1c9a5',face:'smile',hair:'short',hairc:'#3a2418',shirt:'tee',shirtc:'#2e86de',accent:'#ffffff',pants:'jeans',pantsc:'#4a5a9a',shoes:'#ffffff',hat:'none',hatc:'#e63946',back:'none',anim:'idle'};
let C=Object.assign({},DEF,ls.g('ms15:av',{}));
const COLKEY={skin:'skin',hair:'hairc',shirt:'shirtc',accent:'accent',pants:'pantsc',shoes:'shoes',hatc:'hatc'};

/* ---------- avatar spec: pure function ---------- */
function build(c){
 const B={classic:[1,1,1,1],slim:[.82,1,1,1],stocky:[1.25,1,1,1],tall:[1,1.25,1,1],kid:[1,.72,1.3,1],girl:[.85,1,1,1.0]}[c.body]||[1,1,1,1];
 const w=B[0],H=B[1],hs=B[2],lg=2*H,tz=2*H,sw=2*w,al=1.9*H,S=[];
 const add=(n,t,p,s,col,m,limb,r)=>S.push({n,t,p,s,c:col,m:m||'SmoothPlastic',limb:limb||'b',r:r||[0,0,0]});
 const skin=c.skin,sh=c.shirtc,ac=c.accent,pc=c.pantsc,rad=d=>d*Math.PI/180;
 const longPants=c.pants=='jeans'||c.pants=='cargo',shorts=c.pants=='shorts';
 // legs
 [['LeftLeg',-1,'ll'],['RightLeg',1,'rl']].forEach(a=>{const x=a[1]*.5*w;
  if(longPants)add(a[0],'block',[x,lg/2,0],[w*.98,lg,1],pc,0,a[2]);
  else if(shorts){add(a[0]+'Upper','block',[x,lg*.75,0],[w*.98,lg*.5,1.02],pc,0,a[2]);add(a[0]+'Lower','block',[x,lg*.25,0],[w*.9,lg*.5,.95],skin,0,a[2])}
  else add(a[0],'block',[x,lg/2,0],[w*.9,lg,.95],skin,0,a[2]);
  add(a[0].replace('Leg','Shoe'),'block',[x,.2,.08],[w*1.02,.4,1.1],c.shoes,0,a[2]);
  if(c.pants=='cargo')add(a[0]+'Pocket','block',[x+a[1]*w*.5,lg*.45,.3],[.12,.6,.5],'#3d3d3d',0,a[2])});
 if(c.pants=='skirt'||c.shirt=='dress')add('Skirt','block',[0,lg+.1,0],[sw*1.3,.9,1.35],c.shirt=='dress'?sh:pc,0,'b');
 // torso
 add('Torso','block',[0,lg+tz/2,0],[sw,tz,1],sh);
 if(c.shirt=='stripes')[.25,.55,.85,1.15,1.45].forEach((y,i)=>{if(i%2==0)add('Stripe'+i,'block',[0,lg+y*H*.9,0],[sw*1.02,.22*H,1.02],ac)});
 if(c.shirt=='hoodie'){add('HoodPocket','block',[0,lg+.6*H,.52],[sw*.6,.55*H,.08],ac);add('Hood','ball',[0,lg+tz+.1,-.45],[1.3*w,.9,.9],sh)}
 if(c.shirt=='jacket'){add('Zip','block',[0,lg+tz/2,.52],[.08,tz,.06],ac);add('Collar','block',[0,lg+tz-.05,0],[sw*.9,.25,1.1],ac)}
 if(c.shirt=='kimono'){add('Obi','block',[0,lg+tz*.45,0],[sw*1.06,.65*H,1.06],ac);add('KimonoFront','block',[0,lg+tz*.7,.52],[.1,tz*.6,.06],ac)}
 // arms
 const full=c.shirt!='tee'&&c.shirt!='dress';const ay=lg+tz-.15;
 [['LeftArm',-1,'la'],['RightArm',1,'ra']].forEach(a=>{const x=a[1]*(sw/2+w/2);
  if(full){add(a[0],'block',[x,ay-al*.42,0],[w*.98,al*.84,.98],sh,0,a[2]);add(a[0].replace('Arm','Hand'),'block',[x,ay-al*.92,0],[w*.9,al*.16,.9],skin,0,a[2])}
  else{add(a[0]+'Sleeve','block',[x,ay-al*.2,0],[w*.98,al*.4,.98],sh,0,a[2]);add(a[0],'block',[x,ay-al*.7,0],[w*.9,al*.6,.9],skin,0,a[2])}});
 // head + face
 const hd=1.5*hs,hy=lg+tz+hd*.5+.05,r=hd/2;
 add('Head','ball',[0,hy,0],[hd,hd,hd],skin,0,'hd');
 const e={smile:[.2,.22],happy:[.22,.3],cool:[.3,.12],sleepy:[.26,.06],wink:[.2,.22],shock:[.26,.32]}[c.face]||[.2,.22];
 const ez=r*.88;add('LeftEye','ball',[-r*.38,hy+r*.12,ez],[e[0]*hs,e[1]*hs,.1],'#222222',0,'hd');
 add('RightEye','ball',[r*.38,hy+r*.12,ez],[e[0]*hs,c.face=='wink'?.05:e[1]*hs,.1],'#222222',0,'hd');
 add('Mouth','block',[0,hy-r*.42,r*.9],c.face=='shock'?[.22*hs,.26*hs,.08]:c.face=='cool'?[.3*hs,.06,.08]:[.5*hs,.1,.08],c.face=='happy'||c.face=='shock'?'#c0392b':'#7a2e2e',0,'hd');
 if(c.body=='girl')['L','R'].forEach((s,i)=>add('Cheek'+s,'ball',[(i?1:-1)*r*.62,hy-r*.18,r*.82],[.26,.15,.1],'#ff9aa8',0,'hd'));
 // hair
 const hc=c.hairc,hr=r*1.07;
 if(c.hair!='none'){add('HairTop','ball',[0,hy+r*.25,-r*.12],[hd*1.1,hd*.9,hd*1.1],hc,0,'hd');
  if(c.hair=='long')add('HairBack','block',[0,hy-r*.9,-r*.8],[hd*1.05,hd*1.6,.6],hc,0,'hd');
  if(c.hair=='bob')add('HairBob','block',[0,hy-r*.3,-r*.8],[hd*1.1,hd*.9,.6],hc,0,'hd');
  if(c.hair=='bun')add('HairBun','ball',[0,hy+r*1.05,-r*.2],[.8,.8,.8],hc,0,'hd');
  if(c.hair=='twin')['L','R'].forEach((s,i)=>add('Tail'+s,'block',[(i?1:-1)*(r+.2),hy-r*.7,-.2],[.45,1.6,.45],hc,0,'hd'));
  if(c.hair=='short')add('Fringe','block',[0,hy+r*.5,r*.78],[hd*.85,.3,.4],hc,0,'hd');
  if(c.hair=='spiky')[-1,0,1].forEach((k,i)=>add('Spike'+i,'block',[k*r*.6,hy+r*1.05,0],[.28,.7,.28],hc,0,'hd',[0,0,rad(-k*18)]))}
 // hats
 const hcol=c.hatc,top=hy+r;
 if(c.hat=='cap'){add('CapTop','ball',[0,top-.1,0],[hd*1.08,hd*.7,hd*1.08],hcol,0,'hd');add('CapBrim','block',[0,top-.4,r*.85],[hd*.9,.1,.7],hcol,0,'hd')}
 if(c.hat=='beanie'){add('Beanie','ball',[0,top-.15,0],[hd*1.1,hd*.85,hd*1.1],hcol,0,'hd');add('Pom','ball',[0,top+.45,0],[.4,.4,.4],'#ffffff',0,'hd')}
 if(c.hat=='top'){add('TopBrim','cyl',[0,top-.05,0],[hd*1.2,.1,hd*1.2],'#222222',0,'hd');add('TopHat','cyl',[0,top+.5,0],[hd*.8,1,hd*.8],'#222222',0,'hd')}
 if(c.hat=='crown')add('Crown','cyl',[0,top+.1,0],[hd*.85,.5,hd*.85],'#ffd24a','Neon','hd');
 if(c.hat=='cat')[-1,1].forEach((k,i)=>add('Ear'+i,'block',[k*r*.62,top+.15,0],[.4,.55,.15],hcol,0,'hd',[0,0,rad(-k*12)]));
 if(c.hat=='bunny')[-1,1].forEach((k,i)=>add('Bunny'+i,'block',[k*r*.4,top+.7,0],[.3,1.3,.15],hcol,0,'hd',[0,0,rad(-k*8)]));
 if(c.hat=='halo')add('Halo','cyl',[0,top+.65,0],[hd*.95,.06,hd*.95],'#ffe27a','Neon','hd');
 if(c.hat=='flower'){add('FlowerC','ball',[r*.55,top-.1,r*.3],[.3,.3,.3],'#ffd24a',0,'hd');[0,1,2,3,4].forEach(i=>add('Petal'+i,'ball',[r*.55+Math.cos(i*1.256)*.28,top-.1+Math.sin(i*1.256)*.28,r*.3],[.26,.26,.2],hcol,0,'hd'))}
 // back
 const by=lg+tz*.55;
 if(c.back=='wings')[-1,1].forEach((k,i)=>add('Wing'+i,'block',[k*1.5,by+.4,-.7],[.15,2.2,1.3],'#ffffff','Neon','b',[0,rad(k*20),rad(k*22)]));
 if(c.back=='pack')add('Backpack','block',[0,by,-.9],[sw*.8,tz*.75,.7],c.accent=='#ffffff'?'#8a5a2b':c.accent,0,'b');
 if(c.back=='cape')add('Cape','block',[0,by-.3,-.62],[sw*.95,tz*1.3,.12],'#e63946',0,'b',[rad(4),0,0]);
 return {parts:S,piv:{la:[-(sw/2+w/2),ay,0],ra:[sw/2+w/2,ay,0],ll:[-.5*w,lg,0],rl:[.5*w,lg,0],hd:[0,lg+tz,0],b:[0,0,0]},height:hy+r+1};
}
window.MapStudioAvatar={build};

/* ---------- UI ---------- */
function start(){
 if(typeof THREE=='undefined')return;
 const st=document.createElement('style');st.textContent=`
#av{position:fixed;inset:0;z-index:200;background:var(--bg);display:none;flex-direction:column;color:var(--t)}
#av.on{display:flex}
#av .hd{display:flex;align-items:center;justify-content:space-between;padding:calc(8px + env(safe-area-inset-top,0px)) 12px 6px;background:var(--p)}
#av .hd b{font-size:15px}
#av .hd button{background:transparent;border:0;color:var(--t);padding:4px}
#avp{flex:0 0 42%;position:relative;background:linear-gradient(#9fc4e8,#e9f1f8);touch-action:none}
#avp canvas{position:absolute;inset:0;width:100%;height:100%}
#avn{position:absolute;left:10px;top:8px;background:#0007;color:#fff;border-radius:10px;padding:4px 10px;font-size:12px}
#avt{display:flex;overflow-x:auto;background:var(--p2);border-bottom:1px solid var(--b);flex:0 0 auto}
#avt button{flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:2px;padding:8px 12px;font-size:11px;background:transparent;color:var(--t);border:0;border-bottom:2px solid transparent}
#avt button.on{border-bottom-color:var(--ac);background:var(--p)}
#avb{flex:1;overflow-y:auto;padding:8px;background:var(--p)}
#avb .ttl{font-size:11px;opacity:.65;margin:8px 2px 4px}
#avb .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
#avb .card{background:var(--p2);border:2px solid var(--b);border-radius:10px;padding:10px 4px;font-size:12px;text-align:center;color:var(--t);display:flex;flex-direction:column;align-items:center;gap:4px}
#avb .card.on{border-color:var(--ac);background:#0b6cbc33}
#avb .card small{font-size:10px;opacity:.7}
#avb .sw{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
#avb .sw button{width:36px;height:36px;border-radius:50%;padding:0}
#avb .sw input[type=color]{width:40px;height:36px;padding:0;border:0;background:transparent}
#avb input.nm{width:100%;box-sizing:border-box;background:var(--in);color:var(--t);border:1px solid var(--b);border-radius:8px;padding:9px;font-size:15px}
#avf{display:flex;gap:6px;padding:8px 10px calc(8px + env(safe-area-inset-bottom,0px));background:var(--p);border-top:1px solid var(--b)}
#avf button{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;background:var(--p2);color:var(--t);border:1px solid var(--b);border-radius:10px;padding:11px 4px;font-size:13px}
#avf button.pri{background:var(--ac);border-color:var(--ac);color:#fff}`;
 document.head.appendChild(st);
 const ov=document.createElement('div');ov.id='av';document.body.appendChild(ov);
 ov.innerHTML='<div class="hd"><b id="avh"></b><button id="avx"></button></div><div id="avp"><canvas></canvas><div id="avn"></div></div><div id="avt"></div><div id="avb"></div><div id="avf"></div>';
 const q=s=>ov.querySelector(s);
 q('#avx').innerHTML=ic('x',24);
 let tab='body',rd,sc3,cam,grp,piv={},t0=performance.now(),run=false,yaw=.5,drag=null;
 function init3(){const cv=q('#avp canvas');rd=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});rd.setPixelRatio(Math.min(2,window.devicePixelRatio||1));
  sc3=new THREE.Scene();cam=new THREE.PerspectiveCamera(35,1,.1,200);
  sc3.add(new THREE.AmbientLight(0xffffff,.75));const dl=new THREE.DirectionalLight(0xffffff,.8);dl.position.set(5,10,8);sc3.add(dl);
  const fl=new THREE.Mesh(new THREE.CylinderGeometry(3.2,3.2,.2,40),new THREE.MeshStandardMaterial({color:0xffffff,transparent:true,opacity:.6}));fl.position.y=-.1;sc3.add(fl);
  const pp=q('#avp');pp.addEventListener('pointerdown',e=>{drag=e.clientX});window.addEventListener('pointerup',()=>{drag=null});
  pp.addEventListener('pointermove',e=>{if(drag!=null){yaw+=(e.clientX-drag)*.01;drag=e.clientX}})}
 function size(){const p=q('#avp'),w=p.clientWidth,h=p.clientHeight;if(!w||!h)return;rd.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix()}
 function geo(t){return t=='ball'?new THREE.SphereGeometry(.5,18,14):t=='cyl'?new THREE.CylinderGeometry(.5,.5,1,20):new THREE.BoxGeometry(1,1,1)}
 function rebuild(){if(!sc3)return;if(grp)sc3.remove(grp);grp=new THREE.Group();piv={};const sp=build(C);
  Object.keys(sp.piv).forEach(k=>{const g=new THREE.Group();g.position.fromArray(sp.piv[k]);grp.add(g);piv[k]=g});
  sp.parts.forEach(p=>{const m=new THREE.Mesh(geo(p.t),new THREE.MeshStandardMaterial({color:hx(p.c),roughness:p.m=='Neon'?.2:.7,emissive:p.m=='Neon'?new THREE.Color(hx(p.c)):0x000000,emissiveIntensity:p.m=='Neon'?.5:0}));
   const pv=sp.piv[p.limb]||[0,0,0];m.position.set(p.p[0]-pv[0],p.p[1]-pv[1],p.p[2]-pv[2]);m.scale.set(p.s[0],p.s[1],p.s[2]);m.rotation.set(p.r[0],p.r[1],p.r[2]);piv[p.limb].add(m)});
  // head & arm pivots sit inside body pivot space already (all pivots children of grp)
  sc3.add(grp);const h=sp.height;cam.position.set(0,h*.55,h*2.1);cam.lookAt(0,h*.5,0);q('#avn').textContent=C.name}
 function pose(t){if(!grp)return;const a=piv;const s=Math.sin,A=C.anim;
  Object.values(a).forEach(g=>{g.rotation.set(0,0,0)});grp.position.set(0,0,0);grp.rotation.y=yaw+(A=='dance'?s(t*3)*.4:0);
  if(A=='idle'){a.la.rotation.x=s(t*1.5)*.05;a.ra.rotation.x=-s(t*1.5)*.05;grp.position.y=s(t*1.5)*.02}
  else if(A=='walk'||A=='run'){const f=A=='run'?9:5.5,m=A=='run'?1:.65;a.ll.rotation.x=s(t*f)*m;a.rl.rotation.x=-s(t*f)*m;a.la.rotation.x=-s(t*f)*m;a.ra.rotation.x=s(t*f)*m;grp.position.y=Math.abs(s(t*f))*(A=='run'?.18:.08)}
  else if(A=='dance'){a.la.rotation.z=-2.4+s(t*6)*.5;a.ra.rotation.z=2.4-s(t*6)*.5;a.ll.rotation.x=s(t*6)*.4;a.rl.rotation.x=-s(t*6)*.4;grp.position.y=Math.abs(s(t*6))*.25;a.hd.rotation.z=s(t*3)*.15}
  else if(A=='wave'){a.ra.rotation.z=2.6;a.ra.rotation.x=0;a.ra.rotation.y=0;a.ra.rotation.z=2.5+s(t*8)*.25;a.la.rotation.x=s(t*1.5)*.04}
  else if(A=='jump'){const j=Math.abs(s(t*3));grp.position.y=j*1.4;a.la.rotation.z=-2+j*.2;a.ra.rotation.z=2-j*.2;a.ll.rotation.x=-j*.5;a.rl.rotation.x=j*.5}
  else if(A=='sit'){grp.position.y=-.9;a.ll.rotation.x=-1.5;a.rl.rotation.x=-1.5;a.la.rotation.x=-.5;a.ra.rotation.x=-.5}
  else if(A=='cheer'){const j=Math.abs(s(t*5));a.la.rotation.z=-2.7;a.ra.rotation.z=2.7;a.la.rotation.x=s(t*5)*.2;a.ra.rotation.x=-s(t*5)*.2;grp.position.y=j*.3}}
 function loop(){if(!run)return;requestAnimationFrame(loop);size();pose((performance.now()-t0)/1000);rd.render(sc3,cam)}
 const card=(on,label,sub,att,iconName)=>`<button class="card${on?' on':''}" ${att}>${ic(iconName,26)}<span>${label}</span><small>${sub}</small></button>`;
 const swatches=k=>{const ck=COLKEY[k];return `<div class="ttl">${tr(LB[k][0],LB[k][1])}</div><div class="sw">${COLS[k].map(c=>`<button data-sw="${ck}:${c}" style="background:${c};border:3px solid ${C[ck].toLowerCase()==c.toLowerCase()?'#fff':'#0008'}"></button>`).join('')}<input type="color" data-cc="${ck}" value="${C[ck]}"></div>`};
 function draw(){const T=TABS.find(x=>x[0]==tab);
  q('#avt').innerHTML=TABS.map(x=>`<button data-tab="${x[0]}" class="${x[0]==tab?'on':''}">${ic(x[0]=='outs'?'out':P[x[0]]?x[0]:'body',20)}<span>${tr(x[1],x[2])}</span></button>`).join('');
  let h='';
  if(tab=='shoes')h+=swatches('shoes');
  else if(tab=='skin')h+=swatches('skin');
  else if(tab=='outs'){const o=ls.g('ms15:outs',[]);h+=`<div class="ttl">${tr('Name','الاسم')}</div><input class="nm" data-name value="${C.name}">`+`<div class="ttl">${tr('Saved outfits','الأطقم المحفوظة')} (${o.length})</div><div class="grid">${o.map((x,i)=>card(false,x.name,tr('Wear','ارتدِ'),'data-wear="'+i+'"','out')).join('')||`<div class="ttl">${tr('Nothing saved yet. Use Save.','لا شيء محفوظ بعد. استخدمي حفظ.')}</div>`}</div>`+(o.length?`<div class="ttl"></div><div class="grid"><button class="card" data-delo>${tr('Delete last','حذف الأخير')}</button></div>`:'')}
  else{const key=tab=='hat'?'hat':tab=='anim'?'anim':tab;h+=`<div class="grid">${CAT[key].map(it=>card(C[key]==it[0],isAr()?it[2]:it[1],tr('Free','مجاني'),'data-it="'+key+':'+it[0]+'"',tab=='anim'?'anim':P[tab]?tab:'body')).join('')}</div>`;T[3].forEach(k=>{h+=swatches(k)})}
  q('#avb').innerHTML=h;
  q('#avh').textContent=tr('Avatar Editor','محرر الشخصية');
  q('#avf').innerHTML=`<button data-a="save">${ic('save')}${tr('Save','حفظ')}</button><button data-a="rnd">${ic('dice')}${tr('Random','عشوائي')}</button><button data-a="place" class="pri">${ic('place')}${tr('Place in map','ضعها في الماب')}</button>`}
 const pick=a=>a[Math.floor(Math.random()*a.length)];
 function place(){let ox=0,oz=0,gy=0;try{ox=Math.round(tg.x);oz=Math.round(tg.z)}catch(e){}try{gy=groundY(ox,oz)}catch(e){}
  const nm='Character_'+(C.name||'Hero').replace(/\s+/g,'');const sp=build(C);
  sp.parts.forEach(p=>mk(p.t=='cyl'?'cyl':p.t,{p:[ox+p.p[0],gy+p.p[1],oz+p.p[2]],r:p.r,s:p.s.slice(),n:nm+'_'+p.n,c:hx(p.c),m:p.m,co:false}));save();ls.s('ms15:av',C);toast(tr('Character placed','تم وضع الشخصية'));close()}
 ov.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;
  if(t.id=='avx')return close();
  if(t.dataset.tab){tab=t.dataset.tab;return draw()}
  if(t.dataset.it){const[k,v]=t.dataset.it.split(':');C[k]=v;ls.s('ms15:av',C);rebuild();return draw()}
  if(t.dataset.sw){const i=t.dataset.sw.indexOf(':');C[t.dataset.sw.slice(0,i)]=t.dataset.sw.slice(i+1);ls.s('ms15:av',C);rebuild();return draw()}
  if(t.dataset.wear!=null){C=Object.assign({},DEF,ls.g('ms15:outs',[])[+t.dataset.wear]);ls.s('ms15:av',C);rebuild();return draw()}
  if('delo' in t.dataset){const o=ls.g('ms15:outs',[]);o.pop();ls.s('ms15:outs',o);return draw()}
  const a=t.dataset.a;if(a=='save'){const o=ls.g('ms15:outs',[]);o.push(Object.assign({},C,{name:C.name||'Outfit'+(o.length+1)}));ls.s('ms15:outs',o);toast(tr('Outfit saved','تم حفظ الطقم'))}
  if(a=='rnd'){C.body=pick(CAT.body)[0];C.skin=pick(COLS.skin);C.face=pick(CAT.face)[0];C.hair=pick(CAT.hair)[0];C.hairc=pick(COLS.hair);C.shirt=pick(CAT.shirt)[0];C.shirtc=pick(COLS.shirt);C.pants=pick(CAT.pants)[0];C.pantsc=pick(COLS.pants);C.hat=pick(CAT.hat)[0];C.back=pick(CAT.back)[0];ls.s('ms15:av',C);rebuild();draw()}
  if(a=='place')place()});
 ov.addEventListener('input',e=>{const t=e.target;if(t.dataset.cc){C[t.dataset.cc]=t.value;ls.s('ms15:av',C);rebuild()}else if('name' in t.dataset){C.name=t.value;q('#avn').textContent=C.name;ls.s('ms15:av',C)}});
 function open(){if(!rd)init3();ov.classList.add('on');draw();rebuild();run=true;t0=performance.now();setTimeout(()=>{size();loop()},30)}
 function close(){ov.classList.remove('on');run=false}
 window.MapStudioAvatar.open=open;
 // route every Character entry to the editor
 const b=document.querySelector('#tabs [data-d="chr"]');if(b)b.onclick=open;
}
try{start()}catch(e){log('v15 avatar: '+(e&&e.message||e),'e')}

/* strip leftover emoji from UI text periodically */
try{const EM=/[\p{Extended_Pictographic}\u200d\ufe0f]/gu;
 setInterval(()=>{['nav','dock','sh'].forEach(i=>{const r=document.getElementById(i);if(!r)return;const w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT,{acceptNode:x=>x.parentElement&&x.parentElement.closest('#exp,#home')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let n;const L=[];while(n=w.nextNode()){EM.lastIndex=0;if(EM.test(n.nodeValue))L.push(n)}L.forEach(t=>{EM.lastIndex=0;t.nodeValue=t.nodeValue.replace(EM,'').replace(/^\s+/,'')})})},700)}catch(e){}
})();
