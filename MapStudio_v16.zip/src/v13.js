/* ===== v13 · Grouped top bar (portrait) ===== */
(function(){
'use strict';
const isAr=()=>lang=='ar',tr=(en,ar)=>isAr()?ar:en;
const log=(m,ty)=>{try{window.MapStudioV9.log(m,ty)}catch(e){}};
try{
 try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('portrait').catch(()=>{})}catch(e){}
 const st=document.createElement('style');st.textContent=`
#rib,#tabs,#qb{display:none!important}
#main{flex-direction:column!important}
#dock{width:auto!important;height:46%!important;border-left:0!important;border-top:1px solid var(--b)!important}
#dock.min{height:auto!important}
#nav{position:relative;flex:0 0 auto;background:var(--p);border-bottom:1px solid var(--b);z-index:40}
#nq{display:flex;gap:4px;padding:5px 6px 3px;align-items:center}
#nq .tb{flex:1 1 0;min-width:0;height:44px;border:1px solid var(--b);background:var(--p2);border-radius:10px}
#nq .tb small{font-size:9px}
#nq #playb{background:#2e9b4f!important;color:#fff;border-color:#2e9b4f!important}
#ng{display:grid;grid-template-columns:repeat(5,1fr);gap:4px;padding:3px 6px 6px}
#ng button{background:var(--p2);color:var(--t);border:1px solid var(--b);border-radius:10px;padding:7px 2px;font-size:12px;line-height:1.2}
#ng button b{display:block;height:22px}.ri{vertical-align:middle;display:block;margin:0 auto}#sh .go{display:flex;align-items:center;gap:6px}#sh .go .ri{margin:0}#dh .ri{display:inline-block;vertical-align:middle;margin-inline-end:6px}#nq .tb .ri{margin-bottom:1px}
#ng button.on{background:var(--ac);border-color:var(--ac);color:#fff}
#sh{display:none;position:absolute;left:0;right:0;top:100%;background:var(--p);border-bottom:2px solid var(--ac);box-shadow:0 10px 24px #0008;padding:8px;max-height:62vh;overflow-y:auto}
#sh.on{display:block}
#sh .ttl{font-size:11px;opacity:.65;margin:6px 2px 4px}
#sh .row{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
#sh .row .tb{min-width:58px;height:50px;border:1px solid var(--b);background:var(--p2);border-radius:10px}
#sh .row .tb.on{background:var(--ac);color:#fff;border-color:var(--ac)}
#sh .row .lb{background:var(--p2);border:1px solid var(--b);border-radius:10px;padding:5px 8px;display:flex;flex-direction:column;font-size:11px;gap:2px}
#sh .row select,#sh .row input[type=color]{font-size:14px;min-height:30px}
#sh .go{background:var(--p2);color:var(--t);border:1px solid var(--b);border-radius:10px;padding:10px 12px;font-size:14px}
#dh{display:flex;align-items:center;justify-content:space-between;padding:6px 10px;background:var(--p2);font-size:13px;flex:0 0 auto}
#dh button{background:transparent;color:var(--t);border:0;font-size:18px;padding:0 8px}
body.playing #nav{display:none}`;
 document.head.appendChild(st);

 const P={undo:'M7 5L3 9l4 4M3 9h8a5 5 0 010 10H8',redo:'M13 5l4 4-4 4M17 9H9a5 5 0 000 10h3',trash:'M4 6h12M8 6V4h4v2M6 6l1 11h6l1-11M9 9v5M11 9v5',dup:'M7 7h9v9H7zM4 13V4h9',play:'M6 4l10 6-10 6z',home:'M3 10l7-6 7 6M5 9v8h10V9M8 17v-5h4v5',add:'M10 4v12M4 10h12',edit:'M4 16l1-4 8-8 3 3-8 8zM12 5l3 3',world:'M10 3a7 7 0 100 14 7 7 0 000-14zM3 10h14M10 3c-3 3-3 11 0 14M10 3c3 3 3 11 0 14',game:'M4 7h12a2 2 0 012 2v4a2 2 0 01-2 2l-2-2H6l-2 2a2 2 0 01-2-2V9a2 2 0 012-2zM7 9v3M5.5 10.5h3M13 10h.01M15 11.5h.01',project:'M3 5h5l2 2h7v9H3z',tree:'M4 4h5M6 4v12M6 8h5M6 12h5M11 6v4M11 10v4',props:'M4 6h12M4 10h12M4 14h12M8 4v4M13 8v4M7 12v4',box:'M3 8h14v8H3zM7 8V5h6v3M3 12h14',sun:'M10 7a3 3 0 100 6 3 3 0 000-6zM10 2v2M10 16v2M2 10h2M16 10h2M4.5 4.5L6 6M14 14l1.5 1.5M4.5 15.5L6 14M14 6l1.5-1.5',sound:'M3 8h3l4-3v10l-4-3H3zM13 7a4 4 0 010 6M15 5a7 7 0 010 10',out:'M3 4h14v12H3zM6 8l3 2-3 2M11 13h3',mount:'M2 16l5-9 3 5 2-3 6 7z',waves:'M2 8c2-2 3 2 5 0s3 2 5 0 3 2 6 0M2 13c2-2 3 2 5 0s3 2 5 0 3 2 6 0',spark:'M10 3v4M10 13v4M3 10h4M13 10h4M5.5 5.5l2 2M12.5 12.5l2 2M14.5 5.5l-2 2M7.5 12.5l-2 2',code:'M7 6l-4 4 4 4M13 6l4 4-4 4M11 4l-2 12',ui:'M3 4h14v12H3zM3 8h14M5.5 6h.01M8 6h.01',anim:'M3 15h14M5 15V9M10 15V5M15 15v-4M3 4l3 2 4-3 4 3 3-2',person:'M10 3a3 3 0 100 6 3 3 0 000-6zM4 17c0-4 2.5-6 6-6s6 2 6 6',cube:'M10 2l7 4v8l-7 4-7-4V6zM3 6l7 4 7-4M10 10v8',assets:'M3 3h6v6H3zM11 3h6v6h-6zM3 11h6v6H3zM11 11h6v6h-6z',pub:'M10 14V4M6 8l4-4 4 4M4 16h12',select:'M5 3l10 7-5 1-2 5z',move:'M10 2v16M2 10h16M7 5l3-3 3 3M7 15l3 3 3-3M5 7l-3 3 3 3M15 7l3 3-3 3',scale:'M4 16V9M4 16h7M4 16L16 4M16 4h-5M16 4v5',rot:'M16 10a6 6 0 11-2-4.5M16 3v4h-4',part:'M4 4h12v12H4z',img:'M3 4h14v12H3zM3 14l4-4 3 3 3-4 4 5',ai:'M10 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z',anchor:'M10 3a2 2 0 100 4 2 2 0 000-4zM10 7v10M5 11a5 5 0 0010 0M7 10H5M15 10h-2',multi:'M3 3h8v8H3zM9 9h8v8H9z',ground:'M10 3v10M6 9l4 4 4-4M3 17h14',lang:'M10 3a7 7 0 100 14 7 7 0 000-14zM3 10h14M10 3c-3 3-3 11 0 14',clear:'M4 16l8-8M9 5l6 6-5 5-6-6z'};
 const ic=n=>'<svg class="ri" viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="'+(P[n]||P.part)+'"/></svg>';
 const setIc=(id,n)=>{const e=typeof id=='string'?$(id):id;if(!e)return;[...e.childNodes].forEach(x=>{if(x.nodeType==3)x.remove();else if(x.classList&&x.classList.contains('ri'))x.remove()});e.insertAdjacentHTML('afterbegin',ic(n))};
 [['un','undo'],['re','redo'],['del','trash'],['dup','dup'],['playb','play'],['mpb','home'],['addp','part'],['img','img'],['aib','ai'],['lub','code'],['anc','anchor'],['mu','multi'],['gnd','ground'],['ex','pub'],['clr','clear'],['lang','lang']].forEach(a=>setIc(a[0],a[1]));
 [['select','select'],['move','move'],['scale','scale'],['rot','rot']].forEach(a=>{const b=document.querySelector('[data-tool="'+a[0]+'"]');if(b)setIc(b,a[1])});
 const mc=$('mchip');if(mc&&mc.firstElementChild)mc.firstElementChild.innerHTML=ic('home');
 const dock=$('dock'),main=$('main');
 const nav=document.createElement('div');nav.id='nav';main.parentNode.insertBefore(nav,main);
 const nq=document.createElement('div');nq.id='nq';const ng=document.createElement('div');ng.id='ng';const sh=document.createElement('div');sh.id='sh';
 nav.append(nq,ng,sh);
 ['un','re','del','dup','playb','mpb'].forEach(i=>{const e=$(i);if(e)nq.appendChild(e)});
 const dh=document.createElement('div');dh.id='dh';dh.innerHTML='<span></span><button title="min">▾</button>';dock.insertBefore(dh,dock.firstChild);
 dh.querySelector('button').onclick=()=>{dock.classList.toggle('min');dh.querySelector('button').textContent=dock.classList.contains('min')?'▴':'▾'};
 const TN={exp:['Explorer','المستكشف'],props:['Properties','الخصائص'],box:['Toolbox','الأدوات'],light:['Lighting','الإضاءة'],snd:['Sound','الصوت'],outp:['Output','المخرجات'],ter:['Terrain','التضاريس'],ter2:['Terrain+','تضاريس+'],pem:['Particles','الجزيئات'],scr:['Scripts','السكربتات'],ui:['UI','الواجهات'],anm:['Animation','الحركات'],chr:['Character','الشخصية'],mdl:['Model','النمذجة'],ast:['Assets','الأصول'],pub:['Publish','النشر']};
 const IC={exp:'tree',props:'props',box:'box',light:'sun',snd:'sound',outp:'out',ter:'mount',ter2:'waves',pem:'spark',scr:'code',ui:'ui',anm:'anim',chr:'person',mdl:'cube',ast:'assets',pub:'pub'};
 function openTab(id){const b=document.querySelector('#tabs [data-d="'+id+'"]');if(!b)return;if(!b.classList.contains('on'))b.click();dock.classList.remove('min');dh.querySelector('button').textContent='▾';dh.firstChild.innerHTML=ic(IC[id])+tr(TN[id][0],TN[id][1]);closeSh()}
 const G=[['add','Add','إضافة'],['edit','Edit','تعديل'],['world','World','العالم'],['game','Game','اللعبة'],['project','Project','المشروع']];
 const TABS={0:['box','chr','pem'],1:['props','mdl','exp'],2:['ter','ter2','light','snd'],3:['scr','ui','anm','pem'],4:['ast','pub','outp']};
 TABS[3]=['scr','ui','anm','chr'];
 const mv=(row,ids)=>ids.forEach(i=>{const e=typeof i=='string'?$(i):i;if(e)row.appendChild(e)});
 const lbOf=i=>{const e=$(i);return e&&e.closest('.lb')||e};
 const secs=[]; // per group: [title en, ar, nodes[]]
 const mk=(t)=>{const d=document.createElement('div');d.className='row';return d};
 const hold=[[],[],[],[],[]];
 function tabBtns(g){const r=mk();TABS[g].forEach(id=>{if(!document.querySelector('#tabs [data-d="'+id+'"]'))return;const b=document.createElement('button');b.className='go';b.innerHTML=ic(IC[id])+'<span>'+tr(TN[id][0],TN[id][1])+'</span>';b.onclick=()=>openTab(id);r.appendChild(b)});return r}
 const rowAdd=mk(),rowTools=mk(),rowStyle=mk(),rowStep=mk(),rowSel=mk(),rowPrj=mk(),rowDev=mk();
 mv(rowAdd,['addp','shp','img','aib','lub']);
 mv(rowTools,[...document.querySelectorAll('[data-tool]')]);
 mv(rowStyle,[lbOf('col'),lbOf('mat'),'anc']);
 mv(rowStep,[lbOf('im'),lbOf('ir'),'mu','gnd']);
 mv(rowPrj,['ex','clr','lang']);
 const dv=$('dev');if(dv)mv(rowDev,[dv.closest('.g')||dv]);
 let open=-1;
 function closeSh(){sh.classList.remove('on');open=-1;[...ng.children].forEach(b=>b.classList.remove('on'))}
 function fill(g){sh.innerHTML='';const T=(en,ar)=>{const d=document.createElement('div');d.className='ttl';d.textContent=tr(en,ar);sh.appendChild(d)};
  if(g==0){T('Add','إضافة');sh.append(rowAdd);T('Open','فتح');sh.append(tabBtns(0))}
  if(g==1){T('Tools','الأدوات');sh.append(rowTools);T('Color · Material · Anchor','اللون · الخامة · التثبيت');sh.append(rowStyle);T('Steps · Dimensions','الخطوات والأبعاد');sh.append(rowStep);T('Open','فتح');sh.append(tabBtns(1))}
  if(g==2){T('World','العالم');sh.append(tabBtns(2))}
  if(g==3){T('Game','اللعبة');sh.append(tabBtns(3))}
  if(g==4){T('Project','المشروع');sh.append(rowPrj);if(dv){T('Device','الجهاز');sh.append(rowDev)}T('Open','فتح');sh.append(tabBtns(4))}}
 function labels(){ng.innerHTML='';G.forEach((g,i)=>{const b=document.createElement('button');b.innerHTML='<b>'+ic(g[0])+'</b>'+tr(g[1],g[2]);b.onclick=()=>{if(open==i){closeSh();return}closeSh();open=i;b.classList.add('on');fill(i);sh.classList.add('on')};ng.appendChild(b)});const cur=[...document.querySelectorAll('#tabs button')].find(x=>x.classList.contains('on'));if(cur&&TN[cur.dataset.d])dh.firstChild.innerHTML=ic(IC[cur.dataset.d])+tr(TN[cur.dataset.d][0],TN[cur.dataset.d][1])}
 labels();
 $('lang').addEventListener('click',()=>setTimeout(()=>{labels();if(open>=0){const o=open;closeSh();ng.children[o].click()}},80));
 // tapping the canvas closes the sheet
 $('vp').addEventListener('pointerdown',closeSh);
 window.MapStudioV12=Object.assign(window.MapStudioV12||{},{openTab});
 // keep tab title in sync
 document.querySelectorAll('#tabs button').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>{const id=b.dataset.d;if(TN[id])dh.firstChild.innerHTML=ic(IC[id])+tr(TN[id][0],TN[id][1])},0)));
 openTab('exp');
 // strip leftover emoji from UI text (not user data)
 const EM=/[\p{Extended_Pictographic}\u200d\ufe0f]/gu;
 const clean=r=>{const w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT,{acceptNode:x=>x.parentElement&&x.parentElement.closest('#exp,#home')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let n;const L=[];while(n=w.nextNode())if(EM.test(n.nodeValue)){EM.lastIndex=0;L.push(n)}EM.lastIndex=0;L.forEach(t=>{t.nodeValue=t.nodeValue.replace(EM,'').replace(/^\s+/,'')})};
 const roots=['nav','dock'].map(i=>$(i)).filter(Boolean),skip=e=>e.closest&&e.closest('#exp,#home');
 let tm=0;const mo=new MutationObserver(()=>{clearTimeout(tm);tm=setTimeout(()=>roots.forEach(r=>{mo.disconnect();clean(r);roots.forEach(x=>mo.observe(x,{childList:true,subtree:true,characterData:true}))}),50)});
 roots.forEach(r=>{clean(r);mo.observe(r,{childList:true,subtree:true,characterData:true})});
 [...document.querySelectorAll('.pn')].forEach(()=>0);

}catch(e){log('v13 nav: '+(e&&e.message||e),'e');try{console.error(e)}catch(_){}}
})();
