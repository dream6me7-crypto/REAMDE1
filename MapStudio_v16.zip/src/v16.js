/* ===== v16 · Show/hide top bar, bottom panel & move bar ===== */
(function(){
'use strict';
const isAr=()=>typeof lang!=='undefined'&&lang=='ar',tr=(en,ar)=>isAr()?ar:en;
try{
 const K='ms16:ui',ls={g(){try{return JSON.parse(localStorage.getItem(K))||{}}catch(e){return{}}},s(v){try{localStorage.setItem(K,JSON.stringify(v))}catch(e){}}};
 const S=Object.assign({nav:true,dock:true,fb:true},ls.g());
 const st=document.createElement('style');st.textContent=`
#nav{z-index:20!important}
body.h-nav #nav{display:none!important}
body.h-dock #dock{display:none!important}
body.h-fb #fb{display:none!important}
#vt{position:absolute;right:8px;top:50%;transform:translateY(-50%);z-index:7;display:flex;flex-direction:column;gap:8px}
#vt button{width:38px;height:38px;border-radius:50%;border:1px solid #fff5;background:#000a;color:#fff;font-size:16px;padding:0;opacity:.85}
#vt button.off{background:#fff3;opacity:.6}
body.playing #vt{display:none}`;
 document.head.appendChild(st);
 const vt=document.createElement('div');vt.id='vt';document.getElementById('vp').appendChild(vt);
 const B=[['nav','☰','Top bar','الشريط العلوي'],['dock','▤','Panels','اللوحات'],['fb','✥','Move bar','شريط التحريك']];
 function apply(){B.forEach(b=>document.body.classList.toggle('h-'+b[0],!S[b[0]]));
  [...vt.children].forEach((e,i)=>e.classList.toggle('off',!S[B[i][0]]));
  if(!S.nav){const sh=document.getElementById('sh');if(sh)sh.classList.remove('on')}}
 function labels(){[...vt.children].forEach((e,i)=>e.title=tr(B[i][2],B[i][3]))}
 B.forEach(b=>{const e=document.createElement('button');e.textContent=b[1];e.onclick=()=>{S[b[0]]=!S[b[0]];ls.s(S);apply();window.dispatchEvent(new Event('resize'))};vt.appendChild(e)});
 labels();apply();
 const lg=document.getElementById('lang');if(lg)lg.addEventListener('click',()=>setTimeout(labels,80));
}catch(e){try{window.MapStudioV9.log('v16: '+(e&&e.message||e),'e')}catch(_){}}
})();
