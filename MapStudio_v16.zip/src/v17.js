/* ===== v17 · Model library on the home page ===== */
(function(){
'use strict';
const isAr=()=>typeof lang!=='undefined'&&lang=='ar',tr=(a,b)=>isAr()?b:a;
try{
 const V=window.MapStudioV9;if(!V||!V.ML||typeof homeUI!='function')return;
 let hcat='all',busy=false;
 const st=document.createElement('style');st.textContent=`
.hm{max-width:1100px;margin:26px auto 0}
.hm .cr{display:flex;gap:6px;overflow-x:auto;margin:0 0 12px;padding-bottom:4px;scrollbar-width:none}
.hm .cr button{flex:0 0 auto;border:1px solid var(--b);background:var(--p);color:var(--t);border-radius:16px;padding:7px 13px;font-size:13px}
.hm .cr button.on{background:var(--ac);border-color:var(--ac);color:#fff}
.hm .gr{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:10px}
.hm .it{background:var(--p);border:1px solid var(--b);border-radius:12px;padding:6px;color:var(--t);display:flex;flex-direction:column;gap:5px;text-align:start;min-width:0}
.hm .it .im{aspect-ratio:1/1;background:#00000030;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden}
.hm .it img{width:100%;height:100%;object-fit:contain}
.hm .it img:not([src]){visibility:hidden}
.hm .it span{font-size:13px;line-height:1.25;color:#56a8f5;overflow:hidden;text-overflow:ellipsis}
.hm .it.add{border:2px dashed var(--ac);background:transparent;color:var(--ac);align-items:center;justify-content:center;font-weight:700;font-size:14px;min-height:120px;gap:6px}
.hm .it.add b{font-size:34px;line-height:1}
#hpk{position:fixed;inset:0;z-index:62;background:rgba(0,0,0,.6);display:none;align-items:flex-end;justify-content:center}
#hpk.on{display:flex}
#hpk .bx{background:var(--p);color:var(--t);border-radius:18px 18px 0 0;padding:16px 16px calc(16px + env(safe-area-inset-bottom,0px));width:100%;max-width:560px;max-height:80vh;overflow:auto;box-sizing:border-box}
#hpk .top{display:flex;gap:12px;align-items:center;margin-bottom:12px}
#hpk .top .im{width:72px;height:72px;border-radius:10px;background:#00000030;flex:0 0 auto}
#hpk .top img{width:100%;height:100%;object-fit:contain}
#hpk h3{margin:0;font-size:17px}
#hpk .ttl{font-size:12px;opacity:.7;margin:10px 2px 6px}
#hpk .mb{display:block;width:100%;text-align:start;background:var(--p2);color:var(--t);border:1px solid var(--b);border-radius:10px;padding:12px;margin-bottom:6px;font-size:14px}
#hpk .mb.cur{border-color:var(--ac)}
#hpk .mb.new{border-style:dashed;color:var(--ac)}`;
 document.head.appendChild(st);
 const catName=c=>c=='all'?tr('All','الكل'):(V.CATAR[c]&&isAr()?V.CATAR[c]:(V.CATS.find(x=>x[0]==c)||[0,c])[1]);
 const cats=['all','mine','packs','trees','jp','lights','props','nature'];
 const nm=m=>isAr()?m.ar:m.en;
 const esc2=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 function items(){return V.ML.filter(m=>hcat=='all'||m.cat==hcat)}
 function html(){const l=items();
  return `<div class="hm" id="hm"><div class="sc">${tr('Model library','مكتبة النماذج')} <span>${l.length}</span></div>
<div class="cr">${cats.map(c=>`<button data-hcat="${c}" class="${hcat==c?'on':''}">${esc2(catName(c))}</button>`).join('')}</div>
<div class="gr"><button class="it add" data-hadd><b>+</b>${tr('Add model','إضافة نموذج')}</button>${l.map(m=>`<button class="it" data-hm="${esc2(m.id)}"><div class="im"><img data-th="${esc2(m.id)}" alt=""></div><span>${esc2(nm(m))}</span></button>`).join('')}</div></div>`}
 function fill(){const root=document.getElementById('hm');if(!root||busy)return;const imgs=[...root.querySelectorAll('img[data-th]')];if(!imgs.length)return;busy=true;
  (function step(){imgs.splice(0,3).forEach(im=>{const m=V.ML.find(x=>x.id==im.dataset.th);if(!m||!im.isConnected)return;const u=V.thumbOf(m);if(u){im.src=u;im.removeAttribute('data-th')}});if(imgs.length)requestAnimationFrame(step);else busy=false})()}
 function sect(){const hb=document.querySelector('#home .hb');if(!hb)return;const old=document.getElementById('hm');if(old)old.remove();hb.insertAdjacentHTML('beforeend',html());
  const hr=document.querySelector('#home .hr');if(hr&&!hr.querySelector('[data-hgo]')){const b=document.createElement('button');b.className='hl';b.dataset.hgo='1';b.textContent='▦ '+tr('Models','النماذج');hr.appendChild(b)}
  fill()}
 const orig=window.homeUI;window.homeUI=function(){const r=orig.apply(this,arguments);try{sect()}catch(e){}return r};
 async function pick(id){const m=V.ML.find(x=>x.id==id);if(!m)return;let d=document.getElementById('hpk');if(!d){d=document.createElement('div');d.id='hpk';document.body.appendChild(d)}
  d.dir=isAr()?'rtl':'ltr';const th=V.thumbOf(m),ls=[...MP.list].sort((a,b)=>(b.id==MP.cur)-(a.id==MP.cur)||(b.updated||0)-(a.updated||0));
  d.innerHTML=`<div class="bx"><div class="top"><div class="im">${th?`<img src="${th}" alt="">`:''}</div><div><h3>${esc2(nm(m))}</h3><div style="opacity:.7;font-size:13px">${tr('Choose where to add it','اختر أين تضيفه')}</div></div></div>
<div class="ttl">${tr('Add to map','أضف إلى خريطة')}</div>${ls.map(x=>`<button class="mb${x.id==MP.cur?' cur':''}" data-pm="${esc2(x.id)}">${esc2(x.name)}${x.id==MP.cur?' · '+tr('Current','الحالية'):''}</button>`).join('')}
<button class="mb new" data-pn>＋ ${tr('New map with this model','خريطة جديدة بهذا النموذج')}</button><button class="mb" data-px>${tr('Cancel','إلغاء')}</button></div>`;
  d.classList.add('on');
  d.onclick=async e=>{const b=e.target.closest('button');if(e.target==d||(b&&b.dataset.px!=null)){d.classList.remove('on');return}if(!b)return;
   if(b.dataset.pm){d.classList.remove('on');openMap(b.dataset.pm);setTimeout(()=>V.placeModel(id),160)}
   else if(b.dataset.pn!=null){d.classList.remove('on');const v=await dlg({title:L('New map'),msg:L('Give your map a name'),input:L('Map')+' '+(MP.list.length+1),ok:L('Create')});if(!v)return;const nid=uid(),n=Date.now();MP.list.push({id:nid,name:v,created:n,updated:n,count:2});openMap(nid);setTimeout(()=>V.placeModel(id),160)}}}
 document.getElementById('home').addEventListener('click',e=>{const t=e.target;let b;
  if(b=t.closest('[data-hcat]')){hcat=b.dataset.hcat;sect()}
  else if(t.closest('[data-hadd]'))V.openAddModel();
  else if(b=t.closest('[data-hm]'))pick(b.dataset.hm);
  else if(t.closest('[data-hgo]')){const h=document.getElementById('hm');if(h)h.scrollIntoView({behavior:'smooth',block:'start'})}});
 if(document.getElementById('home').classList.contains('on'))sect();
}catch(e){try{window.MapStudioV9.log('v17: '+(e&&e.message||e),'e')}catch(_){}}
})();
