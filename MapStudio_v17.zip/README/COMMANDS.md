# الأوامر التي تحتاجها (Codespaces)

## تحديث التطبيق بنسخة جديدة
استبدلي `MapStudio_v17.zip` باسم الملف الجديد في كل مرة:

```bash
cd /workspaces/REAMDE1 && git checkout -- . && git pull
unzip -o MapStudio_v17.zip -d app/src/main/assets/ && rm MapStudio_v17.zip
bash build.sh
grep -c 'screenOrientation="portrait"' app/src/main/AndroidManifest.xml
```

## ملاحظات
- التطبيق يفتح الملف `Map_Studio.html` فقط داخل `app/src/main/assets/`؛ لذلك يجب أن يحمل الملف الرئيسي في الـzip هذا الاسم.
- نتيجة `grep -c` المتوقعة: `1` أو أكثر (يعني أن الاتجاه العمودي مفعّل في AndroidManifest).
- الملفات داخل `src/` للمرجع فقط؛ التطبيق يعمل من `Map_Studio.html` وحده.
- تحتاج أول مرة إلى إنترنت لتحميل three.js من cdnjs.
