/* ===== v17 · Model library on the home page ===== */
(function(){
'use strict';
const isAr=()=>typeof lang!=='undefined'&&lang=='ar',tr=(a,b)=>isAr()?b:a;
try{
 window.MapStudioVersion='17';
 const V=window.MapStudioV9;if(!V||!V.lib||typeof homeUI!='function')return;
 let q='',busy=false;
 const st=document.createElement('style');st.textContent=`
.mlb{max-width:1100px;margin:28px auto 0}
.mlb-h{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
.mlb-t{font-size:18px;font-weight:700;display:flex;align-items:center;gap:8px}
.mlb-t em{font-style:normal;font-size:12px;font-weight:700;background:var(--ac);color:#fff;border-radius:10px;padding:2px 8px}
.mlb-add{display:flex;align-items:center;gap:6px;background:var(--ac);color:#fff;border:0;border-radius:12px;padding:10px 14px;font-size:14px;font-weight:600}
.mlb-s{display:flex;align-items:center;gap:8px;background:var(--p);border:1px solid var(--b);border-radius:12px;padding:0 12px;margin-bottom:14px;color:var(--t)}
.mlb-s input{flex:1;min-width:0;background:transparent;border:0;color:var(--t);font-size:15px;padding:12px 0;outline:0}
.mlb-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:12px}
.mlb-c{background:var(--p);border:1px solid var(--b);border-radius:16px;padding:8px 8px 10px;color:var(--t);display:flex;flex-direction:column;gap:2px;text-align:start;min-width:0;transition:transform .12s}
.mlb-c:active{transform:scale(.97)}
.mlb-i{aspect-ratio:1/1;border-radius:12px;background:linear-gradient(160deg,#ffffff10,#00000040);display:flex;align-items:center;justify-content:center;overflow:hidden;margin-bottom:8px}
.mlb-i img{width:100%;height:100%;object-fit:contain}
.mlb-i img:not([src]){visibility:hidden}
.mlb-c b{font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 2px}
.mlb-c small{font-size:12px;opacity:.6;padding:0 2px}
.mlb-e{text-align:center;padding:38px 16px;background:var(--p);border:1px dashed var(--b);border-radius:18px}
.mlb-e svg{opacity:.55;margin-bottom:10px}
.mlb-e b{display:block;font-size:17px;margin-bottom:6px}
.mlb-e p{margin:0 0 16px;font-size:13.5px;opacity:.7;line-height:1.6}
.mlb-e button{background:var(--ac);color:#fff;border:0;border-radius:12px;padding:12px 22px;font-size:15px;font-weight:600}
#mlbpk{position:fixed;inset:0;z-index:62;background:rgba(0,0,0,.6);display:none;align-items:flex-end;justify-content:center}
#mlbpk.on{display:flex}
#mlbpk .sh{background:var(--p);color:var(--t);border-radius:22px 22px 0 0;padding:18px 18px calc(16px + env(safe-area-inset-bottom,0px));width:100%;max-width:560px;max-height:84vh;overflow:auto;box-sizing:border-box;box-shadow:0 -10px 40px #0008}
#mlbpk .tp{display:flex;gap:14px;align-items:center;margin-bottom:6px}
#mlbpk .im{width:84px;height:84px;border-radius:14px;background:linear-gradient(160deg,#ffffff10,#00000040);flex:0 0 auto;overflow:hidden}
#mlbpk .im img{width:100%;height:100%;object-fit:contain}
#mlbpk h3{margin:0 0 4px;font-size:18px}
#mlbpk .sub{font-size:13px;opacity:.65}
#mlbpk .lb{font-size:12.5px;opacity:.7;margin:16px 2px 8px}
#mlbpk .mb{display:block;width:100%;text-align:start;background:var(--p2);color:var(--t);border:1px solid var(--b);border-radius:12px;padding:14px;margin-bottom:8px;font-size:15px}
#mlbpk .mb.cur{border-color:var(--ac)}
#mlbpk .mb.nw{border-style:dashed;color:var(--ac);font-weight:600}
#mlbpk .rw{display:flex;gap:8px;margin-top:6px}
#mlbpk .rw button{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;background:transparent;color:var(--t);border:1px solid var(--b);border-radius:12px;padding:12px;font-size:14px}
#mlbpk .rw button.dn{color:#ff6b6b}`;
 document.head.appendChild(st);
 const ic=V.ic2,esc2=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const nm=m=>isAr()?m.ar:m.en;
 function list(){const t=q.trim().toLowerCase().split(/\s+/).filter(Boolean);return V.lib().filter(m=>t.every(w=>(m.en+' '+m.kw).toLowerCase().includes(w)))}
 function gridHtml(){const all=V.lib();if(!all.length)return `<div class="mlb-e">${ic('cube',46)}<b>${tr('Your library is empty','مكتبتك فارغة')}</b><p>${tr('Add models from a photo or a script, then drop them into any map.','أضف نماذج من صورة أو سكربت، ثم أضفها إلى أي خريطة.')}</p><button data-mlb="add">${tr('Add your first model','أضف أول نموذج')}</button></div>`;
  const l=list();if(!l.length)return `<div class="mlb-e"><p>${tr('No results','لا توجد نتائج')}</p></div>`;
  return `<div class="mlb-g">${l.map(m=>`<button class="mlb-c" data-mlb="open:${esc2(m.id)}"><div class="mlb-i"><img data-th="${esc2(m.id)}" alt=""></div><b>${esc2(nm(m))}</b><small>${m.np||0} ${tr('parts','قطعة')}</small></button>`).join('')}</div>`}
 function html(){const n=V.lib().length;return `<div class="mlb" id="mlb"><div class="mlb-h"><div class="mlb-t">${tr('Model library','مكتبة النماذج')}<em>${n}</em></div><button class="mlb-add" data-mlb="add">${ic('plus',18)}${tr('Add model','إضافة نموذج')}</button></div>
${n?`<div class="mlb-s">${ic('search',18)}<input type="text" id="mlbq" value="${esc2(q)}" placeholder="${tr('Search','بحث')}" autocomplete="off"></div>`:''}<div id="mlbg">${gridHtml()}</div></div>`}
 function fill(){const root=document.getElementById('mlb');if(!root||busy)return;const imgs=[...root.querySelectorAll('img[data-th]')];if(!imgs.length)return;busy=true;
  (function step(){imgs.splice(0,3).forEach(im=>{const m=V.ML.find(x=>x.id==im.dataset.th);if(!m||!im.isConnected)return;const u=V.thumbOf(m);if(u){im.src=u;im.removeAttribute('data-th')}});if(imgs.length)requestAnimationFrame(step);else busy=false})()}
 function sect(){const hb=document.querySelector('#home .hb');if(!hb)return;const old=document.getElementById('mlb');if(old)old.remove();hb.insertAdjacentHTML('beforeend',html());
  const hr=document.querySelector('#home .hr');if(hr&&!hr.querySelector('[data-mlb=go]')){const b=document.createElement('button');b.className='hl';b.dataset.mlb='go';b.innerHTML=tr('Models','النماذج')+' '+ic('cube',16);hr.appendChild(b)}
  fill()}
 const orig=window.homeUI;window.homeUI=function(){const r=orig.apply(this,arguments);try{sect()}catch(e){}return r};
 function pick(id){const m=V.ML.find(x=>x.id==id);if(!m)return;let d=document.getElementById('mlbpk');if(!d){d=document.createElement('div');d.id='mlbpk';document.body.appendChild(d)}
  d.dir=isAr()?'rtl':'ltr';const th=V.thumbOf(m),ls=[...MP.list].sort((a,b)=>(b.id==MP.cur)-(a.id==MP.cur)||(b.updated||0)-(a.updated||0));
  d.innerHTML=`<div class="sh"><div class="tp"><div class="im">${th?`<img src="${th}" alt="">`:''}</div><div><h3>${esc2(nm(m))}</h3><div class="sub">${m.np||0} ${tr('parts','قطعة')}</div></div></div>
<div class="lb">${tr('Add to map','أضف إلى خريطة')}</div>${ls.map(x=>`<button class="mb${x.id==MP.cur?' cur':''}" data-pm="${esc2(x.id)}">${esc2(x.name)}${x.id==MP.cur?' · '+tr('Current','الحالية'):''}</button>`).join('')}
<button class="mb nw" data-pn="1">${tr('New map with this model','خريطة جديدة بهذا النموذج')}</button>
<div class="rw"><button data-pr="1">${ic('edit',17)}${tr('Rename','إعادة تسمية')}</button><button class="dn" data-pd="1">${ic('trash',17)}${tr('Delete','حذف')}</button></div></div>`;
  d.classList.add('on');
  d.onclick=async e=>{if(e.target==d){d.classList.remove('on');return}const b=e.target.closest('button');if(!b)return;
   if(b.dataset.pm){d.classList.remove('on');openMap(b.dataset.pm);setTimeout(()=>V.placeModel(id),160)}
   else if(b.dataset.pn){d.classList.remove('on');const v=await dlg({title:L('New map'),msg:L('Give your map a name'),input:L('Map')+' '+(MP.list.length+1),ok:L('Create')});if(!v)return;const nid=uid(),n=Date.now();MP.list.push({id:nid,name:v,created:n,updated:n,count:2});openMap(nid);setTimeout(()=>V.placeModel(id),160)}
   else if(b.dataset.pr){d.classList.remove('on');const v=await dlg({title:tr('Rename model','إعادة تسمية النموذج'),msg:'',input:nm(m),ok:tr('Save','حفظ')});if(v){V.renameCustom(id,v);sect()}}
   else if(b.dataset.pd){d.classList.remove('on');const ok=await dlg({title:tr('Delete model?','حذف النموذج؟'),msg:tr('It will be removed from your library.','سيُحذف من مكتبتك.'),ok:tr('Delete','حذف'),danger:1});if(ok){V.delCustom(id);sect()}}}}
 const home=document.getElementById('home');
 home.addEventListener('click',e=>{const b=e.target.closest('[data-mlb]');if(!b)return;const[k,v]=b.dataset.mlb.split(':');
  if(k=='add')V.openAddModel();
  else if(k=='open')pick(v);
  else if(k=='go'){const h=document.getElementById('mlb');if(h)h.scrollIntoView({behavior:'smooth',block:'start'})}});
 home.addEventListener('input',e=>{if(e.target.id=='mlbq'){q=e.target.value;document.getElementById('mlbg').innerHTML=gridHtml();fill()}});
 if(home.classList.contains('on'))sect();
}catch(e){try{window.MapStudioV9.log('v17: '+(e&&e.message||e),'e')}catch(_){}}
})();
