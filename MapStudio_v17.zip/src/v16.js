/* ===== v16 · Show/hide top bar, bottom panel & move bar ===== */
(function(){
'use strict';
const isAr=()=>typeof lang!=='undefined'&&lang=='ar',tr=(en,ar)=>isAr()?ar:en;
try{
 const K='ms16:ui',ls={g(){try{return JSON.parse(localStorage.getItem(K))||{}}catch(e){return{}}},s(v){try{localStorage.setItem(K,JSON.stringify(v))}catch(e){}}};
 const S=Object.assign({nav:true,dock:true,fb:true},ls.g());
 const st=document.createElement('style');st.textContent=`
#nav{z-index:20!important}
#tabs{display:flex!important;overflow-x:auto;scrollbar-width:none}
#tabs button{font-size:13px!important;padding:10px 12px!important}
#vt button.act{background:#2f6bff;border-color:#2f6bff}
body.h-nav #nav{display:none!important}
body.h-dock #dock{display:none!important}
body.h-fb #fb{display:none!important}
#vt{position:absolute;right:8px;top:50%;transform:translateY(-50%);z-index:7;display:flex;flex-direction:column;gap:8px}
#vt button{width:38px;height:38px;border-radius:50%;border:1px solid #fff5;background:#000a;color:#fff;font-size:16px;padding:0;opacity:.85}
#vt button.off{background:#fff3;opacity:.6}
body.playing #vt{display:none}`;
 document.head.appendChild(st);
 const vt=document.createElement('div');vt.id='vt';document.getElementById('vp').appendChild(vt);
 const svgI=p=>'<svg viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="'+p+'"/></svg>';
 const B=[['nav','☰','Top bar','الشريط العلوي'],['dock','▤','Panels','اللوحات'],['fb','✥','Move bar','شريط التحريك']];
 const A=[['Toolbox (trees, buildings, shapes)','الأدوات (أشجار، مباني، أشكال)','M3 8h14v8H3zM7 8V5h6v3M3 12h14',()=>{S.dock=true;ls.s(S);apply();try{window.MapStudioV12.openTab('box')}catch(e){const b=document.querySelector('#tabs [data-d="box"]');b&&b.click()}}],
  ['Script: paste code to build the map','سكربت: الصق كود لبناء الماب','M7 6l-4 4 4 4M13 6l4 4-4 4M11 4l-2 12',()=>{const b=document.getElementById('lub');b&&b.click()}]];
 function apply(){B.forEach(b=>document.body.classList.toggle('h-'+b[0],!S[b[0]]));
  [...vt.children].forEach((e,i)=>{if(i>=A.length)e.classList.toggle('off',!S[B[i-A.length][0]])});
  if(!S.nav){const sh=document.getElementById('sh');if(sh)sh.classList.remove('on')}}
 function labels(){[...vt.children].forEach((e,i)=>{const t=i<A.length?A[i]:B[i-A.length];e.title=i<A.length?tr(t[0],t[1]):tr(t[2],t[3])})}
 A.forEach(a=>{const e=document.createElement('button');e.className='act';e.innerHTML=svgI(a[2]);e.onclick=a[3];vt.appendChild(e)});
 B.forEach(b=>{const e=document.createElement('button');e.textContent=b[1];e.onclick=()=>{S[b[0]]=!S[b[0]];ls.s(S);apply();window.dispatchEvent(new Event('resize'))};vt.appendChild(e)});
 labels();apply();
 const lg=document.getElementById('lang');if(lg)lg.addEventListener('click',()=>setTimeout(labels,80));
}catch(e){try{window.MapStudioV9.log('v16: '+(e&&e.message||e),'e')}catch(_){}}
})();
