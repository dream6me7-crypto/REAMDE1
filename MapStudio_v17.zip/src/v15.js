/* ===== v15 · Avatar Editor (Roblox-style catalog, 3D preview, animations) ===== */
(function(){
'use strict';
const isAr=()=>lang=='ar',tr=(en,ar)=>isAr()?ar:en;
const log=(m,ty)=>{try{window.MapStudioV9.log(m,ty)}catch(e){}};
const ls={g(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const hx=h=>parseInt(String(h).replace('#',''),16)||0;
const P={body:'M10 3a3 3 0 100 6 3 3 0 000-6zM4 17c0-4 2.5-6 6-6s6 2 6 6',skin:'M10 3a7 7 0 100 14 7 7 0 000-14zM10 3v14',face:'M10 3a7 7 0 100 14 7 7 0 000-14zM7 8v1M13 8v1M7 12c1 2 5 2 6 0',hair:'M4 11a6 6 0 0112 0v6H4zM4 11h12',shirt:'M7 3L3 6l2 3 2-1v9h6V8l2 1 2-3-4-3-3 2z',pants:'M6 3h8l1 14h-4l-1-8-1 8H5z',shoes:'M3 12h6l2 2h6v3H3z',hat:'M4 13a6 6 0 0112 0M2 13h16v3H2z',back:'M6 4h8v12H6zM8 8h4M6 10H4v5h2M14 10h2v5h-2',anim:'M3 15h14M5 15V9M10 15V5M15 15v-4M3 4l3 2 4-3 4 3 3-2',out:'M4 4h12v13H4zM8 4V2h4v2M7 9h6M7 12h4',x:'M5 5l10 10M15 5L5 15',save:'M4 3h10l3 3v11H4zM7 3v5h6V3M7 17v-5h6v5',place:'M10 17s-6-5-6-9a6 6 0 0112 0c0 4-6 9-6 9zM10 6a2 2 0 100 4 2 2 0 000-4z',dice:'M4 4h12v12H4zM8 8h.01M12 12h.01M12 8h.01M8 12h.01'};
const ic=(n,s)=>'<svg viewBox="0 0 20 20" width="'+(s||20)+'" height="'+(s||20)+'" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="'+(P[n]||P.body)+'"/></svg>';

/* ---------- catalog ---------- */
const CAT={
 body:[['classic','Classic','كلاسيك'],['slim','Slim','نحيف'],['stocky','Stocky','قوي'],['tall','Tall','طويل'],['kid','Kid','طفل'],['girl','Girl','بنت']],
 face:[['smile','Smile','ابتسامة'],['happy','Happy','سعيد'],['cool','Cool','هادئ'],['sleepy','Sleepy','نعسان'],['wink','Wink','غمزة'],['shock','Surprised','مندهش']],
 hair:[['none','None','بدون'],['short','Short','قصير'],['long','Long','طويل'],['bun','Bun','كعكة'],['twin','Twin tails','ضفيرتان'],['bob','Bob','بوب'],['spiky','Spiky','مدبب']],
 shirt:[['tee','T-Shirt','تيشيرت'],['long','Long sleeve','كم طويل'],['stripes','Stripes','خطوط'],['hoodie','Hoodie','هودي'],['jacket','Jacket','جاكيت'],['kimono','Kimono','كيمونو'],['dress','Dress','فستان']],
 pants:[['jeans','Jeans','جينز'],['shorts','Shorts','شورت'],['skirt','Skirt','تنورة'],['cargo','Cargo','كارغو'],['none','Bare legs','بدون']],
 hat:[['none','None','بدون'],['cap','Cap','كاب'],['beanie','Beanie','قبعة صوف'],['top','Top hat','قبعة عالية'],['crown','Crown','تاج'],['cat','Cat ears','أذن قطة'],['bunny','Bunny ears','أذن أرنب'],['halo','Halo','هالة'],['flower','Flower','زهرة']],
 back:[['none','None','بدون'],['wings','Wings','أجنحة'],['pack','Backpack','حقيبة'],['cape','Cape','عباءة']],
 anim:[['idle','Idle','وقوف'],['walk','Walk','مشي'],['run','Run','ركض'],['dance','Dance','رقص'],['wave','Wave','تحية'],['jump','Jump','قفز'],['sit','Sit','جلوس'],['cheer','Cheer','احتفال']]};
const COLS={skin:['#fde0c8','#f1c9a5','#d9a27a','#a8744f','#6b4430','#ffe9d6'],hair:['#1b1b1b','#3a2418','#8a5a2b','#e8c26a','#ff7aa8','#7a5cff','#f2f2f2'],shirt:['#ff8fb8','#ffffff','#e63946','#2e86de','#2ecc71','#f1c40f','#222222'],accent:['#ffffff','#222222','#ffd24a','#e63946','#2e86de','#ff8fb8'],pants:['#4a5a9a','#222222','#7a5a3a','#ffffff','#8e44ad','#2f6f4f'],shoes:['#ffffff','#222222','#e63946','#8a5a2b'],hatc:['#e63946','#222222','#ffd24a','#2e86de','#ffffff','#ff8fb8']};
const TABS=[['body','Body','الجسم',[]],['skin','Skin','البشرة',['skin']],['face','Face','الوجه',[]],['hair','Hair','الشعر',['hair']],['shirt','Shirts','القمصان',['shirt','accent']],['pants','Pants','البناطيل',['pants']],['shoes','Shoes','الأحذية',['shoes']],['hat','Hats','القبعات',['hatc']],['back','Back','الظهر',[]],['anim','Animations','الحركات',[]],['outs','Outfits','أطقمي',[]]];
const LB={skin:['Skin tone','لون البشرة'],hair:['Hair color','لون الشعر'],shirt:['Shirt color','لون القميص'],accent:['Accent','اللون الثاني'],pants:['Pants color','لون البنطال'],shoes:['Shoe color','لون الحذاء'],hatc:['Hat color','لون القبعة']};
const KEY={skin:'skin',hair:'hair',shirt:'shirt',accent:'accent',pants:'pants',shoes:'shoes',hatc:'hatc'};
const DEF={name:'Hero',body:'classic',skin:'#f1c9a5',face:'smile',hair:'short',hairc:'#3a2418',shirt:'tee',shirtc:'#2e86de',accent:'#ffffff',pants:'jeans',pantsc:'#4a5a9a',shoes:'#ffffff',hat:'none',hatc:'#e63946',back:'none',anim:'idle'};
let C=Object.assign({},DEF,ls.g('ms15:av',{}));
const COLKEY={skin:'skin',hair:'hairc',shirt:'shirtc',accent:'accent',pants:'pantsc',shoes:'shoes',hatc:'hatc'};

/* ---------- avatar spec: pure function ---------- */
function build(c){
 const B={classic:[1,1,1,1],slim:[.82,1,1,1],stocky:[1.25,1,1,1],tall:[1,1.25,1,1],kid:[1,.72,1.3,1],girl:[.85,1,1,1.0]}[c.body]||[1,1,1,1];
 const w=B[0],H=B[1],hs=B[2],lg=2*H,tz=2*H,sw=2*w,al=1.9*H,S=[];
 const add=(n,t,p,s,col,m,limb,r)=>S.push({n,t,p,s,c:col,m:m||'SmoothPlastic',limb:limb||'b',r:r||[0,0,0]});
 const skin=c.skin,sh=c.shirtc,ac=c.accent,pc=c.pantsc,rad=d=>d*Math.PI/180;
 const longPants=c.pants=='jeans'||c.pants=='cargo',shorts=c.pants=='shorts';
 // legs
 [['LeftLeg',-1,'ll'],['RightLeg',1,'rl']].forEach(a=>{const x=a[1]*.5*w;
  if(longPants)add(a[0],'block',[x,lg/2,0],[w*.98,lg,1],pc,0,a[2]);
  else if(shorts){add(a[0]+'Upper','block',[x,lg*.75,0],[w*.98,lg*.5,1.02],pc,0,a[2]);add(a[0]+'Lower','block',[x,lg*.25,0],[w*.9,lg*.5,.95],skin,0,a[2])}
  else add(a[0],'block',[x,lg/2,0],[w*.9,lg,.95],skin,0,a[2]);
  add(a[0].replace('Leg','Shoe'),'block',[x,.2,.08],[w*1.02,.4,1.1],c.shoes,0,a[2]);
  if(c.pants=='cargo')add(a[0]+'Pocket','block',[x+a[1]*w*.5,lg*.45,.3],[.12,.6,.5],'#3d3d3d',0,a[2])});
 if(c.pants=='skirt'||c.shirt=='dress')add('Skirt','block',[0,lg+.1,0],[sw*1.3,.9,1.35],c.shirt=='dress'?sh:pc,0,'b');
 // torso
 add('Torso','block',[0,lg+tz/2,0],[sw,tz,1],sh);
 if(c.shirt=='stripes')[.25,.55,.85,1.15,1.45].forEach((y,i)=>{if(i%2==0)add('Stripe'+i,'block',[0,lg+y*H*.9,0],[sw*1.02,.22*H,1.02],ac)});
 if(c.shirt=='hoodie'){add('HoodPocket','block',[0,lg+.6*H,.52],[sw*.6,.55*H,.08],ac);add('Hood','ball',[0,lg+tz+.1,-.45],[1.3*w,.9,.9],sh)}
 if(c.shirt=='jacket'){add('Zip','block',[0,lg+tz/2,.52],[.08,tz,.06],ac);add('Collar','block',[0,lg+tz-.05,0],[sw*.9,.25,1.1],ac)}
 if(c.shirt=='kimono'){add('Obi','block',[0,lg+tz*.45,0],[sw*1.06,.65*H,1.06],ac);add('KimonoFront','block',[0,lg+tz*.7,.52],[.1,tz*.6,.06],ac)}
 // arms
 const full=c.shirt!='tee'&&c.shirt!='dress';const ay=lg+tz-.15;
 [['LeftArm',-1,'la'],['RightArm',1,'ra']].forEach(a=>{const x=a[1]*(sw/2+w/2);
  if(full){add(a[0],'block',[x,ay-al*.42,0],[w*.98,al*.84,.98],sh,0,a[2]);add(a[0].replace('Arm','Hand'),'block',[x,ay-al*.92,0],[w*.9,al*.16,.9],skin,0,a[2])}
  else{add(a[0]+'Sleeve','block',[x,ay-al*.2,0],[w*.98,al*.4,.98],sh,0,a[2]);add(a[0],'block',[x,ay-al*.7,0],[w*.9,al*.6,.9],skin,0,a[2])}});
 // head + face
 const hd=1.5*hs,hy=lg+tz+hd*.5+.05,r=hd/2;
 add('Head','ball',[0,hy,0],[hd,hd,hd],skin,0,'hd');
 const e={smile:[.2,.22],happy:[.22,.3],cool:[.3,.12],sleepy:[.26,.06],wink:[.2,.22],shock:[.26,.32]}[c.face]||[.2,.22];
 const ez=r*.88;add('LeftEye','ball',[-r*.38,hy+r*.12,ez],[e[0]*hs,e[1]*hs,.1],'#222222',0,'hd');
 add('RightEye','ball',[r*.38,hy+r*.12,ez],[e[0]*hs,c.face=='wink'?.05:e[1]*hs,.1],'#222222',0,'hd');
 add('Mouth','block',[0,hy-r*.42,r*.9],c.face=='shock'?[.22*hs,.26*hs,.08]:c.face=='cool'?[.3*hs,.06,.08]:[.5*hs,.1,.08],c.face=='happy'||c.face=='shock'?'#c0392b':'#7a2e2e',0,'hd');
 if(c.body=='girl')['L','R'].forEach((s,i)=>add('Cheek'+s,'ball',[(i?1:-1)*r*.62,hy-r*.18,r*.82],[.26,.15,.1],'#ff9aa8',0,'hd'));
 // hair
 const hc=c.hairc,hr=r*1.07;
 if(c.hair!='none'){add('HairTop','ball',[0,hy+r*.25,-r*.12],[hd*1.1,hd*.9,hd*1.1],hc,0,'hd');
  if(c.hair=='long')add('HairBack','block',[0,hy-r*.9,-r*.8],[hd*1.05,hd*1.6,.6],hc,0,'hd');
  if(c.hair=='bob')add('HairBob','block',[0,hy-r*.3,-r*.8],[hd*1.1,hd*.9,.6],hc,0,'hd');
  if(c.hair=='bun')add('HairBun','ball',[0,hy+r*1.05,-r*.2],[.8,.8,.8],hc,0,'hd');
  if(c.hair=='twin')['L','R'].forEach((s,i)=>add('Tail'+s,'block',[(i?1:-1)*(r+.2),hy-r*.7,-.2],[.45,1.6,.45],hc,0,'hd'));
  if(c.hair=='short')add('Fringe','block',[0,hy+r*.5,r*.78],[hd*.85,.3,.4],hc,0,'hd');
  if(c.hair=='spiky')[-1,0,1].forEach((k,i)=>add('Spike'+i,'block',[k*r*.6,hy+r*1.05,0],[.28,.7,.28],hc,0,'hd',[0,0,rad(-k*18)]))}
 // hats
 const hcol=c.hatc,top=hy+r;
 if(c.hat=='cap'){add('CapTop','ball',[0,top-.1,0],[hd*1.08,hd*.7,hd*1.08],hcol,0,'hd');add('CapBrim','block',[0,top-.4,r*.85],[hd*.9,.1,.7],hcol,0,'hd')}
 if(c.hat=='beanie'){add('Beanie','ball',[0,top-.15,0],[hd*1.1,hd*.85,hd*1.1],hcol,0,'hd');add('Pom','ball',[0,top+.45,0],[.4,.4,.4],'#ffffff',0,'hd')}
 if(c.hat=='top'){add('TopBrim','cyl',[0,top-.05,0],[hd*1.2,.1,hd*1.2],'#222222',0,'hd');add('TopHat','cyl',[0,top+.5,0],[hd*.8,1,hd*.8],'#222222',0,'hd')}
 if(c.hat=='crown')add('Crown','cyl',[0,top+.1,0],[hd*.85,.5,hd*.85],'#ffd24a','Neon','hd');
 if(c.hat=='cat')[-1,1].forEach((k,i)=>add('Ear'+i,'block',[k*r*.62,top+.15,0],[.4,.55,.15],hcol,0,'hd',[0,0,rad(-k*12)]));
 if(c.hat=='bunny')[-1,1].forEach((k,i)=>add('Bunny'+i,'block',[k*r*.4,top+.7,0],[.3,1.3,.15],hcol,0,'hd',[0,0,rad(-k*8)]));
 if(c.hat=='halo')add('Halo','cyl',[0,top+.65,0],[hd*.95,.06,hd*.95],'#ffe27a','Neon','hd');
 if(c.hat=='flower'){add('FlowerC','ball',[r*.55,top-.1,r*.3],[.3,.3,.3],'#ffd24a',0,'hd');[0,1,2,3,4].forEach(i=>add('Petal'+i,'ball',[r*.55+Math.cos(i*1.256)*.28,top-.1+Math.sin(i*1.256)*.28,r*.3],[.26,.26,.2],hcol,0,'hd'))}
 // back
 const by=lg+tz*.55;
 if(c.back=='wings')[-1,1].forEach((k,i)=>add('Wing'+i,'block',[k*1.5,by+.4,-.7],[.15,2.2,1.3],'#ffffff','Neon','b',[0,rad(k*20),rad(k*22)]));
 if(c.back=='pack')add('Backpack','block',[0,by,-.9],[sw*.8,tz*.75,.7],c.accent=='#ffffff'?'#8a5a2b':c.accent,0,'b');
 if(c.back=='cape')add('Cape','block',[0,by-.3,-.62],[sw*.95,tz*1.3,.12],'#e63946',0,'b',[rad(4),0,0]);
 return {parts:S,piv:{la:[-(sw/2+w/2),ay,0],ra:[sw/2+w/2,ay,0],ll:[-.5*w,lg,0],rl:[.5*w,lg,0],hd:[0,lg+tz,0],b:[0,0,0]},height:hy+r+1};
}
window.MapStudioAvatar={build};

/* ---------- UI ---------- */
function start(){
 if(typeof THREE=='undefined')return;
 const st=document.createElement('style');st.textContent=`
#av{position:fixed;inset:0;z-index:200;background:#061058;display:none;flex-direction:column;color:#fff;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
#av.on{display:flex}
#av button{font-family:inherit}
#avp{flex:1 1 auto;min-height:0;position:relative;background:linear-gradient(#0a1760 0%,#162a8c 100%);touch-action:none;overflow:hidden}
#avp::before{content:"";position:absolute;inset:0;background:repeating-linear-gradient(90deg,#ffffff00 0 38px,#0a135a55 38px 92px,#ffffff00 92px 120px);opacity:.7;pointer-events:none;mask-image:linear-gradient(transparent,#000 30%,#000 70%,transparent)}
#avp canvas{position:absolute;inset:0;width:100%;height:100%}
#avtop{position:absolute;left:0;right:0;top:0;padding:calc(10px + env(safe-area-inset-top,0px)) 14px 0;display:flex;align-items:center;gap:10px;z-index:3}
#avtop button.ic{width:40px;height:40px;border-radius:50%;background:transparent;border:0;color:#fff;padding:0;display:flex;align-items:center;justify-content:center}
#avseg{flex:1;display:flex;background:#0b2aa8;border-radius:14px;padding:4px;gap:4px}
#avseg button{flex:1;border:0;border-radius:11px;background:transparent;color:#fff;padding:10px 4px;font-size:15px;font-weight:600}
#avseg button.on{background:#2f56d8}
#avsrow{display:none;position:absolute;left:14px;right:14px;top:calc(66px + env(safe-area-inset-top,0px));z-index:3}
#avsrow.on{display:block}
#avsrow input{width:100%;box-sizing:border-box;background:#0b2aa8;color:#fff;border:1px solid #4a6cf0;border-radius:12px;padding:10px 12px;font-size:15px}
#avl{position:absolute;left:12px;top:calc(76px + env(safe-area-inset-top,0px));z-index:3;display:flex;flex-direction:column;gap:6px;background:#0b2aa8;border-radius:22px;padding:8px 6px}
#avl button{width:42px;height:42px;border-radius:50%;background:transparent;border:0;color:#fff;padding:0;display:flex;align-items:center;justify-content:center}
#avr{position:absolute;right:12px;top:calc(80px + env(safe-area-inset-top,0px));z-index:3}
#avr button{display:flex;align-items:center;gap:6px;background:#2f6bff;border:0;border-radius:20px;color:#fff;padding:10px 14px;font-size:14px;font-weight:600;box-shadow:0 3px 10px #0006}
#avu{position:absolute;left:12px;bottom:14px;z-index:3;display:flex;gap:4px;background:#0b2aa8cc;border-radius:24px;padding:6px 10px}
#avu button{width:44px;height:40px;background:transparent;border:0;color:#fff;padding:0;display:flex;align-items:center;justify-content:center}
#avu button:disabled{opacity:.35}
#avn{position:absolute;right:12px;bottom:16px;background:#0b2aa8cc;color:#fff;border-radius:14px;padding:5px 12px;font-size:12px;z-index:3}
#avs{flex:0 0 auto;height:50%;display:flex;flex-direction:column;background:#06197a;border-radius:22px 22px 0 0;box-shadow:0 -6px 20px #0006;transition:height .22s;margin-top:-18px;position:relative;z-index:4}
#avs.min{height:150px}
#avg{height:26px;flex:0 0 auto;background:transparent;border:0;display:flex;align-items:center;justify-content:center;padding:0}
#avg i{display:block;width:44px;height:5px;border-radius:3px;background:#ffffff55}
#avt{display:flex;overflow-x:auto;flex:0 0 auto;scrollbar-width:none}
#avt button{flex:0 0 auto;background:transparent;border:0;color:#ffffffcc;font-size:17px;font-weight:600;padding:8px 14px 10px;border-bottom:3px solid transparent}
#avt button.on{color:#fff;border-bottom-color:#fff}
#avsub{display:flex;overflow-x:auto;flex:0 0 auto;background:#0a2496;scrollbar-width:none}
#avsub button{flex:0 0 auto;background:transparent;border:0;color:#ffffffcc;font-size:16px;font-weight:600;padding:14px 18px 12px;border-bottom:3px solid transparent}
#avsub button.on{color:#fff;border-bottom-color:#fff}
#avb{flex:1;overflow-y:auto;padding:14px 12px calc(14px + env(safe-area-inset-bottom,0px));background:#06197a}
#avb .ttl{font-size:20px;font-weight:700;margin:2px 4px 12px}
#avb .ttl.s{font-size:12px;font-weight:500;opacity:.75;margin:14px 4px 6px}
#avb .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
#avb .card{background:transparent;border:0;color:#fff;padding:0;text-align:start;display:flex;flex-direction:column;gap:2px;min-width:0}
#avb .card .th{aspect-ratio:1/1;background:#1b3399;border-radius:12px;border:2px solid transparent;display:flex;align-items:center;justify-content:center;padding:10px;box-sizing:border-box;overflow:hidden}
#avb .card.on .th{border-color:#5aa8ff;background:#24409f}
#avb .card b{font-size:14px;font-weight:600;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#avb .card i{font-style:normal;font-size:13px;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#avb .card .pr{font-size:13px;opacity:.8}
#avb .sw{display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding:0 4px}
#avb .sw button{width:40px;height:40px;border-radius:50%;padding:0}
#avb .sw input[type=color]{width:44px;height:40px;padding:0;border:0;background:transparent}
#avb input.nm{width:100%;box-sizing:border-box;background:#0b2aa8;color:#fff;border:1px solid #4a6cf0;border-radius:10px;padding:11px;font-size:16px}
#avb .btn{background:#1b3399;color:#fff;border:0;border-radius:12px;padding:12px;font-size:14px}`;
 document.head.appendChild(st);
 const ov=document.createElement('div');ov.id='av';document.body.appendChild(ov);
 ov.innerHTML='<div id="avp"><canvas></canvas><div id="avtop"><button class="ic" id="avx"></button><div id="avseg"></div><button class="ic" id="avsr"></button></div><div id="avsrow"><input id="avq" type="text" autocomplete="off"></div><div id="avl"></div><div id="avr"></div><div id="avu"></div><div id="avn"></div></div><div id="avs"><button id="avg"><i></i></button><div id="avt"></div><div id="avsub"></div><div id="avb"></div></div>';
 const q=s=>ov.querySelector(s);
 Object.assign(P,{search:'M9 3a6 6 0 100 12A6 6 0 009 3zM14 14l4 4',back:'M16 10H4M9 5l-5 5 5 5',undo:'M7 5L3 9l4 4M3 9h8a5 5 0 010 10H8',redo:'M13 5l4 4-4 4M17 9H9a5 5 0 000 10h3',rnd:'M4 4h12v12H4zM8 8h.01M12 12h.01M12 8h.01M8 12h.01'});
 q('#avx').innerHTML=ic('back',26);q('#avsr').innerHTML=ic('search',24);
 let tab='body',main='bodyg',mode='shop',qry='',srch=false,hist=[],hi=-1,rd,sc3,cam,grp,piv={},t0=performance.now(),run=false,yaw=.5,drag=null;
 function init3(){const cv=q('#avp canvas');rd=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});rd.setPixelRatio(Math.min(2,window.devicePixelRatio||1));
  sc3=new THREE.Scene();cam=new THREE.PerspectiveCamera(35,1,.1,200);
  sc3.add(new THREE.AmbientLight(0xffffff,.75));const dl=new THREE.DirectionalLight(0xffffff,.8);dl.position.set(5,10,8);sc3.add(dl);
  const fl=new THREE.Mesh(new THREE.CylinderGeometry(3.2,3.2,.2,40),new THREE.MeshStandardMaterial({color:0x3f55c8,transparent:true,opacity:.55}));fl.position.y=-.1;sc3.add(fl);
  const pp=q('#avp');pp.addEventListener('pointerdown',e=>{drag=e.clientX});window.addEventListener('pointerup',()=>{drag=null});
  pp.addEventListener('pointermove',e=>{if(drag!=null){yaw+=(e.clientX-drag)*.01;drag=e.clientX}})}
 function size(){const p=q('#avp'),w=p.clientWidth,h=p.clientHeight;if(!w||!h)return;rd.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix()}
 function geo(t){return t=='ball'?new THREE.SphereGeometry(.5,18,14):t=='cyl'?new THREE.CylinderGeometry(.5,.5,1,20):new THREE.BoxGeometry(1,1,1)}
 function rebuild(){if(!sc3)return;if(grp)sc3.remove(grp);grp=new THREE.Group();piv={};const sp=build(C);
  Object.keys(sp.piv).forEach(k=>{const g=new THREE.Group();g.position.fromArray(sp.piv[k]);grp.add(g);piv[k]=g});
  sp.parts.forEach(p=>{const m=new THREE.Mesh(geo(p.t),new THREE.MeshStandardMaterial({color:hx(p.c),roughness:p.m=='Neon'?.2:.7,emissive:p.m=='Neon'?new THREE.Color(hx(p.c)):0x000000,emissiveIntensity:p.m=='Neon'?.5:0}));
   const pv=sp.piv[p.limb]||[0,0,0];m.position.set(p.p[0]-pv[0],p.p[1]-pv[1],p.p[2]-pv[2]);m.scale.set(p.s[0],p.s[1],p.s[2]);m.rotation.set(p.r[0],p.r[1],p.r[2]);piv[p.limb].add(m)});
  // head & arm pivots sit inside body pivot space already (all pivots children of grp)
  sc3.add(grp);const h=sp.height;cam.position.set(0,h*.55,h*2.1);cam.lookAt(0,h*.5,0);q('#avn').textContent=C.name}
 function pose(t){if(!grp)return;const a=piv;const s=Math.sin,A=C.anim;
  Object.values(a).forEach(g=>{g.rotation.set(0,0,0)});grp.position.set(0,0,0);grp.rotation.y=yaw+(A=='dance'?s(t*3)*.4:0);
  if(A=='idle'){a.la.rotation.x=s(t*1.5)*.05;a.ra.rotation.x=-s(t*1.5)*.05;grp.position.y=s(t*1.5)*.02}
  else if(A=='walk'||A=='run'){const f=A=='run'?9:5.5,m=A=='run'?1:.65;a.ll.rotation.x=s(t*f)*m;a.rl.rotation.x=-s(t*f)*m;a.la.rotation.x=-s(t*f)*m;a.ra.rotation.x=s(t*f)*m;grp.position.y=Math.abs(s(t*f))*(A=='run'?.18:.08)}
  else if(A=='dance'){a.la.rotation.z=-2.4+s(t*6)*.5;a.ra.rotation.z=2.4-s(t*6)*.5;a.ll.rotation.x=s(t*6)*.4;a.rl.rotation.x=-s(t*6)*.4;grp.position.y=Math.abs(s(t*6))*.25;a.hd.rotation.z=s(t*3)*.15}
  else if(A=='wave'){a.ra.rotation.z=2.6;a.ra.rotation.x=0;a.ra.rotation.y=0;a.ra.rotation.z=2.5+s(t*8)*.25;a.la.rotation.x=s(t*1.5)*.04}
  else if(A=='jump'){const j=Math.abs(s(t*3));grp.position.y=j*1.4;a.la.rotation.z=-2+j*.2;a.ra.rotation.z=2-j*.2;a.ll.rotation.x=-j*.5;a.rl.rotation.x=j*.5}
  else if(A=='sit'){grp.position.y=-.9;a.ll.rotation.x=-1.5;a.rl.rotation.x=-1.5;a.la.rotation.x=-.5;a.ra.rotation.x=-.5}
  else if(A=='cheer'){const j=Math.abs(s(t*5));a.la.rotation.z=-2.7;a.ra.rotation.z=2.7;a.la.rotation.x=s(t*5)*.2;a.ra.rotation.x=-s(t*5)*.2;grp.position.y=j*.3}}
 function loop(){if(!run)return;requestAnimationFrame(loop);size();pose((performance.now()-t0)/1000);rd.render(sc3,cam)}
 const MAIN=[['all','All','الكل',[]],['bodyg','Body','الجسم',['body','skin','face','hair']],['cloth','Clothes','ملابس',['shirt','pants','shoes']],['acc','Accessories','الإكسسوارات',['hat','back']],['anim','Animations','الحركات',['anim']],['outs','Outfits','أطقمي',['outs']]];
 const SUBN={body:['Body','الجسم'],skin:['Skin','البشرة'],face:['Face','الوجه'],hair:['Hair','الشعر'],shirt:['Shirts','القمصان'],pants:['Pants','البناطيل'],shoes:['Shoes','الأحذية'],hat:['Hats','القبعات'],back:['Back','الظهر'],anim:['Emotes','الحركات'],outs:['Saved','المحفوظة']};
 const svg=s=>`<svg viewBox="0 0 64 64" width="100%" height="100%">${s}</svg>`;
 function head(id,faceId){const e={smile:'<circle cx="26" cy="26" r="2"/><circle cx="38" cy="26" r="2"/>',happy:'<path d="M23 27q3-4 6 0M35 27q3-4 6 0" fill="none" stroke="#222" stroke-width="2"/>',cool:'<rect x="21" y="23" width="9" height="5" rx="1"/><rect x="34" y="23" width="9" height="5" rx="1"/>',sleepy:'<path d="M23 26h6M35 26h6" stroke="#222" stroke-width="2"/>',wink:'<circle cx="26" cy="26" r="2"/><path d="M35 26h6" stroke="#222" stroke-width="2"/>',shock:'<circle cx="26" cy="25" r="3"/><circle cx="38" cy="25" r="3"/>'}[faceId||'smile'];
  const m={smile:'<path d="M26 36q6 5 12 0" fill="none" stroke="#222" stroke-width="2"/>',happy:'<path d="M25 35q7 8 14 0z"/>',cool:'<path d="M27 37h10" stroke="#222" stroke-width="2"/>',sleepy:'<path d="M28 37h8" stroke="#222" stroke-width="2"/>',wink:'<path d="M26 36q6 5 12 0" fill="none" stroke="#222" stroke-width="2"/>',shock:'<ellipse cx="32" cy="38" rx="3" ry="4"/>'}[faceId||'smile'];
  return `<circle cx="32" cy="30" r="17" fill="${C.skin}"/><g fill="#222">${e}${m}</g>`}
 function thumb(k,id){const sk=C.skin;
  if(k=='body'){const w={classic:1,slim:.8,stocky:1.25,tall:1,kid:1,girl:.85}[id]||1,h={tall:1.2,kid:.72}[id]||1,hw=12*w;return svg(`<g transform="translate(32 ${id=='kid'?40:34}) scale(1 ${h})"><circle cx="0" cy="-16" r="7" fill="${sk}"/><rect x="${-hw}" y="-8" width="${hw*2}" height="20" rx="2" fill="#2e86de"/><rect x="${-hw-5}" y="-8" width="5" height="16" fill="${sk}"/><rect x="${hw}" y="-8" width="5" height="16" fill="${sk}"/><rect x="${-hw}" y="12" width="${hw-1}" height="14" fill="#4a5a9a"/><rect x="1" y="12" width="${hw-1}" height="14" fill="#4a5a9a"/></g>`)}
  if(k=='face')return svg(head(0,id));
  if(k=='hair'){const c=C.hairc;const H={none:'',short:`<path d="M15 28a17 17 0 0134 0q-17-9-34 0z" fill="${c}"/>`,long:`<path d="M15 32a17 17 0 0134 0v18h-6V30H21v20h-6z" fill="${c}"/>`,bun:`<circle cx="32" cy="10" r="7" fill="${c}"/><path d="M15 28a17 17 0 0134 0q-17-9-34 0z" fill="${c}"/>`,twin:`<path d="M15 28a17 17 0 0134 0q-17-9-34 0z" fill="${c}"/><circle cx="12" cy="40" r="6" fill="${c}"/><circle cx="52" cy="40" r="6" fill="${c}"/>`,bob:`<path d="M14 36a18 18 0 0136 0v6h-7V28H21v14h-7z" fill="${c}"/>`,spiky:`<path d="M15 28l3-14 6 8 4-12 5 11 6-9 3 12 4-2q-17-9-31 6z" fill="${c}"/>`}[id]||'';return svg(`<circle cx="32" cy="32" r="17" fill="${sk}"/>${H}`)}
  if(k=='shirt'){const c=C.shirtc,a=C.accent;let x=`<path d="M20 10L6 20l7 11 7-4v29h24V27l7 4 7-11-14-10-7 6h-10z" fill="${c}"/>`;if(id=='stripes')x+=[22,32,42].map(y=>`<rect x="20" y="${y}" width="24" height="4" fill="${a}"/>`).join('');if(id=='hoodie')x+=`<circle cx="32" cy="14" r="8" fill="${a}"/>`;if(id=='jacket')x+=`<rect x="31" y="14" width="2" height="42" fill="${a}"/>`;if(id=='kimono')x+=`<path d="M26 10l12 46" stroke="${a}" stroke-width="3"/>`;if(id=='dress')x=`<path d="M22 8h20l4 14 8 34H10l8-34z" fill="${c}"/>`;if(id=='long')x+=`<rect x="4" y="22" width="9" height="22" fill="${c}"/><rect x="51" y="22" width="9" height="22" fill="${c}"/>`;return svg(x)}
  if(k=='pants'){const c=C.pantsc;return svg({jeans:`<path d="M18 8h28l4 50H35l-3-30-3 30H14z" fill="${c}"/>`,shorts:`<path d="M16 12h32l3 24H35l-3-10-3 10H13z" fill="${c}"/>`,skirt:`<path d="M20 12h24l10 30H10z" fill="${c}"/>`,cargo:`<path d="M18 8h28l4 50H35l-3-30-3 30H14z" fill="${c}"/><rect x="19" y="32" width="8" height="8" fill="#0003"/><rect x="37" y="32" width="8" height="8" fill="#0003"/>`,none:`<path d="M24 10h6v46h-6zM34 10h6v46h-6z" fill="${sk}"/>`}[id]||'')}
  if(k=='hat'){const c=C.hatc;return svg(`<circle cx="32" cy="42" r="14" fill="${sk}"/>`+({none:'',cap:`<path d="M16 38a16 16 0 0132 0zM14 38h40v4H14z" fill="${c}"/>`,beanie:`<path d="M17 38a15 15 0 0130 0z" fill="${c}"/><circle cx="32" cy="22" r="4" fill="${c}"/>`,top:`<rect x="22" y="12" width="20" height="24" fill="${c}"/><rect x="14" y="34" width="36" height="5" fill="${c}"/>`,crown:`<path d="M16 38l3-16 8 8 5-12 5 12 8-8 3 16z" fill="${c}"/>`,cat:`<path d="M18 36l-2-18 12 10zM46 36l2-18-12 10z" fill="${c}"/>`,bunny:`<rect x="21" y="8" width="7" height="26" rx="3" fill="${c}"/><rect x="36" y="8" width="7" height="26" rx="3" fill="${c}"/>`,halo:`<ellipse cx="32" cy="24" rx="14" ry="4" fill="none" stroke="${c}" stroke-width="3"/>`,flower:`<circle cx="32" cy="30" r="5" fill="#ffd24a"/><circle cx="24" cy="30" r="5" fill="${c}"/><circle cx="40" cy="30" r="5" fill="${c}"/><circle cx="32" cy="22" r="5" fill="${c}"/>`}[id]||''))}
  if(k=='back')return svg({none:'<path d="M18 18l28 28M46 18L18 46" stroke="#fff6" stroke-width="3"/>',wings:'<path d="M30 30C20 10 6 14 6 14c0 18 10 24 24 24zM34 30c10-20 24-16 24-16 0 18-10 24-24 24z" fill="#fff"/>',pack:'<rect x="18" y="14" width="28" height="36" rx="6" fill="#e63946"/><rect x="22" y="32" width="20" height="12" rx="3" fill="#0003"/>',cape:'<path d="M20 10h24l8 46H12z" fill="#e63946"/>'}[id]||'');
  if(k=='anim')return ic('anim',46);
  return ic('body',46)}
 const card=(on,th,name,att)=>`<button class="card${on?' on':''}" ${att}><div class="th">${th}</div><b>${name}</b><i>Map Studio</i><span class="pr">${tr('Free','مجاني')}</span></button>`;
 const swatches=k=>{const ck=COLKEY[k];return `<div class="ttl s">${tr(LB[k][0],LB[k][1])}</div><div class="sw">${COLS[k].map(c=>`<button data-sw="${ck}:${c}" style="background:${c};border:3px solid ${C[ck].toLowerCase()==c.toLowerCase()?'#fff':'#0008'}"></button>`).join('')}<input type="color" data-cc="${ck}" value="${C[ck]}"></div>`};
 const nameOf=it=>isAr()?it[2]:it[1];
 const okQ=n=>!qry||n.toLowerCase().includes(qry.toLowerCase());
 const items=key=>CAT[key].filter(it=>okQ(nameOf(it))).map(it=>card(C[key]==it[0],thumb(key,it[0]),nameOf(it),'data-it="'+key+':'+it[0]+'"')).join('');
 function draw(){const M=MAIN.find(x=>x[0]==main)||MAIN[1];if(M[3].length&&!M[3].includes(tab))tab=M[3][0];
  q('#avseg').innerHTML=`<button data-mode="shop" class="${mode=='shop'?'on':''}">${tr('Shop','المتجر')}</button><button data-mode="cust" class="${mode=='cust'?'on':''}">${tr('Customize','تخصيص')}</button>`;
  q('#avs').style.display='';
  q('#avt').innerHTML=MAIN.map(x=>`<button data-main="${x[0]}" class="${x[0]==main?'on':''}">${tr(x[1],x[2])}</button>`).join('');
  q('#avsub').style.display=(mode=='shop'&&M[3].length>1)?'flex':'none';
  q('#avsub').innerHTML=M[3].map(k=>`<button data-tab="${k}" class="${k==tab?'on':''}">${tr(SUBN[k][0],SUBN[k][1])}</button>`).join('');
  if(mode=='shop'){q('#avt').style.display='flex'}else{q('#avt').style.display='none'}
  let h='';
  if(mode=='cust'){h+=`<div class="ttl s">${tr('Name','الاسم')}</div><input class="nm" data-name value="${C.name}">`;['skin','hair','shirt','accent','pants','shoes','hatc'].forEach(k=>{h+=swatches(k)})}
  else if(main=='all'){h+=`<div class="ttl">${tr('Recommended for you','مقترح لك')}</div><div class="grid">${['body','face','hair','shirt','pants','hat','back','anim'].map(k=>items(k)).join('')}</div>`}
  else if(tab=='shoes')h+=swatches('shoes');
  else if(tab=='skin')h+=swatches('skin');
  else if(tab=='outs'){const o=ls.g('ms15:outs',[]);h+=`<div class="ttl">${tr('Saved outfits','الأطقم المحفوظة')} (${o.length})</div><div class="grid">${o.map((x,i)=>card(false,ic('out',46),x.name,'data-wear="'+i+'"')).join('')||`<div class="ttl s">${tr('Nothing saved yet. Tap save on the left.','لا شيء محفوظ بعد. اضغط حفظ.')}</div>`}</div>`+(o.length?`<div class="ttl s"></div><button class="btn" data-delo>${tr('Delete last','حذف الأخير')}</button>`:'')}
  else{h+=`<div class="grid">${items(tab)}</div>`;(TABS.find(x=>x[0]==tab)||[0,0,0,[]])[3].forEach(k=>{h+=swatches(k)})}
  q('#avb').innerHTML=h;
  q('#avl').innerHTML=`<button data-a="save" title="${tr('Save','حفظ')}">${ic('save',24)}</button><button data-a="rnd" title="${tr('Random','عشوائي')}">${ic('rnd',24)}</button>`;
  q('#avr').innerHTML=`<button data-a="place">${ic('place',20)}${tr('Place in map','ضعها في الماب')}</button>`;
  q('#avu').innerHTML=`<button data-a="undo" ${hi<=0?'disabled':''}>${ic('undo',24)}</button><button data-a="redo" ${hi>=hist.length-1?'disabled':''}>${ic('redo',24)}</button>`;
  q('#avsrow').classList.toggle('on',srch);q('#avq').placeholder=tr('Search','بحث')}
 function chg(){ls.s('ms15:av',C);hist=hist.slice(0,hi+1);hist.push(JSON.stringify(C));hi=hist.length-1;rebuild();draw()}
 const pick=a=>a[Math.floor(Math.random()*a.length)];
 function place(){let ox=0,oz=0,gy=0;try{ox=Math.round(tg.x);oz=Math.round(tg.z)}catch(e){}try{gy=groundY(ox,oz)}catch(e){}
  const nm='Character_'+(C.name||'Hero').replace(/\s+/g,'');const sp=build(C);
  sp.parts.forEach(p=>mk(p.t=='cyl'?'cyl':p.t,{p:[ox+p.p[0],gy+p.p[1],oz+p.p[2]],r:p.r,s:p.s.slice(),n:nm+'_'+p.n,c:hx(p.c),m:p.m,co:false}));save();ls.s('ms15:av',C);toast(tr('Character placed','تم وضع الشخصية'));close()}
 ov.addEventListener('click',e=>{const t=e.target.closest('button');if(!t)return;
  if(t.id=='avx')return close();
  if(t.id=='avsr'){srch=!srch;if(!srch)qry='';draw();if(srch)q('#avq').focus();return}
  if(t.id=='avg'){q('#avs').classList.toggle('min');return}
  if(t.dataset.mode){mode=t.dataset.mode;return draw()}
  if(t.dataset.main){main=t.dataset.main;const M=MAIN.find(x=>x[0]==main);if(M[3].length)tab=M[3][0];return draw()}
  if(t.dataset.tab){tab=t.dataset.tab;return draw()}
  if(t.dataset.it){const[k,v]=t.dataset.it.split(':');C[k]=v;return chg()}
  if(t.dataset.sw){const i=t.dataset.sw.indexOf(':');C[t.dataset.sw.slice(0,i)]=t.dataset.sw.slice(i+1);return chg()}
  if(t.dataset.wear!=null){C=Object.assign({},DEF,ls.g('ms15:outs',[])[+t.dataset.wear]);return chg()}
  if('delo' in t.dataset){const o=ls.g('ms15:outs',[]);o.pop();ls.s('ms15:outs',o);return draw()}
  const a=t.dataset.a;if(a=='save'){const o=ls.g('ms15:outs',[]);o.push(Object.assign({},C,{name:C.name||'Outfit'+(o.length+1)}));ls.s('ms15:outs',o);toast(tr('Outfit saved','تم حفظ الطقم'))}
  if(a=='undo'&&hi>0){hi--;C=Object.assign({},DEF,JSON.parse(hist[hi]));ls.s('ms15:av',C);rebuild();draw()}
  if(a=='redo'&&hi<hist.length-1){hi++;C=Object.assign({},DEF,JSON.parse(hist[hi]));ls.s('ms15:av',C);rebuild();draw()}
  if(a=='rnd'){C.body=pick(CAT.body)[0];C.skin=pick(COLS.skin);C.face=pick(CAT.face)[0];C.hair=pick(CAT.hair)[0];C.hairc=pick(COLS.hair);C.shirt=pick(CAT.shirt)[0];C.shirtc=pick(COLS.shirt);C.pants=pick(CAT.pants)[0];C.pantsc=pick(COLS.pants);C.hat=pick(CAT.hat)[0];C.back=pick(CAT.back)[0];chg()}
  if(a=='place')place()});
 ov.addEventListener('input',e=>{const t=e.target;if(t.id=='avq'){qry=t.value;const b=q('#avb'),y=b.scrollTop;draw();q('#avq').focus();return}if(t.dataset.cc){C[t.dataset.cc]=t.value;ls.s('ms15:av',C);rebuild()}else if('name' in t.dataset){C.name=t.value;q('#avn').textContent=C.name;ls.s('ms15:av',C)}});
 ov.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.cc){hist=hist.slice(0,hi+1);hist.push(JSON.stringify(C));hi=hist.length-1;draw()}});
 function open(){if(!rd)init3();ov.classList.add('on');hist=[JSON.stringify(C)];hi=0;srch=false;qry='';draw();rebuild();run=true;t0=performance.now();setTimeout(()=>{size();loop()},30)}
 function close(){ov.classList.remove('on');run=false}
 window.MapStudioAvatar.open=open;
 // route every Character entry to the editor
 const b=document.querySelector('#tabs [data-d="chr"]');if(b)b.onclick=open;
}
try{start()}catch(e){log('v15 avatar: '+(e&&e.message||e),'e')}

/* strip leftover emoji from UI text periodically */
try{const EM=/[\p{Extended_Pictographic}\u200d\ufe0f]/gu;
 setInterval(()=>{['nav','dock','sh'].forEach(i=>{const r=document.getElementById(i);if(!r)return;const w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT,{acceptNode:x=>x.parentElement&&x.parentElement.closest('#exp,#home')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT});let n;const L=[];while(n=w.nextNode()){EM.lastIndex=0;if(EM.test(n.nodeValue))L.push(n)}L.forEach(t=>{EM.lastIndex=0;t.nodeValue=t.nodeValue.replace(EM,'').replace(/^\s+/,'')})})},700)}catch(e){}
})();

