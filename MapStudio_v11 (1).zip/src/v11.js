/* ===== v11 · Model tools · Part flags · Terrain Flatten/Fill/Sea Level · ParticleEmitter ===== */
(function(){
'use strict';
const T=R,isAr=()=>lang=='ar',tr=(en,ar)=>isAr()?ar:en;
const log=(m,ty)=>{try{window.MapStudioV9.log(m,ty)}catch(e){}};
const guard=(n,fn)=>{try{fn()}catch(e){log('v11 '+n+': '+(e&&e.message||e),'e')}};
const TB=[];
function addTab(id,en,ar,render){const b=document.createElement('button');b.dataset.d=id;$('tabs').appendChild(b);const p=document.createElement('div');p.id=id;p.className='pn';$('pane').appendChild(p);
 b.onclick=()=>{const was=b.classList.contains('on');document.querySelectorAll('#tabs button').forEach(x=>x.classList.toggle('on',x==b));document.querySelectorAll('.pn').forEach(x=>x.classList.toggle('on',x.id==id));$('dock').classList.toggle('min',was&&!$('dock').classList.contains('min'));if(!was)render()};
 b.textContent=tr(en,ar);TB.push({b,en,ar,render});return p}
const sel=()=>[...sels];
const need=()=>{if(!sels.size){toast(tr('Select parts first','حددي مجسمات أولاً'));return false}return true};
const btn=(a,en,ar,cls)=>`<button data-a="${a}" class="${cls||''}">${tr(en,ar)}</button>`;

/* 1) MODEL: Group / Ungroup / Align / Flags / Reflectance */
guard('model',()=>{
 let gid=0;const FL=[['an','Anchored','تثبيت'],['co','CanCollide','اصطدام'],['ct','CanTouch','اللمس'],['cq','CanQuery','الاستعلام']];
 const p=addTab('mdl','Model','النمذجة',r);
 function flagState(k){const a=sel();if(!a.length)return false;return a.every(m=>k=='ct'||k=='cq'?m.userData[k]!==false:m.userData[k])}
 function r(){p.innerHTML=`<div class="nt">${tr('Selected','المحدد')}: ${sels.size}</div>
<div class="rw2">${btn('grp','Group','تجميع')}${btn('ungrp','Ungroup','فك التجميع')}${btn('selgrp','Select group','تحديد المجموعة')}</div>
<div class="nt">${tr('Align (selected parts)','محاذاة (المحدد)')}</div>
<div class="rw2">${['x','y','z'].map(a=>btn('al'+a+'min',a.toUpperCase()+' min',a.toUpperCase()+' أدنى')).join('')}</div>
<div class="rw2">${['x','y','z'].map(a=>btn('al'+a+'c',a.toUpperCase()+' center',a.toUpperCase()+' وسط')).join('')}</div>
<div class="rw2">${['x','y','z'].map(a=>btn('al'+a+'max',a.toUpperCase()+' max',a.toUpperCase()+' أقصى')).join('')}</div>
<div class="nt">${tr('Part flags','خصائص القطعة')}</div>
<div class="ckr">${FL.map(f=>`<label class="ck"><input type="checkbox" data-f="${f[0]}"${flagState(f[0])?' checked':''}>${f[1]}</label>`).join('')}</div>
<div class="r"><label>Reflectance</label><div class="v"><input type="range" data-rf min="0" max="1" step=".05" value="${sels.size?(sel()[0].userData.rf||0):0}"><output>${sels.size?(sel()[0].userData.rf||0):0}</output></div></div>
<div class="nt">${tr('Groups and CanTouch/CanQuery are kept for this session and in Luau comments.','المجموعات وCanTouch/CanQuery تُحفظ أثناء الجلسة.')}</div>`}
 p.addEventListener('click',e=>{const a=e.target.dataset.a;if(!a||!need())return;const L=sel();
  if(a=='grp'){gid++;const g='Group'+gid+'_'+Date.now().toString(36);L.forEach(m=>m.userData.grp=g);toast(tr('Grouped ','تم تجميع ')+L.length)}
  else if(a=='ungrp'){L.forEach(m=>delete m.userData.grp);toast(tr('Ungrouped','تم فك التجميع'))}
  else if(a=='selgrp'){const gs=new Set(L.map(m=>m.userData.grp).filter(Boolean));items.forEach(m=>{if(gs.has(m.userData.grp))sels.add(m)});sync()}
  else if(/^al[xyz]/.test(a)){const ax=a[2],md=a.slice(3),ext=m=>{const b=new T.Box3().setFromObject(m);return[b.min[ax],b.max[ax]]},ex=L.map(ext);
   const lo=Math.min(...ex.map(e=>e[0])),hi=Math.max(...ex.map(e=>e[1]));
   L.forEach((m,i)=>{const[a0,a1]=ex[i];const d=md=='min'?lo-a0:md=='max'?hi-a1:(lo+hi)/2-(a0+a1)/2;m.position[ax]+=d});save()}
  r()});
 p.addEventListener('change',e=>{const f=e.target.dataset.f;if(f&&need()){sel().forEach(m=>m.userData[f]=e.target.checked);save()}});
 p.addEventListener('input',e=>{if(e.target.hasAttribute('data-rf')&&sels.size){const v=parseFloat(e.target.value);sel().forEach(m=>{m.userData.rf=v;m.material.metalness=Math.max(m.material.metalness,v*.6);m.material.roughness=Math.min(m.material.roughness,1-v*.7)});e.target.nextElementSibling.textContent=v}});
});

/* 2) TERRAIN extras: Flatten · Fill · Sea Level */
guard('terrain2',()=>{
 const st={lvl:0,sea:false};let sea=null;
 const hills=()=>items.filter(m=>/^Terrain_(Hill|Sculpt)/.test(m.userData.name));
 const p=addTab('ter2','Terrain+','تضاريس+',r);
 function r(){p.innerHTML=`<div class="rw2">${btn('flat','Flatten hills','تسوية التلال')}${btn('fill','Fill (water level)','ملء')}</div>
<div class="r"><label>Sea Level</label><div class="v"><input type="range" data-sl min="-5" max="20" step=".5" value="${st.lvl}"><output>${st.lvl}</output></div></div>
<div class="rw2">${btn('sea',st.sea?'Hide sea':'Show sea',st.sea?'إخفاء البحر':'إظهار البحر',st.sea?'on2':'')}</div>
<div class="nt">${tr('Flatten lowers every Terrain hill to half height. Fill raises low hills up to the sea level. Sea is a blue water plane.','التسوية تخفض كل التلال للنصف، والملء يرفع التلال المنخفضة إلى مستوى البحر، والبحر سطح مائي أزرق.')}</div>`}
 function setSea(){if(!sea){sea=new T.Mesh(new T.PlaneGeometry(600,600),new T.MeshStandardMaterial({color:0x3a8fd9,transparent:true,opacity:.6,side:T.DoubleSide}));sea.rotation.x=-Math.PI/2;sea.userData={name:'SeaLevel',skip:true};sc.add(sea)}sea.visible=st.sea;sea.position.y=st.lvl}
 p.addEventListener('click',e=>{const a=e.target.dataset.a;if(!a)return;
  if(a=='flat'){hills().forEach(m=>{m.scale.y*=.5});save();toast(tr('Flattened','تمت التسوية'))}
  if(a=='fill'){hills().forEach(m=>{if(m.scale.y<st.lvl)m.scale.y=st.lvl});save();toast(tr('Filled','تم الملء'))}
  if(a=='sea'){st.sea=!st.sea;setSea();r()}});
 p.addEventListener('input',e=>{if(e.target.hasAttribute('data-sl')){st.lvl=parseFloat(e.target.value);e.target.nextElementSibling.textContent=st.lvl;setSea()}});
});

/* 3) ParticleEmitter */
guard('particles',()=>{
 const C={on:true,rate:60,life:6,speed:2,size:.5,col:'#ffc2dc',spread:40,h:25,grav:1.2};let pts=null,N=0,pos,vel,age;
 const p=addTab('pem','Particles','الجزيئات',r);
 function build(){if(pts){sc.remove(pts);pts.geometry.dispose()}N=Math.round(C.rate*C.life);pos=new Float32Array(N*3);vel=new Float32Array(N*3);age=new Float32Array(N);
  for(let i=0;i<N;i++){age[i]=Math.random()*C.life;respawn(i)}
  const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(pos,3));
  pts=new T.Points(g,new T.PointsMaterial({color:new T.Color(C.col),size:C.size,transparent:true,opacity:.9,depthWrite:false}));pts.frustumCulled=false;pts.userData={name:'ParticleEmitter',skip:true};pts.visible=C.on;sc.add(pts)}
 function respawn(i){pos[i*3]=(Math.random()-.5)*C.spread;pos[i*3+1]=C.h;pos[i*3+2]=(Math.random()-.5)*C.spread;vel[i*3]=(Math.random()-.5)*C.speed;vel[i*3+1]=-C.grav*(.5+Math.random());vel[i*3+2]=(Math.random()-.5)*C.speed;age[i]=0}
 let last=performance.now();(function loop(t){requestAnimationFrame(loop);const dt=Math.min(.05,(t-last)/1000);last=t;if(!pts||!C.on)return;
  for(let i=0;i<N;i++){age[i]+=dt;if(age[i]>C.life||pos[i*3+1]<0){respawn(i);continue}pos[i*3]+=vel[i*3]*dt+Math.sin(age[i]*2+i)*.3*dt;pos[i*3+1]+=vel[i*3+1]*dt;pos[i*3+2]+=vel[i*3+2]*dt}
  pts.geometry.attributes.position.needsUpdate=true})(last);
 const S=[['rate','Rate','المعدل',5,200,5],['life','Lifetime','العمر',1,12,.5],['speed','Speed','السرعة',0,10,.5],['size','Size','الحجم',.1,2,.1],['spread','Spread','الانتشار',5,120,5],['h','Height','الارتفاع',5,60,1],['grav','Gravity','الجاذبية',.2,6,.2]];
 function r(){p.innerHTML=`<div class="rw2">${btn('tg',C.on?'Enabled':'Disabled',C.on?'مفعّل':'معطّل',C.on?'on2':'')}${btn('pk','Sakura petals','بتلات ساكورا')}</div><div class="r"><label>${tr('Color','اللون')}</label><div class="v"><input type="color" data-c value="${C.col}"></div></div>`+
  S.map(s=>`<div class="r"><label>${tr(s[1],s[2])}</label><div class="v"><input type="range" data-k="${s[0]}" min="${s[3]}" max="${s[4]}" step="${s[5]}" value="${C[s[0]]}"><output>${C[s[0]]}</output></div></div>`).join('')}
 p.addEventListener('click',e=>{const a=e.target.dataset.a;if(a=='tg'){C.on=!C.on;if(pts)pts.visible=C.on;r()}if(a=='pk'){Object.assign(C,{col:'#ffc2dc',rate:60,life:6,speed:2,size:.5,spread:40,h:25,grav:1.2});build();r()}});
 p.addEventListener('input',e=>{const t=e.target;if(t.hasAttribute('data-c')){C.col=t.value;if(pts)pts.material.color.set(C.col);return}const k=t.dataset.k;if(!k)return;C[k]=parseFloat(t.value);t.nextElementSibling.textContent=C[k];if(k=='rate'||k=='life'||k=='h'||k=='spread')build();else if(k=='size'&&pts)pts.material.size=C.size});
 build();
});
})();
