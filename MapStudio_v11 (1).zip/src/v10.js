/* ===== v10 · Terrain brush · Device emulator · Game tree · UI designer · Scripts · Animation · Assets · Publish ===== */
(function(){
'use strict';
const T=R,isAr=()=>lang=='ar',tr=(en,ar)=>isAr()?ar:en;
const log=(m,ty)=>{try{window.MapStudioV9.log(m,ty)}catch(e){}};
const ls={g(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const clone=o=>JSON.parse(JSON.stringify(o));
const E=t=>String(t==null?'':t).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
const hexn=h=>parseInt(String(h).replace('#',''),16)||0;
const c3=h=>{const n=hexn(h);return[n>>16&255,n>>8&255,n&255]};
const rgba=(h,tp)=>{const c=c3(h);return'rgba('+c[0]+','+c[1]+','+c[2]+','+(1-tp)+')'};
const q=s=>JSON.stringify(String(s));
const uid=()=>'u'+Date.now().toString(36)+Math.random().toString(36).slice(2,6);
function guard(n,fn){try{fn()}catch(e){log('v10 '+n+': '+(e&&e.message||e),'e');try{console.error(e)}catch(_){}}}

/* ---------- per-map state ---------- */
const blank=()=>({ui:[],uiShow:false,scripts:[],pub:{name:'',desc:'',thumb:'',genre:'Adventure',maxp:12,priv:false,copy:false,dev:{phone:true,tablet:true,desktop:true,console:false}},anim:{dur:1.2,kf:[]}});
let S=blank();
const skey=()=>'ms10:'+MP.cur,saveS=()=>ls.s(skey(),S);
function loadS(){const d=ls.g(skey(),{}),b=blank();S=Object.assign(b,d);S.pub=Object.assign(blank().pub,d.pub||{});S.pub.dev=Object.assign(blank().pub.dev,(d.pub||{}).dev||{});S.anim=Object.assign(blank().anim,d.anim||{})}
guard('state',loadS);

/* ---------- CSS ---------- */
const st=document.createElement('style');st.textContent=`
#uiov{position:absolute;inset:0;pointer-events:none;overflow:hidden;display:none;z-index:4;container-type:size}
#uiov .ue{position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;text-align:center;overflow:hidden;white-space:nowrap;line-height:1.1}
#uiov .ue.sel{outline:2px dashed #2d9cff}
body.playing #uiov .ue.sel{outline:0}body.playing #uiov .ub{pointer-events:auto;cursor:pointer}
#devl{position:absolute;bottom:4px;left:50%;transform:translateX(-50%);font-size:11px;background:#000a;color:#fff;border-radius:10px;padding:2px 10px;pointer-events:none;z-index:6;white-space:nowrap}
#devl:empty{display:none}
.n .cn{margin-inline-start:auto;opacity:.6;font-size:11px}.n small{opacity:.55;margin-inline-start:6px}
.tq{padding:6px 8px;display:flex;flex-direction:column;gap:6px}
.tq textarea{height:190px;width:100%;box-sizing:border-box;font:12px/1.4 ui-monospace,Menlo,monospace;direction:ltr;text-align:left;white-space:pre;overflow:auto}
.tq textarea.sm{height:70px;white-space:pre-wrap;font:13px system-ui,sans-serif;direction:inherit;text-align:start}
.ai2{display:flex;align-items:center;gap:8px;padding:6px 8px;border-bottom:1px solid var(--b)}
.ai2 img{width:44px;height:44px;object-fit:cover;border-radius:4px;border:1px solid var(--b)}.ai2 .gr{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ai2 button{background:var(--p2);color:var(--t);border:1px solid var(--b);border-radius:4px;padding:5px 8px;font-size:12px}
.ck2{padding:3px 10px;font-size:12px}.ck2.ok{color:#3ecf5f}.ck2.no{color:#f0b429}
.thm{width:100%;max-height:120px;object-fit:cover;border-radius:6px;border:1px solid var(--b)}
`;document.head.appendChild(st);

/* ---------- tab helper ---------- */
const TABS=[];
function addTab(id,en,ar,render){const b=document.createElement('button');b.dataset.d=id;$('tabs').appendChild(b);const p=document.createElement('div');p.id=id;p.className='pn';$('pane').appendChild(p);
 b.onclick=()=>{const was=b.classList.contains('on');document.querySelectorAll('#tabs button').forEach(x=>x.classList.toggle('on',x==b));document.querySelectorAll('.pn').forEach(x=>x.classList.toggle('on',x.id==id));$('dock').classList.toggle('min',was&&!$('dock').classList.contains('min'));if(!was)try{render()}catch(e){log('v10 '+id+': '+e.message,'e')}};
 TABS.push({id,en,ar,b,p,render});b.textContent=tr(en,ar);return p}
function openTab(id){const b=document.querySelector('#tabs [data-d="'+id+'"]');if(!b)return;if(!b.classList.contains('on'))b.click();else $('dock').classList.remove('min')}
const labelTabs=()=>TABS.forEach(t=>t.b.textContent=tr(t.en,t.ar));
const renderAll=()=>TABS.forEach(t=>{try{t.render()}catch(e){log('v10 '+t.id+': '+e.message,'e')}});

/* =====================================================================
   1) TERRAIN BRUSH  (Raise · Lower · Smooth · Paint)
   ===================================================================== */
guard('terrain',()=>{
 const BR={tool:'off',size:10,str:.5,col:'#6aae55',mat:'Grass'};
 const p=addTab('ter','Terrain','التضاريس',rT);
 const TL=[['off','⏸','Off','إيقاف'],['raise','⛰','Raise','رفع'],['lower','🕳','Lower','خفض'],['smooth','≈','Smooth','تنعيم'],['paint','🎨','Paint','تلوين']];
 function rT(){p.innerHTML=`<div class="chips">${TL.map(t=>`<button data-bt="${t[0]}" class="${BR.tool==t[0]?'on':''}">${t[1]} ${tr(t[2],t[3])}</button>`).join('')}</div>
<div class="r"><label>${tr('Brush size','حجم الفرشاة')}</label><div class="v"><input type="range" data-bp="size" min="3" max="40" step="1" value="${BR.size}"><output>${BR.size}</output></div></div>
<div class="r"><label>${tr('Strength','القوة')}</label><div class="v"><input type="range" data-bp="str" min=".1" max="1" step=".05" value="${BR.str}"><output>${BR.str}</output></div></div>
<div class="r"><label>${tr('Color','اللون')}</label><div class="v"><input type="color" data-bp="col" value="${BR.col}"></div></div>
<div class="r"><label>${tr('Material','الخامة')}</label><div class="v"><select data-bp="mat">${Object.keys(MATS).map(m=>`<option${m==BR.mat?' selected':''}>${m}</option>`).join('')}</select></div></div>
<div class="nt">${tr('Tap the ground to apply the brush; drag to orbit. Raise / Lower / Smooth work on hills (Terrain_*). Paint recolors terrain parts. Raise on flat ground creates a new hill.','اضغط على الأرض لتطبيق الفرشاة، واسحب لتدوير الكاميرا. الرفع والخفض والتنعيم تعمل على التلال (Terrain_*)، والتلوين يغيّر ألوان أجزاء التضاريس. الرفع على أرض مسطحة ينشئ تلاً جديداً.')}</div>
<div class="rw2"><button data-bclr>${tr('Clear sculpted hills','مسح التلال المنحوتة')}</button></div>`}
 p.addEventListener('click',e=>{const b=e.target.closest('[data-bt]');if(b){BR.tool=b.dataset.bt;ring.visible=false;rT();return}
  if(e.target.closest('[data-bclr]')){const d=items.filter(m=>/^Terrain_Sculpt/.test(m.userData.name));d.forEach(rm);save();toast(tr('Removed','تم الحذف')+' '+d.length)}});
 p.addEventListener('input',e=>{const t=e.target,k=t.dataset.bp;if(!k)return;BR[k]=t.type=='range'?parseFloat(t.value):t.value;const o=t.parentElement.querySelector('output');if(o)o.textContent=BR[k]});
 const rm=m=>{sc.remove(m);const i=items.indexOf(m);if(i>=0)items.splice(i,1);sels.delete(m)};
 const hills=()=>items.filter(m=>m.userData.t=='ball'&&/^Terrain_(Hill|Sculpt)/.test(m.userData.name));
 const ring=new T.Mesh(new T.RingGeometry(.92,1,48),new T.MeshBasicMaterial({color:0xffffff,side:T.DoubleSide,transparent:true,opacity:.85,depthTest:false}));ring.rotation.x=-Math.PI/2;ring.renderOrder=30;ring.visible=false;sc.add(ring);
 function apply(h){const P=h.point,r=BR.size,s=BR.str,tool=BR.tool;let n=0;
  const near=(m,k)=>Math.hypot(m.position.x-P.x,m.position.z-P.z)<r+m.scale.x*k;
  if(tool=='raise'){const hs=hills().filter(m=>near(m,.4));
   if(hs.length)hs.forEach(m=>{m.scale.y+=s*3;m.scale.x+=s*.6;m.scale.z=m.scale.x;n++});
   else{const gy=/^Terrain_(Hill|Sculpt)/.test(h.object.userData.name||'')?h.object.position.y:P.y;
    mk('ball',{p:[P.x,gy,P.z],r:[0,0,0],s:[r*1.6,r*(.5+s),r*1.6],n:'Terrain_Sculpt'+Date.now().toString(36).slice(-4),c:hexn(BR.col),m:BR.mat});n=1}}
  else if(tool=='lower'){hills().filter(m=>near(m,.4)).forEach(m=>{m.scale.y-=s*3;if(m.scale.y<1)rm(m);n++})}
  else if(tool=='smooth'){const hs=hills().filter(m=>near(m,.5));if(hs.length){const av=hs.reduce((a,m)=>a+m.scale.y,0)/hs.length;hs.forEach(m=>{m.scale.y+=(av-m.scale.y)*s*.7;if(hs.length==1)m.scale.y*=1-s*.15;m.scale.x*=1+s*.08;m.scale.z=m.scale.x;n++})}}
  else if(tool=='paint'){items.filter(m=>/^Terrain_/.test(m.userData.name)&&near(m,.5)).forEach(m=>{m.material.color.set(BR.col);m.userData.mat=BR.mat;look(m);n++})}
  if(n){save();toast('✓ '+tr(TL.find(x=>x[0]==tool)[2],TL.find(x=>x[0]==tool)[3])+' · '+n)}else toast(tr('Nothing in range here','لا يوجد شيء ضمن النطاق'))}
 const act=()=>BR.tool!='off'&&!document.body.classList.contains('playing');
 const hitAt=e=>{aim(e);return ray.intersectObjects([...items,base],false)[0]};
 const dn=new Map();let multi2=false;
 cv.addEventListener('pointerdown',e=>{if(!act())return;dn.set(e.pointerId,{x:e.clientX,y:e.clientY});if(dn.size>1)multi2=true},true);
 cv.addEventListener('pointermove',e=>{if(!act()){ring.visible=false;return}if(dn.size)return;const h=hitAt(e);if(h){ring.visible=true;ring.position.set(h.point.x,h.point.y+.15,h.point.z);ring.scale.setScalar(BR.size)}else ring.visible=false},true);
 const up=e=>{const d=dn.get(e.pointerId);dn.delete(e.pointerId);if(!d||dn.size)return;const tap=!multi2&&Math.hypot(e.clientX-d.x,e.clientY-d.y)<8;multi2=false;
  if(tap&&act()){const h=hitAt(e);if(h){apply(h);setTimeout(()=>select(null),0)}}};
 cv.addEventListener('pointerup',up,true);cv.addEventListener('pointercancel',e=>{dn.delete(e.pointerId);if(!dn.size)multi2=false},true);
 window.MapStudioV10=window.MapStudioV10||{};window.MapStudioV10.brush=BR;
});

/* =====================================================================
   2) DEVICE EMULATOR
   ===================================================================== */
guard('device',()=>{
 const DV=[['full','Full screen','ملء الشاشة',0,0],['phone','Phone ▯ 390×844','هاتف عمودي',390,844],['phoneL','Phone ▭ 844×390','هاتف أفقي',844,390],['tab','Tablet ▯ 820×1180','تابلت عمودي',820,1180],['tabL','Tablet ▭ 1180×820','تابلت أفقي',1180,820],['lap','Laptop 1366×768','لابتوب',1366,768],['tv','Console / TV 1920×1080','كونسول / تلفاز',1920,1080]];
 const g=document.createElement('div');g.className='g';g.innerHTML='<div class="lb"><span id="devt"></span><select id="dev"></select></div>';$('rib').appendChild(g);
 const lab=document.createElement('div');lab.id='devl';$('vp').appendChild(lab);
 const fill=()=>{$('devt').textContent=tr('Device','الجهاز');const v=$('dev').value||ls.g('ms_dev','full');$('dev').innerHTML=DV.map(d=>`<option value="${d[0]}"${d[0]==v?' selected':''}>${tr(d[1],d[2]+(d[3]?' '+d[3]+'×'+d[4]:''))}</option>`).join('')};
 fill();
 let raf=0;const fit=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(doFit)};
 function doFit(){const v=$('vp'),m=$('main'),dk=$('dock'),d=DV.find(x=>x[0]==$('dev').value);v.style.cssText='';m.style.background='';lab.textContent='';
  if(!d||!d[3])return;
  const col=matchMedia('(max-width:800px)').matches,dkv=dk.offsetParent!==null;
  const aw=m.clientWidth-(!col&&dkv?dk.offsetWidth:0),ah=m.clientHeight-(col&&dkv?dk.offsetHeight:0);
  const k=Math.min(aw/d[3],ah/d[4],1),w=Math.max(120,Math.floor(d[3]*k)),h=Math.max(120,Math.floor(d[4]*k));
  v.style.flex='none';v.style.width=w+'px';v.style.height=h+'px';v.style.margin='auto';v.style.outline='2px solid var(--ac)';m.style.background='#0c0c0e';
  lab.textContent=tr(d[1],d[2])+(k<1?' · '+Math.round(k*100)+'%':'')}
 $('dev').onchange=()=>{ls.s('ms_dev',$('dev').value);fit()};
 new ResizeObserver(fit).observe($('main'));new ResizeObserver(fit).observe($('dock'));addEventListener('resize',fit);
 new MutationObserver(fit).observe(document.body,{attributes:true,attributeFilter:['class']});
 fit();
 window.MapStudioV10=window.MapStudioV10||{};window.MapStudioV10.deviceRefresh=()=>{fill();fit()};
});

/* =====================================================================
   3) SCRIPTS  (Script · LocalScript · ModuleScript)
   ===================================================================== */
const SCK={Script:['⚙','ServerScriptService'],LocalScript:['🏃','StarterPlayerScripts'],ModuleScript:['📦','ReplicatedStorage']};
let SCSEL=null;
guard('scripts',()=>{
 const p=addTab('scr','Scripts','السكربتات',rS);
 const TPL=[
 ['blank','Blank','فارغ','Script','-- '+'Write your Luau code here\nprint("Hello from Map Studio")\n'],
 ['gate','Gate teleport','بوابة انتقال','Script','-- Put two parts in the map: "Gate" and "Target".\n-- A player touching the Gate is moved to the Target.\nlocal gate = workspace:WaitForChild("Gate", 10)\nlocal target = workspace:WaitForChild("Target", 10)\nif gate and target then\n\tgate.Touched:Connect(function(hit)\n\t\tlocal char = hit:FindFirstAncestorOfClass("Model")\n\t\tif char and char:FindFirstChildOfClass("Humanoid") then\n\t\t\tchar:PivotTo(target.CFrame + Vector3.new(0, 5, 0))\n\t\tend\n\tend)\nend\n'],
 ['coin','Coin collector','جمع العملات','Script','-- Every part named "Coin" gives +1 and disappears.\nlocal Players = game:GetService("Players")\nPlayers.PlayerAdded:Connect(function(plr)\n\tlocal ls = Instance.new("Folder") ls.Name = "leaderstats" ls.Parent = plr\n\tlocal c = Instance.new("IntValue") c.Name = "Coins" c.Parent = ls\nend)\nfor _, d in ipairs(workspace:GetDescendants()) do\n\tif d:IsA("BasePart") and d.Name == "Coin" then\n\t\tlocal used = false\n\t\td.Touched:Connect(function(hit)\n\t\t\tlocal plr = Players:GetPlayerFromCharacter(hit.Parent)\n\t\t\tif plr and not used then\n\t\t\t\tused = true\n\t\t\t\tplr.leaderstats.Coins.Value += 1\n\t\t\t\td:Destroy()\n\t\t\tend\n\t\tend)\n\tend\nend\n'],
 ['door','Door (ProximityPrompt)','باب بالضغط','Script','-- Part named "Door" with a ProximityPrompt: toggles open/closed.\nlocal door = workspace:WaitForChild("Door", 10)\nif door then\n\tlocal pp = door:FindFirstChildOfClass("ProximityPrompt") or Instance.new("ProximityPrompt", door)\n\tpp.ActionText = "Open"\n\tlocal open = false\n\tpp.Triggered:Connect(function()\n\t\topen = not open\n\t\tdoor.CanCollide = not open\n\t\tdoor.Transparency = open and 0.7 or 0\n\tend)\nend\n'],
 ['welcome','Welcome message','رسالة ترحيب','LocalScript','-- Shows a message for 4 seconds when the player joins.\nlocal gui = Instance.new("ScreenGui")\ngui.ResetOnSpawn = false\ngui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")\nlocal l = Instance.new("TextLabel")\nl.Size = UDim2.fromScale(0.5, 0.1) l.Position = UDim2.fromScale(0.25, 0.05)\nl.BackgroundTransparency = 0.3 l.TextScaled = true l.Text = "Welcome to the map!"\nl.Parent = gui\ntask.delay(4, function() gui:Destroy() end)\n'],
 ['module','Module (shared helpers)','موديول مشترك','ModuleScript','local M = {}\n\nfunction M.round(n, d)\n\tlocal m = 10 ^ (d or 0)\n\treturn math.floor(n * m + 0.5) / m\nend\n\nreturn M\n']];
 function rS(){const sel=S.scripts.find(s=>s.id==SCSEL);
  p.innerHTML=`<div class="chips">${Object.keys(SCK).map(k=>`<button data-sn="${k}">＋ ${SCK[k][0]} ${k}</button>`).join('')}</div>
<div class="r"><label>${tr('Template','قالب')}</label><div class="v"><select id="sctp">${TPL.map(t=>`<option value="${t[0]}">${tr(t[1],t[2])} (${t[3]})</option>`).join('')}</select><button class="sb" data-stp>${tr('Add','إضافة')}</button></div></div>
${S.scripts.length?'':`<div class="em">${tr('No scripts yet. Add one above. They are exported to ServerScriptService / StarterPlayerScripts / ReplicatedStorage.','لا توجد سكربتات. أضف واحداً من الأعلى، وتُصدَّر إلى ServerScriptService وStarterPlayerScripts وReplicatedStorage.')}</div>`}
${S.scripts.map(s=>`<div class="n c${s.id==SCSEL?' s':''}" data-si="${s.id}"><span>${SCK[s.k][0]}</span><span class="nm">${E(s.name)}</span><small>${s.k}</small><span class="cn"><button class="sb" data-sx="${s.id}">✕</button></span></div>`).join('')}
${sel?`<div class="tq"><div class="r" style="padding:0"><label>${tr('Name','الاسم')}</label><div class="v"><input type="text" id="scnm" value="${E(sel.name)}"></div></div>
<textarea id="scsrc" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" wrap="off">${E(sel.src)}</textarea>
<div class="rw2" style="padding:0"><button data-srun>▶ ${tr('Test run in editor','تجربة في المحرر')}</button></div><div class="nt" id="scout" style="padding:0"></div></div>`:''}`}
 p.addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-sn]')){const k=b.dataset.sn,n=S.scripts.filter(s=>s.k==k).length+1,s={id:uid(),k,name:k+n,src:'-- '+k+'\n'};S.scripts.push(s);SCSEL=s.id;saveS();rS();sync();return}
  if(e.target.closest('[data-stp]')){const t=TPL.find(x=>x[0]==$('sctp').value),s={id:uid(),k:t[3],name:t[1].replace(/[^\w]+/g,''),src:t[4]};S.scripts.push(s);SCSEL=s.id;saveS();rS();sync();return}
  if(b=e.target.closest('[data-sx]')){S.scripts=S.scripts.filter(s=>s.id!=b.dataset.sx);if(SCSEL==b.dataset.sx)SCSEL=null;saveS();rS();sync();e.stopPropagation();return}
  if(b=e.target.closest('[data-si]')){SCSEL=b.dataset.si;rS();return}
  if(e.target.closest('[data-srun]')){const s=S.scripts.find(x=>x.id==SCSEL);if(!s)return;let r;try{r=LuaImp.run(s.src,{maxParts:2000,maxMs:3000})}catch(x){r={parts:[],log:[],error:{msg:String(x.message||x),line:0}}}
   const o=$('scout');const lines=(r.log||[]).slice(0,20).join('\n');
   o.textContent=(r.error?'✗ '+tr('Line','سطر')+' '+r.error.line+': '+r.error.msg+'\n'+tr('(Game scripts run only inside Roblox; the editor runs scripts that build parts.)','(سكربتات اللعب تعمل داخل Roblox فقط، والمحرر يشغّل السكربتات التي تبني قطعاً.)'):'✓ '+tr('Ran without errors','نُفّذ بدون أخطاء'))+(r.parts.length?'\n'+r.parts.length+' '+tr('parts built','قطعة'):'')+(lines?'\n'+lines:'');
   r.log&&r.log.forEach(l=>log(l));if(r.error)log('Script '+s.name+' line '+r.error.line+': '+r.error.msg,'w');
   if(r.parts.length){r.parts.forEach(a=>mk(a.t,a));save();toast('✓ '+r.parts.length+' '+tr('parts added','قطعة أُضيفت'))}}});
 p.addEventListener('input',e=>{const s=S.scripts.find(x=>x.id==SCSEL);if(!s)return;if(e.target.id=='scsrc')s.src=e.target.value;else if(e.target.id=='scnm'){s.name=e.target.value.slice(0,40)||s.k;const r=p.querySelector('[data-si="'+s.id+'"] .nm');if(r)r.textContent=s.name}saveS()});
});

/* =====================================================================
   4) UI DESIGNER  (StarterGui)
   ===================================================================== */
let UISEL=null;const UIH={};
guard('ui',()=>{
 const p=addTab('ui','UI','الواجهات',rU);
 const ov=document.createElement('div');ov.id='uiov';$('vp').appendChild(ov);
 const isPlay=()=>document.body.classList.contains('playing');
 const DEFU={Frame:{k:'Frame',name:'Frame',text:'',x:30,y:30,w:40,h:30,bg:'#1e1e20',fg:'#ffffff',fs:4,r:12,bt:.15,a:'none',tg:''},TextLabel:{k:'TextLabel',name:'Label',text:'Text',x:35,y:5,w:30,h:8,bg:'#000000',fg:'#ffffff',fs:4,r:10,bt:.4,a:'none',tg:''},TextButton:{k:'TextButton',name:'Button',text:'Button',x:40,y:80,w:20,h:9,bg:'#e8789f',fg:'#ffffff',fs:4,r:14,bt:0,a:'none',tg:''}};
 const mkU=(k,o)=>Object.assign({id:uid()},clone(DEFU[k]),o||{});
 const PRE=[['menu','Start menu','قائمة البداية',()=>[mkU('Frame',{name:'StartMenu',x:25,y:20,w:50,h:60,bg:'#2b1d2f',bt:.1,r:20}),mkU('TextLabel',{name:'Title',text:'Sakura World 🌸',x:30,y:26,w:40,h:14,bt:1,fs:7}),mkU('TextButton',{name:'PlayBtn',text:'▶ Play',x:36,y:52,w:28,h:12,a:'hide',tg:'StartMenu',fs:5})]],
  ['coins','Coins bar','شريط العملات',()=>[mkU('TextLabel',{name:'Coins',text:'🪙 0',x:78,y:3,w:19,h:8,bg:'#000000',bt:.35,fs:5,r:16})]],
  ['worlds','World buttons','أزرار العوالم',()=>[['Sakura','#e8789f'],['Forest','#3f8a45'],['Night','#4a5cc7']].map((w,i)=>mkU('TextButton',{name:'World'+(i+1),text:w[0],x:12+i*29,y:86,w:24,h:9,bg:w[1],a:'teleport',tg:'Torii'}))],
  ['msg','Message','رسالة',()=>[mkU('TextLabel',{name:'Message',text:'Welcome! 🌸',x:25,y:84,w:50,h:9,fs:5})]]];
 const list=()=>S.ui.map(u=>`<div class="n c${u.id==UISEL?' s':''}" data-ui="${u.id}"><span>${u.k=='TextButton'?'🔘':u.k=='TextLabel'?'🔤':'▭'}</span><span class="nm">${E(u.name)}</span><span class="cn"><button class="sb" data-ux="${u.id}">✕</button></span></div>`).join('');
 const nf=(f,lab,mn,mx,st,u)=>`<div class="r"><label>${lab}</label><div class="v"><input type="number" data-uf="${f}" min="${mn}" max="${mx}" step="${st}" value="${u[f]}"></div></div>`;
 function rU(){const u=S.ui.find(x=>x.id==UISEL);
  p.innerHTML=`<div class="r"><label>${tr('Preview','معاينة')}</label><input type="checkbox" id="uishow"${S.uiShow?' checked':''}><span class="nt" style="padding:0">${tr('Always shown while playing','تظهر دائماً أثناء التجربة')}</span></div>
<div class="sec">${tr('Presets','قوالب جاهزة')}</div><div class="chips">${PRE.map(x=>`<button data-up="${x[0]}">＋ ${tr(x[1],x[2])}</button>`).join('')}</div>
<div class="sec">${tr('Add element','إضافة عنصر')}</div><div class="chips"><button data-uk="Frame">▭ Frame</button><button data-uk="TextLabel">🔤 TextLabel</button><button data-uk="TextButton">🔘 TextButton</button></div>
<div class="sec">StarterGui · ${S.ui.length}</div>${S.ui.length?list():`<div class="em">${tr('No UI yet. Tap a preset or add an element.','لا توجد واجهات. اختر قالباً أو أضف عنصراً.')}</div>`}
${u?`<div class="sec">${tr('Properties','الخصائص')}</div>
<div class="r"><label>${tr('Name','الاسم')}</label><div class="v"><input type="text" data-uf="name" value="${E(u.name)}"></div></div>
${u.k!='Frame'?`<div class="r"><label>${tr('Text','النص')}</label><div class="v"><input type="text" data-uf="text" value="${E(u.text)}"></div></div>`:''}
${nf('x','X %',-50,100,1,u)}${nf('y','Y %',-50,100,1,u)}${nf('w',tr('Width %','العرض %'),1,100,1,u)}${nf('h',tr('Height %','الارتفاع %'),1,100,1,u)}
<div class="r"><label>${tr('Background','الخلفية')}</label><div class="v"><input type="color" data-uf="bg" value="${u.bg}"></div></div>
${nf('bt',tr('Transparency','الشفافية'),0,1,.05,u)}
${u.k!='Frame'?`<div class="r"><label>${tr('Text color','لون النص')}</label><div class="v"><input type="color" data-uf="fg" value="${u.fg}"></div></div>${nf('fs',tr('Text size','حجم النص'),1,20,.5,u)}`:''}
${nf('r',tr('Corner px','تدوير px'),0,60,1,u)}
${u.k=='TextButton'?`<div class="r"><label>${tr('On tap','عند الضغط')}</label><div class="v"><select data-uf="a"><option value="none"${u.a=='none'?' selected':''}>${tr('Nothing','لا شيء')}</option><option value="teleport"${u.a=='teleport'?' selected':''}>${tr('Teleport to part','انتقال إلى قطعة')}</option><option value="hide"${u.a=='hide'?' selected':''}>${tr('Hide element','إخفاء عنصر')}</option></select></div></div>
<div class="r"><label>${tr('Target name','اسم الهدف')}</label><div class="v"><input type="text" data-uf="tg" value="${E(u.tg)}" placeholder="${tr('part or element name','اسم قطعة أو عنصر')}"></div></div>`:''}`:''}`}
 function updOv(){const show=(S.uiShow||isPlay())&&S.ui.length;ov.style.display=show?'block':'none';if(!show){ov.innerHTML='';return}
  ov.innerHTML=S.ui.filter(u=>!(isPlay()&&UIH[u.id])).map(u=>`<div class="ue${u.k=='TextButton'?' ub':''}${u.id==UISEL&&!isPlay()?' sel':''}" data-uid="${u.id}" style="left:${u.x}%;top:${u.y}%;width:${u.w}%;height:${u.h}%;background:${rgba(u.bg,u.bt)};color:${u.fg};border-radius:${u.r}px;font-size:${u.fs}cqmin">${E(u.text)}</div>`).join('')}
 window.MapStudioV10=window.MapStudioV10||{};window.MapStudioV10.updOv=updOv;
 p.addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-up]')){const pr=PRE.find(x=>x[0]==b.dataset.up),a=pr[3]();S.ui.push(...a);UISEL=a[0].id;saveS();rU();updOv();sync();return}
  if(b=e.target.closest('[data-uk]')){const u=mkU(b.dataset.uk);u.name=u.k.replace('Text','')+(S.ui.length+1);S.ui.push(u);UISEL=u.id;saveS();rU();updOv();sync();return}
  if(b=e.target.closest('[data-ux]')){S.ui=S.ui.filter(u=>u.id!=b.dataset.ux);if(UISEL==b.dataset.ux)UISEL=null;saveS();rU();updOv();sync();e.stopPropagation();return}
  if(b=e.target.closest('[data-ui]')){UISEL=b.dataset.ui;rU();updOv()}});
 p.addEventListener('input',e=>{const t=e.target;if(t.id=='uishow'){S.uiShow=t.checked;saveS();updOv();return}
  const f=t.dataset.uf,u=S.ui.find(x=>x.id==UISEL);if(!f||!u)return;u[f]=t.type=='number'?(parseFloat(t.value)||0):t.value;
  if(f=='name'){const r=p.querySelector('[data-ui="'+u.id+'"] .nm');if(r)r.textContent=u.name}
  saveS();updOv()});
 ov.addEventListener('click',e=>{if(!isPlay())return;const el=e.target.closest('.ub');if(!el)return;const u=S.ui.find(x=>x.id==el.dataset.uid);if(!u||!u.a||u.a=='none')return;
  if(u.a=='hide'){const t=S.ui.find(x=>x.name.toLowerCase()==String(u.tg).toLowerCase());if(t){UIH[t.id]=true;updOv()}return}
  if(u.a=='teleport'){const PL=window.MapStudioV9&&window.MapStudioV9.PL,tg0=String(u.tg).toLowerCase();if(!PL||!tg0)return;
   const t=items.find(m=>m.userData.name.toLowerCase()==tg0)||items.find(m=>m.userData.name.toLowerCase().includes(tg0));if(!t){toast(tr('Target not found: ','الهدف غير موجود: ')+u.tg);return}
   const bb=new T.Box3().setFromObject(t);PL.pos.set(t.position.x,bb.max.y+.1,t.position.z);PL.vy=0}});
 let wasPlay=false;new MutationObserver(()=>{const pl=isPlay();if(pl!=wasPlay){wasPlay=pl;if(!pl)Object.keys(UIH).forEach(k=>delete UIH[k]);updOv()}}).observe(document.body,{attributes:true,attributeFilter:['class']});
 window.MapStudioV10.uiRender=()=>{updOv()};
 updOv();
});

/* =====================================================================
   5) ANIMATION EDITOR  (preview rig · presets · keyframes · Luau export)
   ===================================================================== */
guard('anim',()=>{
 const p=addTab('anm','Animation','الحركات',rA);
 const KEYS=[['la','Left arm','الذراع اليسرى',-180,180],['ra','Right arm','الذراع اليمنى',-180,180],['ll','Left leg','الساق اليسرى',-90,90],['rl','Right leg','الساق اليمنى',-90,90],['lz','Left arm out','فتح الذراع اليسرى',-90,90],['rz','Right arm out','فتح الذراع اليمنى',-90,90],['hd','Head turn','دوران الرأس',-60,60],['ty','Body turn','دوران الجسم',-60,60],['by','Height','الارتفاع',-2,2]];
 const D2R=Math.PI/180,sn=Math.sin;
 const PRES={
  walk:t=>{const s=sn(t*8)*45;return{la:s,ra:-s,ll:-s,rl:s,by:Math.abs(Math.cos(t*8))*.12}},
  run:t=>{const s=sn(t*12)*65;return{la:s,ra:-s,ll:-s,rl:s,by:Math.abs(Math.cos(t*12))*.3,ty:sn(t*12)*6}},
  dance:t=>({la:-150+sn(t*6)*25,ra:-150-sn(t*6)*25,lz:-20,rz:20,ll:sn(t*6)*18,rl:-sn(t*6)*18,ty:sn(t*3)*28,by:Math.abs(sn(t*6))*.5}),
  sit:t=>({ll:-90,rl:-90,la:-25,ra:-25,by:-1.2}),
  wave:t=>({ra:-170,rz:sn(t*8)*25,hd:sn(t*2)*12,la:5}),
  celebrate:t=>({la:-165,ra:-165,lz:-15,rz:15,by:Math.abs(sn(t*5))*1.6,ll:-8,rl:8})};
 const PN={walk:['Walk','مشي'],run:['Run','ركض'],dance:['Dance','رقص'],sit:['Sit','جلوس'],wave:['Wave','تحية'],celebrate:['Celebrate','احتفال'],custom:['Custom','مخصص']};
 let rig=null,on=false,mode='walk',playing=false,speed=1,t0=0,CP={},TM=0,sel=-1;KEYS.forEach(k=>CP[k[0]]=0);
 function mkRig(){const g=new T.Group(),M=c=>new T.MeshStandardMaterial({color:c,flatShading:true}),B=(w,h,d,c,x,y,z,par)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),M(c));m.position.set(x,y,z);m.castShadow=true;(par||g).add(m);return m};
  const sk=0xf5cd9a;B(2,2,1,0x0d69ac,0,3,0);const head=new T.Group();head.position.set(0,4,0);B(1.2,1.2,1.2,sk,0,.6,0,head);B(.2,.25,.1,0x111111,-.3,.7,.62,head);B(.2,.25,.1,0x111111,.3,.7,.62,head);g.add(head);
  const lim=(x,y,c)=>{const q2=new T.Group();q2.position.set(x,y,0);B(1,2,1,c,0,-1,0,q2);g.add(q2);return q2};
  return{g,head,la:lim(-1.5,4,sk),ra:lim(1.5,4,sk),ll:lim(-.5,2,0x4b974b),rl:lim(.5,2,0x4b974b)}}
 function groundAt(x,z){const r=new T.Raycaster(new T.Vector3(x,800,z),new T.Vector3(0,-1,0)),h=r.intersectObjects([...items,base],false)[0];return h?Math.max(0,h.point.y):0}
 let by0=0;
 function showRig(v){on=v;if(v&&!rig){rig=mkRig()}if(v){rig.g.position.set(Math.round(tg.x),groundAt(tg.x,tg.z),Math.round(tg.z));by0=rig.g.position.y;rig.g.rotation.y=Math.PI;sc.add(rig.g);pose(poseNow(0))}else if(rig)sc.remove(rig.g)}
 function pose(P){if(!rig)return;const g=(k)=>P[k]||0;rig.la.rotation.set(g('la')*D2R,0,g('lz')*D2R);rig.ra.rotation.set(g('ra')*D2R,0,g('rz')*D2R);rig.ll.rotation.x=g('ll')*D2R;rig.rl.rotation.x=g('rl')*D2R;rig.head.rotation.y=g('hd')*D2R;rig.g.rotation.y=Math.PI+g('ty')*D2R;rig.g.position.y=by0+g('by')}
 function lerpP(a,b,k){const o={};KEYS.forEach(x=>o[x[0]]=(a[x[0]]||0)+((b[x[0]]||0)-(a[x[0]]||0))*k);return o}
 function custom(t){const kf=S.anim.kf.slice().sort((a,b)=>a.t-b.t);if(!kf.length)return CP;if(kf.length==1)return kf[0].pose;const d=S.anim.dur,tt=((t%d)+d)%d;
  for(let i=0;i<kf.length;i++){const a=kf[i],b=kf[i+1]||{t:kf[0].t+d,pose:kf[0].pose};if(tt>=a.t&&tt<b.t||i==kf.length-1){const sp=b.t-a.t||1;return lerpP(a.pose,b.pose,Math.min(1,Math.max(0,(((tt<a.t?tt+d:tt))-a.t)/sp)))}}return kf[0].pose}
 function poseNow(t){return mode=='custom'?custom(t):PRES[mode](t)}
 function tick(){if(!on||!rig)return;const t=playing?((performance.now()-t0)/1000)*speed:TM;if(playing||mode!='custom')pose(poseNow(playing?t:0))}
 const _r=ren.render;ren.render=function(s,c){if(s===sc&&c===cam)try{tick()}catch(e){}return _r.apply(ren,arguments)};
 function rA(){const kf=S.anim.kf.slice().sort((a,b)=>a.t-b.t);
  p.innerHTML=`<div class="r"><label>${tr('Preview rig','نموذج المعاينة')}</label><input type="checkbox" id="anon"${on?' checked':''}><span class="nt" style="padding:0">${tr('Placed at camera focus','يوضع عند مركز الكاميرا')}</span></div>
<div class="chips">${Object.keys(PN).map(k=>`<button data-am="${k}" class="${mode==k?'on':''}">${tr(PN[k][0],PN[k][1])}</button>`).join('')}</div>
<div class="rw2"><button data-ap class="on2">${playing?'■ '+tr('Stop','إيقاف'):'▶ '+tr('Play','تشغيل')}</button></div>
<div class="r"><label>${tr('Speed','السرعة')}</label><div class="v"><input type="range" data-asp min=".25" max="3" step=".05" value="${speed}"><output>${speed}</output></div></div>
${mode=='custom'?`<div class="sec">${tr('Pose','الوضعية')}</div>${KEYS.map(k=>`<div class="r"><label>${tr(k[1],k[2])}</label><div class="v"><input type="range" data-ak="${k[0]}" min="${k[3]}" max="${k[4]}" step="${k[0]=='by'?.05:1}" value="${CP[k[0]]}"><output>${CP[k[0]]}</output></div></div>`).join('')}
<div class="r"><label>${tr('Length (s)','المدة (ث)')}</label><div class="v"><input type="number" id="andur" min=".2" max="10" step=".1" value="${S.anim.dur}"></div></div>
<div class="r"><label>${tr('Time (s)','الزمن (ث)')}</label><div class="v"><input type="range" id="antm" min="0" max="${S.anim.dur}" step=".05" value="${Math.min(TM,S.anim.dur)}"><output>${fmt(TM)}</output></div></div>
<div class="rw2"><button data-aadd>＋ ${tr('Keyframe at this time','مفتاح عند هذا الزمن')}</button></div>
${kf.map((k,i)=>`<div class="n c" data-akf="${i}"><span>🔑</span>${fmt(k.t)}s<span class="cn"><button class="sb" data-adel="${i}">✕</button></span></div>`).join('')}`:''}
<div class="rw2"><button data-aex>⇪ ${tr('Export Luau (R6)','تصدير Luau (R6)')}</button></div><div class="nt">${tr('Preview only inside the editor. The exported script animates an R6 character with Motor6D joints.','المعاينة داخل المحرر فقط. السكربت المُصدَّر يحرّك شخصية R6 عبر مفاصل Motor6D.')}</div>`}
 const fmt=v=>(+v).toFixed(2).replace(/\.?0+$/,'')||'0';
 const kfs=()=>S.anim.kf;
 p.addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-am]')){mode=b.dataset.am;if(mode=='custom'&&on)pose(poseNow(TM));rA();return}
  if(e.target.closest('[data-ap]')){if(!on){$('anon')&&($('anon').checked=true);showRig(true)}playing=!playing;t0=performance.now();if(!playing)pose(poseNow(0));rA();return}
  if(e.target.closest('[data-aadd]')){const k=kfs();const t=+(Math.min(TM,S.anim.dur)).toFixed(2);const i=k.findIndex(x=>Math.abs(x.t-t)<.01);const o={t,pose:Object.assign({},CP)};if(i>=0)k[i]=o;else k.push(o);saveS();rA();return}
  if(b=e.target.closest('[data-adel]')){const s2=S.anim.kf.slice().sort((a,c)=>a.t-c.t);const t=s2[+b.dataset.adel];S.anim.kf=S.anim.kf.filter(x=>x!==t&&!(x.t==t.t));saveS();rA();e.stopPropagation();return}
  if(b=e.target.closest('[data-akf]')){const s2=S.anim.kf.slice().sort((a,c)=>a.t-c.t),k=s2[+b.dataset.akf];if(k){CP=Object.assign({},CP,k.pose);TM=k.t;rA();pose(CP)}return}
  if(e.target.closest('[data-aex]')){const lua=exportAnim();navigator.clipboard&&navigator.clipboard.writeText(lua).then(()=>toast('✓ '+tr('Luau copied','تم نسخ Luau')),()=>{});log('Animation script exported ('+lua.length+' chars)')}});
 p.addEventListener('input',e=>{const t=e.target;
  if(t.id=='anon'){showRig(t.checked);return}
  if(t.dataset.asp!==undefined){speed=parseFloat(t.value);t.parentElement.querySelector('output').textContent=speed;return}
  if(t.dataset.ak){CP[t.dataset.ak]=parseFloat(t.value);t.parentElement.querySelector('output').textContent=CP[t.dataset.ak];if(on&&!playing)pose(CP);return}
  if(t.id=='andur'){S.anim.dur=Math.max(.2,parseFloat(t.value)||1);saveS();return}
  if(t.id=='antm'){TM=parseFloat(t.value);t.parentElement.querySelector('output').textContent=fmt(TM);if(on&&!playing&&mode=='custom'&&S.anim.kf.length)pose(custom(TM));return}});
 function exportAnim(){const kf=mode=='custom'&&S.anim.kf.length?S.anim.kf.slice().sort((a,b)=>a.t-b.t):null;
  let o='-- Map Studio animation (R6). Put in StarterCharacterScripts as a LocalScript.\nlocal char=script.Parent\nlocal hum=char:WaitForChild("Humanoid")\nlocal torso=char:WaitForChild("Torso")\nlocal root=char:WaitForChild("HumanoidRootPart")\nlocal anim=char:FindFirstChild("Animate") if anim then anim.Enabled=false end\nfor _,t in ipairs(hum:GetPlayingAnimationTracks()) do t:Stop() end\n';
  o+='local J={la=torso:WaitForChild("Left Shoulder"),ra=torso:WaitForChild("Right Shoulder"),ll=torso:WaitForChild("Left Hip"),rl=torso:WaitForChild("Right Hip"),hd=torso:WaitForChild("Neck")}\nlocal C0={} for k,j in pairs(J) do C0[k]=j.C0 end\nlocal rad=math.rad\n';
  if(kf){o+='local DUR='+S.anim.dur+'\nlocal KF={\n'+kf.map(k=>'\t{t='+k.t+',p={'+KEYS.map(x=>x[0]+'='+(k.pose[x[0]]||0)).join(',')+'}},').join('\n')+'\n}\n';
   o+='local function lerp(a,b,k) return a+(b-a)*k end\nlocal function sample(t)\n\tt=t%DUR\n\tfor i=1,#KF do\n\t\tlocal a,b=KF[i],KF[i+1] or {t=KF[1].t+DUR,p=KF[1].p}\n\t\tlocal tt=t<a.t and t+DUR or t\n\t\tif tt>=a.t and tt<b.t then\n\t\t\tlocal k=(tt-a.t)/math.max(b.t-a.t,1e-3) local o={}\n\t\t\tfor n,v in pairs(a.p) do o[n]=lerp(v,b.p[n] or 0,k) end\n\t\t\treturn o\n\t\tend\n\tend\n\treturn KF[#KF].p\nend\n'}
  else{const fx=PRES[mode]===undefined?PRES.walk:PRES[mode];const pts=[];for(let i=0;i<24;i++){const t=i/24*(mode=='walk'?Math.PI*2/8:mode=='run'?Math.PI*2/12:mode=='dance'?Math.PI*2/3:mode=='wave'?Math.PI*2/2:Math.PI*2/5);pts.push({t:+(i/24*1).toFixed(3),pose:fx(t)})}
   o+='local DUR=1\nlocal KF={\n'+pts.map(k=>'\t{t='+k.t+',p={'+KEYS.map(x=>x[0]+'='+(+(k.pose[x[0]]||0).toFixed(2))).join(',')+'}},').join('\n')+'\n}\nlocal function sample(t)\n\tt=t%DUR\n\tlocal i=math.clamp(math.floor(t*#KF)+1,1,#KF)\n\treturn KF[i].p\nend\n'}
  o+='local t0=os.clock()\ngame:GetService("RunService").RenderStepped:Connect(function()\n\tlocal P=sample(os.clock()-t0)\n\tJ.la.C0=C0.la*CFrame.Angles(rad(P.la or 0),0,rad(P.lz or 0))\n\tJ.ra.C0=C0.ra*CFrame.Angles(rad(P.ra or 0),0,rad(P.rz or 0))\n\tJ.ll.C0=C0.ll*CFrame.Angles(rad(P.ll or 0),0,0)\n\tJ.rl.C0=C0.rl*CFrame.Angles(rad(P.rl or 0),0,0)\n\tJ.hd.C0=C0.hd*CFrame.Angles(0,rad(P.hd or 0),0)\nend)\n';return o}
 window.MapStudioV10=window.MapStudioV10||{};window.MapStudioV10.exportAnim=exportAnim;
});

/* =====================================================================
   6) ASSET MANAGER
   ===================================================================== */
guard('assets',()=>{
 const p=addTab('ast','Assets','الأصول',rM);
 const grp=n=>{const i=n.lastIndexOf('_');return i>0?n.slice(0,i):tr('Loose parts','قطع منفردة')};
 const used=id=>items.filter(m=>(m.userData.dc||[]).some(d=>d.i==id)).length;
 function rM(){const gs=new Map();items.forEach(m=>{const k=grp(m.userData.name);gs.set(k,(gs.get(k)||0)+1)});
  const snd=ls.g('ms_snd:'+MP.cur,[]),ids=Object.keys(IMG);
  p.innerHTML=`<div class="sec">${tr('Summary','الملخص')}</div>
<div class="n"><span>▣</span>${tr('Parts','القطع')}<span class="cn">${items.length}</span></div><div class="n"><span>📁</span>${tr('Model groups','مجموعات المجسمات')}<span class="cn">${gs.size}</span></div>
<div class="n"><span>🖼</span>${tr('Images','الصور')}<span class="cn">${ids.length}</span></div><div class="n"><span>🔊</span>${tr('Sounds','الأصوات')}<span class="cn">${snd.length}</span></div>
<div class="n"><span>📜</span>${tr('Scripts','السكربتات')}<span class="cn">${S.scripts.length}</span></div><div class="n"><span>🖥</span>${tr('UI elements','عناصر الواجهة')}<span class="cn">${S.ui.length}</span></div>
<div class="sec">${tr('Models','المجسمات')}</div>${[...gs].sort((a,b)=>b[1]-a[1]).map(g=>`<div class="ai2"><div class="gr">${E(g[0])} · ${g[1]}</div><button data-gs="${E(g[0])}">${tr('Select','تحديد')}</button><button data-gd="${E(g[0])}">✕</button></div>`).join('')||`<div class="em">${tr('Empty','فارغ')}</div>`}
<div class="sec">${tr('Images','الصور')}</div>${ids.map(i=>`<div class="ai2"><img src="${IMG[i]}"><div class="gr">${i} · ${tr('used by','مستخدمة في')} ${used(i)}</div><button data-id="${i}"${used(i)?' disabled style="opacity:.4"':''}>✕</button></div>`).join('')||`<div class="em">${tr('No images','لا توجد صور')}</div>`}
${ids.length?`<div class="rw2"><button data-iun>${tr('Delete unused images','حذف الصور غير المستخدمة')}</button></div>`:''}
<div class="sec">${tr('Sounds','الأصوات')}</div>${snd.map(s=>`<div class="ai2"><div class="gr">🔊 ${E(s.name)} · ${s.sid?E(s.sid):tr('no ID yet','بدون رقم')}</div></div>`).join('')||`<div class="em">${tr('No sounds. Add them in the Sound tab.','لا توجد أصوات. أضفها من تبويب الصوت.')}</div>`}`}
 p.addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-gs]')){const k=b.dataset.gs,l=items.filter(m=>grp(m.userData.name)==k);select(null);l.forEach(m=>select(m,true));if(l.length){const bb=new T.Box3();l.forEach(m=>bb.expandByObject(m));const c=bb.getCenter(new T.Vector3());tg.set(c.x,Math.max(0,c.y),c.z);rad=Math.max(12,Math.min(300,bb.getSize(new T.Vector3()).length()*1.1));upCam()}toast('✓ '+l.length);return}
  if(b=e.target.closest('[data-gd]')){const k=b.dataset.gd,l=items.filter(m=>grp(m.userData.name)==k);if(!confirm(tr('Delete ','حذف ')+l.length+tr(' parts?',' قطعة؟')))return;select(null);l.forEach(m=>{sc.remove(m);items.splice(items.indexOf(m),1)});save();rM();return}
  if(b=e.target.closest('[data-id]')){if(b.disabled)return;delete IMG[b.dataset.id];try{localStorage.setItem('mapstudio_img',JSON.stringify(IMG))}catch(x){}rM();return}
  if(e.target.closest('[data-iun]')){let n=0;Object.keys(IMG).forEach(i=>{if(!used(i)){delete IMG[i];n++}});try{localStorage.setItem('mapstudio_img',JSON.stringify(IMG))}catch(x){}toast('✓ '+n);rM()}});
});

/* =====================================================================
   7) PUBLISH SETTINGS
   ===================================================================== */
guard('publish',()=>{
 const p=addTab('pub','Publish','النشر',rP);
 const GEN=['Adventure','Roleplay','Obby','Simulator','Showcase','Social'];
 const chk=()=>{const sp=items.some(m=>m.userData.t=='spawn'),fl=items.some(m=>m.userData.t=='block'&&m.scale.x>=24&&m.scale.z>=24);const sn2=ls.g('ms_snd:'+MP.cur,[]);
  return[[sp,tr('Has a SpawnLocation','فيه نقطة ظهور'),tr('Add a Spawn from the Toolbox','أضف نقطة ظهور من الصندوق')],[fl||items.some(m=>/^Terrain_/.test(m.userData.name)),tr('Has ground','فيه أرضية'),tr('Add a floor or generate terrain','أضف أرضية أو ولّد تضاريس')],[items.length>0&&items.length<12000,tr('Part count is reasonable','عدد القطع مناسب')+' ('+items.length+')',tr('Too many parts can lag phones','القطع الكثيرة تُبطئ الهواتف')],[!sn2.length||sn2.every(s=>s.sid),tr('All sounds have an ID','كل الأصوات لها رقم'),tr('Paste the audio IDs in the Sound tab','ألصق أرقام الأصوات في تبويب الصوت')],[!!S.pub.name.trim(),tr('Game name set','اسم اللعبة محدد'),tr('Write a name below','اكتب اسماً بالأسفل')],[!!S.pub.thumb,tr('Thumbnail added','الصورة المصغرة مضافة'),tr('Add a thumbnail','أضف صورة مصغرة')]]};
 function rP(){const P=S.pub,c=chk();
  p.innerHTML=`<div class="sec">${tr('Game info','معلومات اللعبة')}</div><div class="tq">
<input type="text" data-pf="name" maxlength="50" placeholder="${tr('Game name','اسم اللعبة')}" value="${E(P.name)}">
<textarea class="sm" data-pf="desc" maxlength="1000" placeholder="${tr('Description','الوصف')}">${E(P.desc)}</textarea>
${P.thumb?`<img class="thm" src="${P.thumb}">`:''}<input type="file" id="pthm" accept="image/*"></div>
<div class="r"><label>${tr('Genre','النوع')}</label><div class="v"><select data-pf="genre">${GEN.map(g=>`<option${g==P.genre?' selected':''}>${g}</option>`).join('')}</select></div></div>
<div class="r"><label>${tr('Max players','أقصى لاعبين')}</label><div class="v"><input type="number" data-pf="maxp" min="1" max="100" value="${P.maxp}"></div></div>
<div class="sec">${tr('Devices','الأجهزة المدعومة')}</div><div class="ckr">${[['phone','📱 '+tr('Phone','هاتف')],['tablet','📲 '+tr('Tablet','تابلت')],['desktop','💻 '+tr('Computer','كمبيوتر')],['console','🎮 '+tr('Console','كونسول')]].map(d=>`<label class="ck"><input type="checkbox" data-pd="${d[0]}"${P.dev[d[0]]?' checked':''}> ${d[1]}</label>`).join('')}</div>
<div class="sec">${tr('Permissions','الأذونات')}</div><div class="ckr"><label class="ck"><input type="checkbox" data-pf="priv"${P.priv?' checked':''}> ${tr('Private (only me)','خاصة (أنا فقط)')}</label><label class="ck"><input type="checkbox" data-pf="copy"${P.copy?' checked':''}> ${tr('Allow copying','السماح بالنسخ')}</label></div>
<div class="sec">${tr('Pre-publish check','فحص قبل النشر')}</div>${c.map(x=>`<div class="ck2 ${x[0]?'ok':'no'}">${x[0]?'✓':'•'} ${x[1]}${x[0]?'':' — '+x[2]}</div>`).join('')}
<div class="rw2"><button data-pex class="on2">⇧ ${tr('Open export (Luau / rbxlx)','فتح التصدير (Luau / rbxlx)')}</button></div>
<div class="nt">${tr('Roblox sets name, thumbnail, devices and permissions on the website when you publish. These values are saved here and written as comments at the top of the exported Luau.','Roblox يحدد الاسم والصورة والأجهزة والأذونات من موقعه عند النشر. هذه القيم تُحفظ هنا وتُكتب كتعليقات في أعلى ملف Luau المُصدَّر.')}</div>`}
 p.addEventListener('input',e=>{const t=e.target;if(t.dataset.pf){const k=t.dataset.pf;S.pub[k]=t.type=='checkbox'?t.checked:t.type=='number'?(parseInt(t.value)||1):t.value;saveS();if(k=='name'||k=='priv'||k=='copy')return}
  if(t.dataset.pd){S.pub.dev[t.dataset.pd]=t.checked;saveS()}});
 p.addEventListener('change',e=>{const t=e.target;if(t.id=='pthm'&&t.files[0]){const fr=new FileReader();fr.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=512;c.height=288;const x=c.getContext('2d'),k=Math.max(512/im.width,288/im.height),w=im.width*k,h=im.height*k;x.drawImage(im,(512-w)/2,(288-h)/2,w,h);S.pub.thumb=c.toDataURL('image/jpeg',.8);saveS();rP()};im.src=fr.result};fr.readAsDataURL(t.files[0])}});
 p.addEventListener('click',e=>{if(e.target.closest('[data-pex]'))$('ex').click()});
});

/* =====================================================================
   8) EXPLORER GAME TREE
   ===================================================================== */
guard('explorer',()=>{
 const cnt=k=>S.scripts.filter(s=>s.k==k).length;
 const ROWS=[['pl','👥','Players','Players in the game (you, while testing)','اللاعبون (أنت أثناء التجربة)',()=>'1',null],
  ['rs','📦','ReplicatedStorage','Shared by client and server (ModuleScripts)','مشترك بين العميل والسيرفر (موديولات)',()=>cnt('ModuleScript')+' Module','scr'],
  ['sss','⚙','ServerScriptService','Server scripts','سكربتات السيرفر',()=>cnt('Script')+' Script','scr'],
  ['ss','🗄','ServerStorage','Things kept on the server','أشياء محفوظة على السيرفر',()=>items.length+' '+tr('parts','قطعة'),'ast'],
  ['sg','🖼','StarterGui','Player interfaces','واجهات اللاعب',()=>S.ui.length+' UI','ui'],
  ['sp','🎒','StarterPack','Tools the player starts with','أدوات يبدأ بها اللاعب',()=>'0',null],
  ['spl','🏃','StarterPlayer','Player settings and LocalScripts','إعدادات اللاعب وسكربتاته المحلية',()=>cnt('LocalScript')+' Local','scr']];
 const draw=()=>{const e=$('exp');if(!e)return;e.insertAdjacentHTML('beforeend',`<div class="sec">${tr('Game tree','شجرة اللعبة')}</div>`+ROWS.map(r=>`<div class="n" data-gt="${r[0]}">▸ ${r[1]} ${r[2]}<small>${tr(r[3],r[4])}</small><span class="cn">${r[5]()}</span></div>`).join('')+
  S.scripts.map(s=>`<div class="n c" data-gt-s="${s.id}"><span>${SCK[s.k][0]}</span>${E(s.name)}<small>${SCK[s.k][1]}</small></div>`).join('')+
  S.ui.map(u=>`<div class="n c" data-gt-u="${u.id}"><span>🖼</span>${E(u.name)}<small>StarterGui</small></div>`).join(''))};
 const _s=sync;sync=function(){_s();try{draw()}catch(e){}};
 $('exp').addEventListener('click',e=>{let b;
  if(b=e.target.closest('[data-gt]')){const r=ROWS.find(x=>x[0]==b.dataset.gt);if(r[6])openTab(r[6]);else toast(r[2]+' — '+tr(r[3],r[4]));return}
  if(b=e.target.closest('[data-gt-s]')){SCSEL=b.dataset.gtS;openTab('scr');const t=TABS.find(x=>x.id=='scr');t&&t.render();return}
  if(b=e.target.closest('[data-gt-u]')){UISEL=b.dataset.gtU;openTab('ui');const t=TABS.find(x=>x.id=='ui');t&&t.render();window.MapStudioV10.updOv&&window.MapStudioV10.updOv()}});
 sync();
});

/* =====================================================================
   9) EXPORT (Luau + rbxlx): UI, scripts, publish header
   ===================================================================== */
guard('export',()=>{
 const lb=src=>{let n=2;while(src.includes(']'+'='.repeat(n)+']'))n++;const e='='.repeat(n);return'['+e+'[\n'+src+']'+e+']'};
 const nm=s=>String(s||'Item').replace(/[\r\n"]/g,' ');
 const act=u=>{const t=String(u.tg||'');
  if(u.k!='TextButton'||u.a=='none'||!t)return'';
  if(u.a=='teleport')return'local btn=script.Parent\nlocal function find(n)\n\tfor _,d in ipairs(workspace:GetDescendants()) do\n\t\tif d:IsA("BasePart") and string.find(string.lower(d.Name),string.lower(n),1,true) then return d end\n\tend\nend\nbtn.Activated:Connect(function()\n\tlocal t=find('+q(t)+')\n\tlocal ch=game.Players.LocalPlayer.Character\n\tif t and ch then ch:PivotTo(t.CFrame+Vector3.new(0,6,0)) end\nend)\n';
  return'local btn=script.Parent\nbtn.Activated:Connect(function()\n\tlocal g=btn:FindFirstAncestorOfClass("ScreenGui")\n\tlocal t=g and g:FindFirstChild('+q(t)+',true)\n\tif t then t.Visible=false end\nend)\n'};
 const _l=luau;luau=function(){let s=_l(),h='',P=S.pub;
  if(P.name||P.desc)h='-- Game: '+nm(P.name)+'\n-- Genre: '+P.genre+' | Max players: '+P.maxp+' | '+(P.priv?'Private':'Public')+' | Devices: '+Object.keys(P.dev).filter(k=>P.dev[k]).join(', ')+'\n'+String(P.desc||'').split('\n').filter(Boolean).slice(0,6).map(x=>'-- '+x.slice(0,200)).join('\n')+'\n\n';
  if(S.ui.length){s+='\n-- ===== StarterGui (UI) =====\ndo\nlocal g=Instance.new("ScreenGui") g.Name="MapUI" g.ResetOnSpawn=false g.Parent=game:GetService("StarterGui")\n';
   S.ui.forEach((u,i)=>{const v='e'+i,b=c3(u.bg),f=c3(u.fg);
    s+='local '+v+'=Instance.new('+q(u.k)+') '+v+'.Name='+q(u.name)+' '+v+'.Position=UDim2.fromScale('+u.x/100+','+u.y/100+') '+v+'.Size=UDim2.fromScale('+u.w/100+','+u.h/100+') '+v+'.BackgroundColor3=Color3.fromRGB('+b+') '+v+'.BackgroundTransparency='+u.bt+' '+v+'.BorderSizePixel=0';
    if(u.k!='Frame')s+=' '+v+'.Text='+q(u.text)+' '+v+'.TextColor3=Color3.fromRGB('+f+') '+v+'.TextScaled=true';
    s+=' '+v+'.Parent=g\n';
    if(u.r>0)s+='do local c=Instance.new("UICorner") c.CornerRadius=UDim.new(0,'+u.r+') c.Parent='+v+' end\n';
    const a=act(u);if(a)s+='do local l=Instance.new("LocalScript") l.Name="Action" l.Source='+lb(a)+' l.Parent='+v+' end\n'});
   s+='end\n'}
  if(S.scripts.length){s+='\n-- ===== Scripts =====\n';S.scripts.forEach(x=>{const dst=x.k=='Script'?'game:GetService("ServerScriptService")':x.k=='LocalScript'?'game:GetService("StarterPlayer"):WaitForChild("StarterPlayerScripts")':'game:GetService("ReplicatedStorage")';
    s+='do local s=Instance.new('+q(x.k)+') s.Name='+q(x.name)+' s.Source='+lb(x.src)+' s.Parent='+dst+' end\n'})}
  return h+s};
 let rid=0;const R3=h=>{const c=c3(h);return'<Color3 name="@"><R>'+(c[0]/255)+'</R><G>'+(c[1]/255)+'</G><B>'+(c[2]/255)+'</B></Color3>'};
 const col=(n,h)=>R3(h).replace('@',n),cd=s=>'<![CDATA['+String(s).replace(/\]\]>/g,']]]]><![CDATA[>')+']]>',ex=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
 const scr=(cls,name,src)=>'<Item class="'+cls+'" referent="RBXV'+(rid++)+'"><Properties><string name="Name">'+ex(name)+'</string><ProtectedString name="Source">'+cd(src)+'</ProtectedString></Properties></Item>';
 const _x=xml;xml=function(){let s=_x(),extra='';rid=0;
  if(S.ui.length){let kids='';S.ui.forEach(u=>{let k='';if(u.r>0)k+='<Item class="UICorner" referent="RBXV'+(rid++)+'"><Properties><UDim name="CornerRadius"><S>0</S><O>'+u.r+'</O></UDim></Properties></Item>';const a=act(u);if(a)k+=scr('LocalScript','Action',a);
    kids+='<Item class="'+u.k+'" referent="RBXV'+(rid++)+'"><Properties><string name="Name">'+ex(u.name)+'</string><UDim2 name="Position"><XS>'+u.x/100+'</XS><XO>0</XO><YS>'+u.y/100+'</YS><YO>0</YO></UDim2><UDim2 name="Size"><XS>'+u.w/100+'</XS><XO>0</XO><YS>'+u.h/100+'</YS><YO>0</YO></UDim2>'+col('BackgroundColor3',u.bg)+'<float name="BackgroundTransparency">'+u.bt+'</float><int name="BorderSizePixel">0</int>'+(u.k!='Frame'?'<string name="Text">'+ex(u.text)+'</string>'+col('TextColor3',u.fg)+'<bool name="TextScaled">true</bool>':'')+'</Properties>'+k+'</Item>'});
   extra+='<Item class="StarterGui" referent="RBXV'+(rid++)+'"><Properties><string name="Name">StarterGui</string></Properties><Item class="ScreenGui" referent="RBXV'+(rid++)+'"><Properties><string name="Name">MapUI</string><bool name="ResetOnSpawn">false</bool></Properties>'+kids+'</Item></Item>'}
  const by=k=>S.scripts.filter(x=>x.k==k).map(x=>scr(x.k,x.name,x.src)).join('');
  if(by('Script'))extra+='<Item class="ServerScriptService" referent="RBXV'+(rid++)+'"><Properties><string name="Name">ServerScriptService</string></Properties>'+by('Script')+'</Item>';
  if(by('ModuleScript'))extra+='<Item class="ReplicatedStorage" referent="RBXV'+(rid++)+'"><Properties><string name="Name">ReplicatedStorage</string></Properties>'+by('ModuleScript')+'</Item>';
  if(by('LocalScript'))extra+='<Item class="StarterPlayer" referent="RBXV'+(rid++)+'"><Properties><string name="Name">StarterPlayer</string></Properties><Item class="StarterPlayerScripts" referent="RBXV'+(rid++)+'"><Properties><string name="Name">StarterPlayerScripts</string></Properties>'+by('LocalScript')+'</Item></Item>';
  return extra?s.replace(/<\/roblox>\s*$/,extra+'</roblox>'):s};
});

/* =====================================================================
   10) wiring: language refresh · map switch
   ===================================================================== */
guard('wire',()=>{
 const _rb=renderBox;renderBox=function(){_rb();labelTabs();renderAll();try{window.MapStudioV10.deviceRefresh()}catch(e){}};
 const _lm=loadMap;loadMap=function(id){_lm(id);try{loadS();SCSEL=null;UISEL=null;renderAll();window.MapStudioV10.updOv&&window.MapStudioV10.updOv();sync()}catch(e){log('v10 map: '+e.message,'e')}};
 labelTabs();renderAll();
 if(window.MapStudioV9)window.MapStudioV10.version='10';
 log('Map Studio v10 ready','i');
});
})();
