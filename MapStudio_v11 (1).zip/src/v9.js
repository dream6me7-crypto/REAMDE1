/* ===== v9 · Toolbox library · Lighting & effects · Terrain · Sound · Output · Play ===== */
(function(){
'use strict';
const T=R;
const isAr=()=>lang=='ar';
const A9={Play:'تجربة',Stop:'إيقاف',Lighting:'الإضاءة',Sound:'الصوت',Output:'المخرجات','Services':'الخدمات',Models:'المجسمات','Search models':'ابحث عن مجسم…',All:'الكل',Trees:'أشجار',Japanese:'ياباني',Lights:'إنارة',Props:'أغراض',Nature:'طبيعة','Basic parts':'قطع أساسية',Terrain:'التضاريس',Area:'المساحة',Hills:'التلال',Height:'الارتفاع',Seed:'البذرة','Trees density':'كثافة الأشجار',Lake:'بحيرة','Flowers & rocks':'زهور وصخور','Replace previous':'استبدال السابق','Generate terrain':'توليد التضاريس','Sakura map':'ماب ساكورا جاهز','Clear generated':'مسح المولَّد',
'Built-in models: no hidden scripts':'مجسمات مدمجة: بدون أي سكربتات مخفية','No messages yet':'لا توجد رسائل بعد',
Classic:'كلاسيك',Day:'نهار','Sakura Dusk':'غروب الساكورا',Night:'ليل','Misty Forest':'غابة ضبابية','Neon Pink':'نيون وردي',Theme:'النمط',
'Sky & Sun':'السماء والشمس','Clock time':'الوقت','Sun brightness':'سطوع الشمس','Ambient':'الإضاءة العامة',Shadows:'الظلال','Sun color':'لون الشمس','Sky top':'أعلى السماء','Sky horizon':'الأفق','Ambient sky':'لون الإضاءة العلوي','Ambient ground':'لون الإضاءة السفلي',
Atmosphere:'الغلاف الجوي (ضباب)',Density:'الكثافة',Haze:'الغبش',Bloom:'توهج Bloom',Intensity:'الشدة',Threshold:'العتبة',SunRays:'أشعة الشمس',Spread:'الانتشار',ColorCorrection:'تعديل الألوان',Brightness:'السطوع',Contrast:'التباين',Saturation:'التشبع',Tint:'الصبغة',DepthOfField:'عمق الميدان','Far blur':'ضبابية البعيد','Near blur':'ضبابية القريب','Focus distance':'مسافة التركيز','In-focus radius':'نطاق الوضوح','Stars':'النجوم',
'Add sound':'إضافة صوت','Background Music':'موسيقى خلفية',Rain:'مطر',Wind:'رياح',Ambience:'أجواء','Gate':'بوابة',Reward:'مكافأة',Volume:'مستوى الصوت',Looped:'تكرار',Playing:'تشغيل تلقائي','Paste the Roblox audio ID (Creator Store → Audio → Copy ID). Exported as Sound objects; the editor cannot preview Roblox audio.':'الصق رقم الصوت من Roblox (Creator Store ← Audio ← Copy ID). يُصدَّر كأجسام Sound، ولا يمكن تشغيل صوت Roblox داخل المحرر.',
'Click Play to walk around your map. Use the stick, Jump, and drag to look.':'اضغط تجربة للتجول داخل الماب. استخدم العصا والقفز واسحب لتدوير الكاميرا.','Jump':'قفز',
'Added':'تمت إضافة','parts':'قطعة','Terrain generated':'تم توليد التضاريس','Sakura map built':'تم بناء ماب الساكورا','Cleared':'تم المسح','Walking in your map…':'تتجول داخل الماب…','Stopped':'تم الإيقاف','Script':'سكربت','Post effects are not supported on this device':'المؤثرات غير مدعومة على هذا الجهاز'};
Object.assign(AR,A9);Object.keys(A9).forEach(k=>EN[A9[k]]=k);
Object.assign(AR,{Packs:'حزم',Recent:'الأخيرة'});EN['حزم']='Packs';EN['الأخيرة']='Recent';
const ls={g(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const hexn=h=>parseInt(String(h).replace('#',''),16);
const clone=o=>JSON.parse(JSON.stringify(o));
const mg=(a,b)=>{for(const k in b){if(b[k]&&typeof b[k]=='object'&&!Array.isArray(b[k]))a[k]=mg(a[k]||{},b[k]);else a[k]=b[k]}return a};
const rnd=s=>()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const fmt=v=>(+v).toFixed(2).replace(/\.?0+$/,'')||'0';

/* ---------------- Output panel ---------------- */
const OUT=[];let outErr=0;
function log(msg,ty){const d=new Date(),p=n=>String(n).padStart(2,'0');OUT.push({t:p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds()),m:String(msg),y:ty||'i'});if(OUT.length>300)OUT.shift();if(ty=='e'||ty=='w')outErr++;renderOut()}
function renderOut(){const p=$('outp');if(!p)return;
 p.innerHTML=`<div class="sec fx"><span>${esc(L('Output'))}</span><button class="sb" data-oc>🗑</button></div>`+(OUT.length?OUT.slice().reverse().map(o=>`<div class="ol ${o.y}"><i>${o.t}</i>${esc(o.m)}</div>`).join(''):`<div class="em">${esc(L('No messages yet'))}</div>`);
 const b=$('obg');if(b)b.textContent=outErr||''}
$('outp').addEventListener('click',e=>{if(e.target.closest('[data-oc]')){OUT.length=0;outErr=0;renderOut()}});
document.querySelector('#tabs [data-d="outp"]').addEventListener('click',()=>{outErr=0;renderOut()});
const _run=LuaImp.run;
LuaImp.run=function(src,opt){const r=_run.call(LuaImp,src,opt);try{(r.log||[]).forEach(l=>log(l,/^warn:/.test(l)?'w':'i'));if(r.error)log('Line '+r.error.line+': '+r.error.msg,'e');log(L('Script')+': '+r.parts.length+' '+L('parts')+' · '+r.ms+'ms','i')}catch(e){}return r};

/* ---------------- Model builders (parts only → exports to Luau / rbxlx) ---------------- */
const P=(t,n,p,s,c,m,o)=>Object.assign({t,n,p,s,r:[0,0,0],c,m:m||'Plastic'},o||{});
const BK=(n,p,s,c,m,o)=>P('block',n,p,s,c,m,o);
const BL=(n,p,s,c,m,o)=>P('ball',n,p,Array.isArray(s)?s:[s,s,s],c,m,o);
const CY=(n,p,h,d,c,m,o)=>P('cyl',n,p,[h,d,d],c,m,Object.assign({r:[0,0,90]},o||{}));
const CZ=(n,p,len,d,c,m,o)=>P('cyl',n,p,[len,d,d],c,m,Object.assign({r:[0,90,0]},o||{}));
const WG=(n,p,s,c,m,o)=>P('wedge',n,p,s,c,m,o);
const LB=(n,a,b,d,c,m,o)=>{const v=new T.Vector3(b[0]-a[0],b[1]-a[1],b[2]-a[2]),len=v.length()||.01,q=new T.Quaternion().setFromUnitVectors(new T.Vector3(1,0,0),v.normalize()),e=new T.Euler().setFromQuaternion(q,'XYZ');
 return P('cyl',n,[(a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2],[len,d,d],c,m,Object.assign({r:[e.x*180/Math.PI,e.y*180/Math.PI,e.z*180/Math.PI]},o||{}))};
const scaleList=(l,k)=>l.map(p=>Object.assign({},p,{p:p.p.map(v=>v*k),s:p.s.map(v=>v*k)}));

function sakura(kind,k){
 const pal={pink:['#ffb7c5','#ffc9d6','#f7a3bb','#ffdbe4','#f5b0c8'],white:['#ffffff','#fbeef3','#f3e2ea','#ffffff','#f8e8ef'],purple:['#b79cf5','#a98af0','#c7b1fa','#9d7fe8','#bda4f7'],maple:['#b3262e','#912029','#cc3b3b','#a31f2b','#c24545']}[kind];
 const tr=kind=='maple'?'#3b2a2a':kind=='white'?'#5a4a44':'#4a3228';
 const l=[CY('Trunk',[0,2.6,0],5.2,1.1,tr,'Wood'),LB('Branch1',[0,4.2,0],[-2.6,6.6,.8],.55,tr,'Wood'),LB('Branch2',[0,4.4,0],[2.8,6.8,-.6],.55,tr,'Wood'),LB('Branch3',[0,4.6,0],[.4,7,2.8],.45,tr,'Wood')];
 [[0,7.6,0,7],[-3,6.8,.9,5],[3.1,7,-.7,5.2],[.6,6.9,3.1,4.7],[-.5,7.1,-3.1,5],[0,10,0,4.6],[-2,9.2,-1.2,3.6],[2.2,9.4,1,3.8]].forEach((b,i)=>l.push(BL('Blossom'+(i+1),[b[0],b[1],b[2]],[b[3],b[3]*.82,b[3]],pal[i%5],'SmoothPlastic')));
 return scaleList(l,k)}
function weeping(){const tr='#4a3228',l=[CY('Trunk',[0,2.2,0],4.4,1.5,tr,'Wood'),LB('Branch1',[0,4,0],[-2.8,5.8,0],.6,tr,'Wood'),LB('Branch2',[0,4,0],[2.8,5.8,.4],.6,tr,'Wood'),BL('Dome',[0,6.4,0],[9.4,3.8,9.4],'#ffc2d1','SmoothPlastic'),BL('DomeTop',[0,7.4,0],[5.6,2.4,5.6],'#ffb0c4','SmoothPlastic')];
 const g=rnd(3);for(let i=0;i<10;i++){const a=i/10*6.283,r=3.1+g()*1.2,len=4+g()*3.2,x=Math.cos(a)*r,z=Math.sin(a)*r;l.push(BK('Strand'+i,[x,5.9-len/2,z],[.5,len,.5],i%2?'#ffc9d8':'#ffb3c7','SmoothPlastic'),BL('Tip'+i,[x,5.9-len,z],.9,'#ffd8e3','SmoothPlastic'))}return l}
function pine(){const l=[CY('Trunk',[0,2,0],4,1,'#5a4030','Wood')],gs=['#3f8a45','#4a9a4c','#58aa55','#66ba60'];for(let i=0;i<4;i++)l.push(CY('Layer'+(i+1),[0,4.2+i*2.5,0],2.8,8.4-i*1.9,gs[i],'SmoothPlastic'));l.push(CY('Tip',[0,14.4,0],2.2,.7,gs[3],'SmoothPlastic'));return l}
function petals(){const g=rnd(5),l=[],cs=['#ffc4d3','#ffd3de','#f9a9bf','#ffe0e8'];for(let i=0;i<14;i++){const a=g()*6.283,r=Math.sqrt(g())*4.5;l.push(BK('Petal'+i,[Math.cos(a)*r,.07,Math.sin(a)*r],[.9,.12,.6],cs[i%4],'SmoothPlastic',{r:[0,g()*180,0],co:false}))}return l}
function torii(k,col,cap){cap=cap||'#1c1c20';const l=[];
 [-4,4].forEach(x=>l.push(CY('Pillar',[x,5.2,0],10.4,1.3,col,'SmoothPlastic'),CY('PillarBase',[x,.45,0],.9,1.9,'#2f2f33','Slate')));
 l.push(BK('Nuki',[0,7.9,0],[8.6,.8,.9],col,'SmoothPlastic'),BK('Gakuzuka',[0,9.4,0],[.9,1.8,.9],cap,'SmoothPlastic'),BK('Shimaki',[0,10.5,0],[14.2,.5,1.6],cap,'SmoothPlastic'),BK('Kasagi',[0,11,0],[15.4,.7,2],col,'SmoothPlastic'),BK('KasagiCap',[0,11.5,0],[16.2,.45,2.4],cap,'SmoothPlastic'),
  BK('TipL',[-8.2,11.9,0],[1.8,.45,2.4],cap,'SmoothPlastic',{r:[0,0,22]}),BK('TipR',[8.2,11.9,0],[1.8,.45,2.4],cap,'SmoothPlastic',{r:[0,0,-22]}));
 return scaleList(l,k)}
function stoneLantern(st,gl){return[BK('Base',[0,.35,0],[2.8,.7,2.8],st,'Slate'),CY('Post',[0,2.1,0],2.8,.9,st,'Slate'),BK('Tray',[0,3.65,0],[2.4,.4,2.4],st,'Slate'),BK('Fire',[0,4.65,0],[1.5,1.6,1.5],st,'Slate'),BK('GlowX',[0,4.65,0],[1,1.1,1.62],gl,'Neon'),BK('GlowZ',[0,4.65,0],[1.62,1.1,1],gl,'Neon'),BK('Roof1',[0,5.7,0],[3.2,.45,3.2],st,'Slate'),BK('Roof2',[0,6.15,0],[2.2,.45,2.2],st,'Slate'),BL('Finial',[0,6.7,0],.9,st,'Slate')]}
function lamp(){const d='#2b2b2f',g='#ffd27a';return[BK('Foot',[0,.3,0],[1.4,.6,1.4],d,'Slate'),CY('Pole',[0,3.6,0],6.6,.5,'#3a2a22','Wood'),BK('Box',[0,7.6,0],[1.5,1.7,1.5],d,'Metal'),BK('GlowA',[0,7.6,0],[1.1,1.3,1.6],g,'Neon'),BK('GlowB',[0,7.6,0],[1.6,1.3,1.1],g,'Neon'),BK('Cap',[0,8.7,0],[2,.35,2],d,'Metal'),BK('Cap2',[0,9.05,0],[1.3,.35,1.3],d,'Metal'),BL('Knob',[0,9.4,0],.45,d,'Metal')]}
function paperLantern(){return[CY('Pole',[0,3.2,0],6.4,.3,'#3a2a22','Wood'),BK('Arm',[.8,6.3,0],[1.8,.25,.25],'#3a2a22','Wood'),BL('Paper',[1.6,5,0],[2.2,2.6,2.2],'#ffc86a','Neon'),CY('CapTop',[1.6,6.4,0],.3,1,'#2a2a2a','Metal'),CY('CapBot',[1.6,3.6,0],.3,1,'#2a2a2a','Metal')]}
function pagoda(){const l=[BK('Platform',[0,.6,0],[20,1.2,20],'#8d8a86','Slate'),BK('Steps',[0,.3,11],[6,.6,2],'#8d8a86','Slate')],wall='#f1ece0',wood='#4a2f22',roof='#2c313c';let y=1.2;
 for(let i=0;i<3;i++){const w=13-i*3,h=4.6,n=i+1;l.push(BK('Wall'+n,[0,y+h/2,0],[w,h,w],wall,'Concrete'));
  [[-1,-1],[1,-1],[-1,1],[1,1]].forEach((q,j)=>l.push(BK('Post'+n+'_'+j,[q[0]*w/2,y+h/2,q[1]*w/2],[.8,h,.8],wood,'Wood')));
  l.push(BK('WinF'+n,[0,y+h/2+.2,w/2+.06],[2,2,.15],'#ffd98a','Neon'),BK('WinB'+n,[0,y+h/2+.2,-w/2-.06],[2,2,.15],'#ffd98a','Neon'),BK('Beam'+n,[0,y+h+.25,0],[w+1,.5,w+1],wood,'Wood'),BK('RoofA'+n,[0,y+h+.75,0],[w+6,.6,w+6],roof,'Slate'),BK('RoofB'+n,[0,y+h+1.3,0],[w+3.6,.6,w+3.6],roof,'Slate'),BK('RoofC'+n,[0,y+h+1.85,0],[w+1.4,.6,w+1.4],roof,'Slate'));y+=h+2.1}
 l.push(CY('Spire',[0,y+2.4,0],4.8,.5,'#b9a26a','Metal'),CY('Ring1',[0,y+1.4,0],.3,1.6,'#b9a26a','Metal'),CY('Ring2',[0,y+2.6,0],.3,1.3,'#b9a26a','Metal'),BL('Orb',[0,y+5,0],.9,'#d4b95e','Metal'));return l}
function house(){const W=15,D=10,H=5,wall='#f0ebdd',wood='#4d3326',roof='#353a46',y0=.9,l=[BK('Base',[0,.45,0],[W+1,.9,D+1],'#7d7a77','Slate'),BK('Walls',[0,y0+H/2,0],[W,H,D],wall,'Concrete')];
 [-W/2,-W/6,W/6,W/2].forEach((x,i)=>l.push(BK('PostF'+i,[x,y0+H/2,D/2+.05],[.6,H,.4],wood,'Wood'),BK('PostB'+i,[x,y0+H/2,-D/2-.05],[.6,H,.4],wood,'Wood')));
 l.push(BK('BeamF',[0,y0+H-.3,D/2+.06],[W+.4,.6,.4],wood,'Wood'),BK('Door',[0,y0+2.1,D/2+.12],[2.6,4.2,.25],'#5b3a28','Wood'),BK('Step',[0,.25,D/2+1.4],[5,.5,1.8],'#7d7a77','Slate'));
 [-4.6,4.6].forEach((x,i)=>l.push(BK('Window'+i,[x,y0+2.8,D/2+.12],[2.6,2.2,.2],'#ffd98a','Neon')));
 l.push(WG('RoofA',[0,y0+H+1.9,-3.1],[W+2.4,3.8,6.2],roof,'Slate'),WG('RoofB',[0,y0+H+1.9,3.1],[W+2.4,3.8,6.2],roof,'Slate',{r:[0,180,0]}),BK('Ridge',[0,y0+H+3.9,0],[W+2.6,.45,.9],'#23262e','Slate'));return l}
function stall(){const wd='#6b4a35',l=[];[[-3,-1.8],[3,-1.8],[-3,1.8],[3,1.8]].forEach((q,i)=>l.push(CY('Post'+i,[q[0],2.5,q[1]],5,.5,wd,'Wood')));
 l.push(BK('Back',[0,2.6,-1.8],[6,4.6,.3],'#f1ece0','Concrete'),BK('CounterBody',[0,.8,1.4],[6,1.6,1.2],wd,'Wood'),BK('CounterTop',[0,1.7,1.4],[6.4,.3,1.6],'#8a5c36','Wood'),WG('Roof',[0,5.7,0],[7.6,1.6,5.2],'#353a46','Slate',{r:[0,180,0]}),BK('Lantern',[0,4.4,1.8],[.9,.9,.9],'#ffc86a','Neon'));return l}
function fence(){const rd='#6b2d1f',l=[];[-4,0,4].forEach((x,i)=>l.push(BK('Post'+i,[x,1.6,0],[.55,3.2,.55],rd,'Wood')));l.push(BK('RailTop',[0,2.6,0],[8.6,.35,.3],rd,'Wood'),BK('RailLow',[0,1.3,0],[8.6,.35,.3],rd,'Wood'));return l}
function bridge(){const red='#a8322a',wd='#6b4a35',l=[BK('Deck',[0,2.6,0],[6,.5,12],wd,'Wood'),WG('RampN',[0,1.425,-8.5],[6,2.85,5],wd,'Wood'),WG('RampS',[0,1.425,8.5],[6,2.85,5],wd,'Wood',{r:[0,180,0]})];
 [-2.8,2.8].forEach((x,i)=>{[-6,-2,2,6].forEach((z,j)=>l.push(CY('Post'+i+j,[x,3.9,z],2.1,.4,red,'SmoothPlastic')));l.push(BK('RailTop'+i,[x,4.7,0],[.25,.3,12.4],red,'SmoothPlastic'),BK('RailLow'+i,[x,3.7,0],[.25,.25,12.4],red,'SmoothPlastic'))});return l}
function stones(){const g=rnd(9),l=[],cs=['#9a9aa0','#8b8b92','#a5a5ab'];for(let i=0;i<9;i++)l.push(CY('Stone'+i,[Math.sin(i*.7)*2,.15,i*3],.3,2.2+g()*.9,cs[i%3],'Slate'));return l}
function pond(){const g=rnd(4),l=[CY('Sand',[0,.15,0],.3,24,'#e6d6a8','Concrete'),CY('Water',[0,.22,0],.4,20,'#4aa8d8','Glass',{tr:.35,co:false})];for(let i=0;i<5;i++){const a=i/5*6.283+g(),r=11.5+g();l.push(BL('Rock'+i,[Math.cos(a)*r,.9,Math.sin(a)*r],[2.6+g()*1.4,1.8+g(),2.2+g()],'#8d8f96','Slate'))}return l}
function barrel(){return[CY('Barrel',[0,1.2,0],2.4,1.9,'#7a4f2e','Wood'),CY('RingTop',[0,1.9,0],.16,2,'#2a2a2e','Metal'),CY('RingBot',[0,.5,0],.16,2,'#2a2a2e','Metal'),CY('Lid',[0,2.42,0],.08,1.7,'#8a5c36','Wood')]}
function crate(){return[BK('Crate',[0,1.2,0],[3,2.4,2.4],'#8a5a35','Wood'),BK('StrapA',[-.8,1.2,0],[.3,2.46,2.46],'#2d2a2a','Wood'),BK('StrapB',[.8,1.2,0],[.3,2.46,2.46],'#2d2a2a','Wood')]}
function cart(){const wd='#6b4a35',dk='#3a2a22';return[BK('Bed',[0,1.6,0],[4.2,.35,2.6],wd,'Wood'),BK('SideL',[0,2.2,1.3],[4.2,.9,.2],wd,'Wood'),BK('SideR',[0,2.2,-1.3],[4.2,.9,.2],wd,'Wood'),BK('Back',[-2.1,2.2,0],[.2,.9,2.6],wd,'Wood'),CZ('WheelL',[0,1.1,1.6],.3,2.2,dk,'Wood'),CZ('WheelR',[0,1.1,-1.6],.3,2.2,dk,'Wood'),LB('HandleL',[2,1.7,.9],[5.4,1.2,.9],.2,dk,'Wood'),LB('HandleR',[2,1.7,-.9],[5.4,1.2,-.9],.2,dk,'Wood')]}
function bench(){const wd='#7a5236',l=[BK('Seat',[0,1.6,0],[5,.4,1.6],wd,'Wood'),BK('Back',[0,2.7,-.7],[5,1.4,.3],wd,'Wood')];[-2.1,2.1].forEach((x,i)=>l.push(BK('LegF'+i,[x,.8,.55],[.35,1.6,.35],'#2d2a2a','Metal'),BK('LegB'+i,[x,.8,-.55],[.35,1.6,.35],'#2d2a2a','Metal')));return l}
function rock(){return[BL('Rock',[0,1.1,0],[4.8,3.4,4],'#8d8f96','Slate'),BL('Chip',[2.7,.55,1.2],[2.4,1.5,2.2],'#7c7e85','Slate'),BL('Chip2',[-2.5,.5,-1],[2,1.2,1.8],'#9a9ca3','Slate')]}
function rocks(){const g=rnd(8),l=[],cs=['#8d8f96','#7c7e85','#9a9ca3','#8a8590'];for(let i=0;i<5;i++){const a=g()*6.283,r=g()*3.2,s=1.4+g()*2.4;l.push(BL('Rock'+i,[Math.cos(a)*r,s*.28,Math.sin(a)*r],[s*1.3,s*.8,s],cs[i%4],'Slate'))}return l}
function mushrooms(){const l=[];[[0,0,1],[1.6,.8,.7],[-1.3,1,.8]].forEach((q,i)=>{l.push(CY('Stem'+i,[q[0],.6*q[2],q[1]],1.2*q[2],.5*q[2],'#e9d9c1','SmoothPlastic'),BL('Cap'+i,[q[0],1.25*q[2],q[1]],[1.9*q[2],1*q[2],1.9*q[2]],'#b0603a','SmoothPlastic'))});return l}
function flowers(){const g=rnd(6),l=[],cs=['#ff8fb1','#b79cf5','#ffe27a','#ffffff','#ff9d6e','#8fd1ff'];for(let i=0;i<7;i++){const a=g()*6.283,r=g()*2.4,x=Math.cos(a)*r,z=Math.sin(a)*r,h=1.1+g()*.9;l.push(CY('Stem'+i,[x,h/2,z],h,.14,'#3f8a45','SmoothPlastic',{co:false}),BL('Bloom'+i,[x,h+.1,z],.75,cs[i%6],'SmoothPlastic',{co:false}))}return l}
function bush(){return[BL('A',[0,1.1,0],[3.4,2.4,3.2],'#3f8a45','SmoothPlastic'),BL('B',[1.7,.9,.5],[2.4,1.8,2.4],'#4a9a4c','SmoothPlastic'),BL('C',[-1.5,.8,-.4],[2.2,1.6,2.2],'#58aa55','SmoothPlastic')]}
function tuft(){const g=rnd(2),l=[],cs=['#4a9a4c','#58aa55','#66ba60'];for(let i=0;i<8;i++){const a=g()*6.283,r=g()*.9;l.push(BK('Blade'+i,[Math.cos(a)*r,.7,Math.sin(a)*r],[.25,1.4,.1],cs[i%3],'SmoothPlastic',{r:[0,g()*180,(g()-.5)*30],co:false}))}return l}
function hill(){return[BL('Hill',[0,0,0],[38,16,38],'#62a64e','Grass')]}

const ML=[];const reg=(id,cat,ico,en,ar,kw,fn)=>ML.push({id,cat,ico,en,ar,kw,fn});
reg('sakura','trees','🌸','Sakura Tree','شجرة ساكورا','cherry blossom pink cherry blossom tree sakura ساكورا زهر كرز وردي',()=>sakura('pink',1));
reg('sakura_l','trees','🌸','Big Sakura','ساكورا كبيرة','large big sakura كبيرة',()=>sakura('pink',1.5));
reg('sakura_w','trees','🤍','White Sakura','ساكورا بيضاء','white sakura أبيض',()=>sakura('white',1));
reg('sakura_p','trees','💜','Purple Blossom','أزهار بنفسجية','purple jacaranda بنفسجي',()=>sakura('purple',1.1));
reg('maple','trees','🍁','Red Maple','قيقب أحمر','maple autumn red خريف',()=>sakura('maple',1));
reg('weeping','trees','🌿','Weeping Sakura','ساكورا باكية','weeping willow hanging wisteria',weeping);
reg('pine','trees','🌲','Pine Tree','شجرة صنوبر','pine fir conifer',pine);
reg('petals','trees','🌸','Fallen Petals','بتلات متساقطة','petals ground flowers بتلات',petals);
reg('torii','jp','⛩','Torii Gate','بوابة توري','torii gate shrine red بوابة',()=>torii(1,'#c4281c'));
reg('torii_s','jp','⛩','Small Torii','توري صغيرة','torii small gate',()=>torii(.6,'#c4281c'));
reg('torii_w','jp','⛩','Wooden Torii','توري خشبية','torii wood brown',()=>torii(1,'#7a4a34','#2a1f1c'));
reg('pagoda','jp','🏯','Pagoda','معبد باغودا','pagoda temple tower معبد',pagoda);
reg('house','jp','🏠','Japanese House','بيت ياباني','house home village بيت',house);
reg('stall','jp','🏪','Market Stall','كشك سوق','stall shop market كشك',stall);
reg('fence','jp','🚧','Wooden Fence','سياج خشبي','fence wood سياج',fence);
reg('bridge','jp','🌉','Wooden Bridge','جسر خشبي','bridge red جسر',bridge);
reg('stones','jp','🪨','Stepping Stones','ممر أحجار','path stones stepping ممر',stones);
reg('lantern','lights','🏮','Stone Lantern','فانوس حجري','lantern stone ishidoro فانوس',()=>stoneLantern('#b9b7b2','#ffcf7a'));
reg('lantern_p','lights','🏮','Pink Lantern','فانوس وردي','lantern pink sakura فانوس',()=>stoneLantern('#efe3e8','#ff9fcf'));
reg('lamp','lights','💡','Garden Lamp','عمود إنارة','lamp post light street إنارة',lamp);
reg('paper','lights','🏮','Paper Lantern','فانوس ورقي','paper lantern chochin',paperLantern);
reg('barrel','props','🛢','Barrel','برميل','barrel wood',barrel);
reg('crate','props','📦','Crate','صندوق','crate box wood',crate);
reg('cart','props','🛒','Wooden Cart','عربة خشبية','cart wagon',cart);
reg('bench','props','🪑','Bench','مقعد','bench seat chair',bench);
reg('rock','nature','🪨','Rock','صخرة','rock stone boulder',rock);
reg('rocks','nature','🪨','Rock Cluster','مجموعة صخور','rocks cluster stones',rocks);
reg('mushrooms','nature','🍄','Mushrooms','فطر','mushroom',mushrooms);
reg('flowers','nature','🌼','Flowers','زهور','flowers garden',flowers);
reg('bush','nature','🌿','Bush','شجيرة','bush shrub',bush);
reg('tuft','nature','🌱','Grass Tuft','عشب','grass tuft',tuft);
reg('pond','nature','💧','Pond','بركة','pond lake water',pond);
reg('hill','nature','⛰','Grass Hill','تل عشبي','hill terrain mountain تل',hill);

/* Packs: several models placed together in one tap. Entry = [modelId, dx, dz, yaw, scale] */
const PI=Math.PI;
const pack=(id,ico,en,ar,kw,list)=>ML.push({id,cat:'packs',ico,en,ar,kw,fn:null,pack:list});
pack('pk_garden','🎍','Japanese Garden','حديقة يابانية','japanese garden zen pond bridge sakura lantern حديقة يابانية',
 [['pond',0,0,0,1],['bridge',0,0,PI/2,1],['sakura',-19,-10,0,1.1],['sakura_l',19,-12,2,1],['sakura_w',-16,17,4,1],['weeping',18,17,1,1],
  ['lantern',-8,13,.5,1],['lantern',8,13,-.5,1],['torii_s',0,-26,0,1],['stones',-3,15,0,1],['bush',-23,2,0,1],['bush',23,2,2,1],['flowers',-10,-17,0,1],['flowers',11,-18,1,1],['rocks',-24,-18,0,1],['petals',-7,5,0,1],['petals',9,-5,1,1]]);
pack('pk_shrine','⛩','Shrine Entrance','مدخل المعبد','shrine entrance torii path lantern معبد مدخل بوابة',
 [['torii',0,0,0,1],['torii_w',0,-18,0,.8],['lantern_p',-7,-9,.4,.9],['lantern_p',7,-9,-.4,.9],['lantern_p',-7,-27,.4,.9],['lantern_p',7,-27,-.4,.9],['stones',0,4,0,1],['sakura',-14,-6,0,1],['sakura',14,-14,2,1],['petals',-3,-12,0,1],['petals',4,-24,1,1]]);
pack('pk_village','🏘','Small Village','قرية صغيرة','village houses market stall barrel cart قرية بيوت سوق',
 [['house',-20,0,PI/2,1],['house',20,0,-PI/2,1],['stall',-8,14,PI,1],['stall',8,14,PI,1],['barrel',-3,12,0,1],['crate',3,12,0,1],['cart',0,22,.4,1],['lamp',-10,8,0,1],['lamp',10,8,0,1],['bench',0,-12,0,1],['sakura',0,-24,0,1.2],['fence',-26,-14,PI/2,1],['fence',26,-14,PI/2,1]]);
pack('pk_grove','🌸','Sakura Grove','بستان ساكورا','sakura grove forest trees cherry blossom pink بستان ساكورا غابة',
 [['sakura',0,0,0,1.2],['sakura_l',-16,-6,1,1],['sakura_w',15,-8,2,1],['sakura_p',-8,15,3,1],['weeping',12,14,0,1],['sakura',-22,12,5,.9],['sakura',24,4,4,.9],['petals',-5,6,0,1],['petals',7,-3,2,1],['petals',-12,-1,1,1],['flowers',3,9,0,1],['bush',-3,-12,0,1],['lantern_p',-7,3,0,.9],['lantern_p',8,5,0,.9]]);

/* ---------------- Placement ---------------- */
const GRX=/floor|terrain|hill|ground|lake|sand|baseplate/i;
function groundY(x,z){const rc=new T.Raycaster(new T.Vector3(x,800,z),new T.Vector3(0,-1,0)),gs=items.filter(m=>GRX.test(m.userData.name)||m.userData.t=='spawn'||(m.userData.t=='block'&&m.scale.x>=24&&m.scale.z>=24&&m.scale.y<=3));gs.push(base);const h=rc.intersectObjects(gs,false)[0];return h?Math.max(0,h.point.y):0}
function addModel(id,o){o=o||{};const d=ML.find(x=>x.id==id);if(!d)return[];
 const ox=o.x!=null?o.x:Math.round(tg.x),oz=o.z!=null?o.z:Math.round(tg.z),gy=o.y!=null?o.y:groundY(ox,oz),yaw=o.yaw||0,k=o.k||1,pre=o.prefix||d.en.replace(/\s+/g,'');
 const cq=new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),yaw),made=[];
 (k!=1?scaleList(d.fn(),k):d.fn()).forEach(sp=>{const v=new T.Vector3(sp.p[0],sp.p[1],sp.p[2]).applyQuaternion(cq),q=new T.Quaternion().setFromEuler(new T.Euler(sp.r[0]*Math.PI/180,sp.r[1]*Math.PI/180,sp.r[2]*Math.PI/180,'XYZ')).premultiply(cq),e=new T.Euler().setFromQuaternion(q,'XYZ');
  made.push(mk(sp.t,{p:[ox+v.x,gy+v.y,oz+v.z],r:[e.x,e.y,e.z],s:sp.s.slice(),n:pre+'_'+sp.n,c:hexn(sp.c),m:sp.m,tr:sp.tr||0,co:sp.co!==false}))});
 return made}
const OFFS=[[0,0],[10,0],[-10,0],[0,10],[0,-10],[10,10],[-10,10],[10,-10],[-10,-10]];let lastTg=null,addK=0;
function nextOff(){const key=Math.round(tg.x)+','+Math.round(tg.z);if(key!=lastTg){lastTg=key;addK=0}else addK++;const g=OFFS[addK%9],r=1+Math.floor(addK/9);return[g[0]*r,g[1]*r]}
const RC=ls.g('ms_recent',[]);
function placeModel(id){const d=ML.find(x=>x.id==id),off=nextOff(),kk=d.pack?3:1,bx=Math.round(tg.x)+off[0]*kk,bz=Math.round(tg.z)+off[1]*kk;let made=[];
 if(d.pack)d.pack.forEach(q=>{made=made.concat(addModel(q[0],{x:bx+q[1],z:bz+q[2],yaw:q[3],k:q[4],prefix:'Pk_'+q[0]}))});else made=addModel(id,{x:bx,z:bz});
 const ri=RC.indexOf(id);if(ri>=0)RC.splice(ri,1);RC.unshift(id);if(RC.length>12)RC.length=12;ls.s('ms_recent',RC);
 select(null);made.forEach(m=>select(m,true));save();const nm=isAr()?d.ar:d.en;toast('✓ '+L('Added')+' '+nm+' · '+made.length+' '+L('parts'));log(L('Added')+' '+d.en+' ('+made.length+' parts)')}

/* ---------------- Toolbox panel ---------------- */
let tbCat='all',tbQ='';const TGP={S:120,hills:4,H:12,seed:7,dens:35,lake:true,deco:true,replace:true};
const CATS=[['all','All','✦'],['packs','Packs','🎍'],['recent','Recent','🕘'],['trees','Trees','🌸'],['jp','Japanese','⛩'],['lights','Lights','🏮'],['props','Props','📦'],['nature','Nature','🪨']];
function gridHTML(){const tk=tbQ.trim().toLowerCase().split(/\s+/).filter(Boolean);
 let l=ML.filter(m=>{if(tbCat=='recent')return RC.includes(m.id);if(tbCat!='all'&&m.cat!=tbCat)return false;const h=(m.en+' '+m.ar+' '+m.kw).toLowerCase();return tk.every(w=>h.includes(w))});
 if(tbCat=='recent')l.sort((a,b)=>RC.indexOf(a.id)-RC.indexOf(b.id));
 return`<div class="sec">${esc(L('Models'))} · ${l.length}</div><div class="tg">${l.map(m=>`<button data-ml="${m.id}"><b>${m.ico}</b>${esc(isAr()?m.ar:m.en)}</button>`).join('')}</div>`}
function renderToolbox(){const nr=(k,lab)=>`<div class="r"><label>${esc(L(lab))}</label><div class="v"><input type="number" data-tp="${k}" value="${TGP[k]}"></div></div>`,ck=(k,lab)=>`<label class="ck"><input type="checkbox" data-tp="${k}"${TGP[k]?' checked':''}> ${esc(L(lab))}</label>`;
 $('box').innerHTML=`<div class="tbs"><input type="text" id="tbq" placeholder="${esc(L('Search models'))}" value="${esc(tbQ)}" autocomplete="off"></div>
<div class="chips">${CATS.map(c=>`<button data-cat="${c[0]}" class="${tbCat==c[0]?'on':''}">${c[2]} ${esc(L(c[1]))}</button>`).join('')}</div>
<div id="tbg">${gridHTML()}</div><div class="nt">🛡 ${esc(L('Built-in models: no hidden scripts'))}</div>
<div class="sec">${esc(L('Basic parts'))}</div><div class="tg">${TB.map((t,i)=>`<button data-b="${i}"><b>${t[3]}</b>${esc(L(t[0]))}</button>`).join('')}<button data-w="bld"><b>▦</b>${esc(L('Building'))}</button><button data-w="chr"><b>♙</b>${esc(L('Character'))}</button><button data-w="cut"><b>▧</b>${esc(L('Cutout'))}</button></div>
<div class="sec">${esc(L('Terrain'))}</div>
<div class="tp"><div class="tg"><button data-sk class="hl2"><b>🌸</b>${esc(L('Sakura map'))}</button></div>
${nr('S','Area')}${nr('hills','Hills')}${nr('H','Height')}${nr('seed','Seed')}${nr('dens','Trees density')}
<div class="ckr">${ck('lake','Lake')}${ck('deco','Flowers & rocks')}${ck('replace','Replace previous')}</div>
<div class="rw2"><button data-tg class="on2">${esc(L('Generate terrain'))}</button><button data-tc>${esc(L('Clear generated'))}</button></div></div>`}
$('box').addEventListener('input',e=>{const t=e.target;
 if(t.id=='tbq'){tbQ=t.value;$('tbg').innerHTML=gridHTML()}
 else if(t.dataset.tp){const k=t.dataset.tp;TGP[k]=t.type=='checkbox'?t.checked:(parseFloat(t.value)||0)}});
$('box').addEventListener('click',e=>{const t=e.target;let b;
 if(b=t.closest('[data-ml]'))placeModel(b.dataset.ml);
 else if(b=t.closest('[data-cat]')){tbCat=b.dataset.cat;document.querySelectorAll('#box .chips button').forEach(x=>x.classList.toggle('on',x==b));$('tbg').innerHTML=gridHTML()}
 else if(t.closest('[data-tg]')){const o=clone(TGP);o.S=Math.max(40,Math.min(300,o.S));o.hills=Math.max(0,Math.min(14,o.hills|0));o.H=Math.max(2,Math.min(60,o.H));o.dens=Math.max(0,Math.min(100,o.dens));genTerrain(o);toast('✓ '+L('Terrain generated'))}
 else if(t.closest('[data-tc]')){select(null);const n=clearGen();save();toast(L('Cleared')+' · '+n+' '+L('parts'))}
 else if(t.closest('[data-sk]'))sakuraMap()});

/* ---------------- Terrain generator + Sakura template ---------------- */
function clearGen(){const del=items.filter(m=>/^(Terrain|TG_)/.test(m.userData.name));del.forEach(m=>{sc.remove(m);items.splice(items.indexOf(m),1)});return del.length}
function genTerrain(o){o=Object.assign({S:120,hills:4,H:12,seed:7,dens:35,lake:true,deco:true,replace:true,theme:'gen',hillList:null,avoid:[]},o);
 select(null);if(o.replace)clearGen();
 const g=rnd(o.seed*977+5),S=o.S,gy=groundY(0,0),hs=[];
 if(o.hillList)o.hillList.forEach(h=>hs.push({x:h[0],z:h[1],r:h[2],h:h[3]}));
 else for(let i=0;i<o.hills;i++){const a=g()*6.283,d=S*(.22+.26*g()),r=S*(.1+.13*g()),h=o.H*(.45+.55*g());hs.push({x:Math.cos(a)*d,z:Math.sin(a)*d,r,h})}
 const gc=['#5fa24b','#6aae55','#4f9141','#78b95e'];
 hs.forEach((h,i)=>mk('ball',{p:[h.x,gy,h.z],r:[0,0,0],s:[h.r*2,h.h*2,h.r*2],n:'Terrain_Hill'+(i+1),c:hexn(gc[i%4]),m:'Grass'}));
 const hAt=(x,z)=>{let m=0;hs.forEach(h=>{const q=1-((x-h.x)*(x-h.x)+(z-h.z)*(z-h.z))/(h.r*h.r);if(q>0)m=Math.max(m,h.h*Math.sqrt(q))});return m};
 let lake=null;
 if(o.lake){for(let t=0;t<40&&!lake;t++){const x=(g()*2-1)*S*.35,z=(g()*2-1)*S*.35,r=S*(.07+.05*g());if(Math.hypot(x,z)<r+14)continue;let ok=hAt(x,z)<.3;for(let a=0;a<8&&ok;a++)ok=hAt(x+Math.cos(a)*r*1.4,z+Math.sin(a)*r*1.4)<.3;if(ok)lake={x,z,r}}
  if(lake){mk('cyl',{p:[lake.x,gy+.15,lake.z],r:[0,0,Math.PI/2],s:[.3,lake.r*2+5,lake.r*2+5],n:'Terrain_Sand',c:0xe6d6a8,m:'Concrete'});mk('cyl',{p:[lake.x,gy+.22,lake.z],r:[0,0,Math.PI/2],s:[.4,lake.r*2,lake.r*2],n:'Terrain_Water',c:0x4aa8d8,m:'Glass',tr:.35,co:false})}}
 const bad=(x,z)=>(lake&&Math.hypot(x-lake.x,z-lake.z)<lake.r*1.5+3)||Math.hypot(x,z)<9||o.avoid.some(f=>f(x,z));
 const pick=w=>{let r=g(),a=0;for(const q of w){a+=q[1];if(r<=a)return q[0]}return w[0][0]};
 const nT=Math.min(60,Math.round(o.dens/100*S/4)),wT=o.theme=='sakura'?[['sakura',.5],['sakura_w',.15],['sakura_p',.1],['weeping',.12],['maple',.06],['sakura_l',.07]]:[['pine',.4],['sakura',.2],['maple',.2],['sakura_w',.1],['sakura_p',.1]];
 const put=(id,k)=>{const x=(g()*2-1)*S*.48,z=(g()*2-1)*S*.48;if(bad(x,z))return false;addModel(id,{x,z,y:gy+hAt(x,z)-.15,yaw:g()*6.283,k,prefix:'TG_'+id});return true};
 for(let i=0,t=0;i<nT&&t<nT*8;t++)if(put(pick(wT),.85+g()*.5))i++;
 const nD=o.deco?Math.round(nT*1.6):0,wD=[['flowers',.3],['mushrooms',.12],['rock',.16],['rocks',.1],['bush',.14],['petals',.12],['tuft',.06]];
 for(let i=0,t=0;i<nD&&t<nD*8;t++)if(put(pick(wD),.8+g()*.4))i++;
 save();log('Terrain: '+hs.length+' hills'+(lake?', lake':'')+', '+nT+' trees');return{hs,lake,gy,hAt}}
function sakuraMap(){
 const hl=[[-75,-30,28,12],[75,-35,30,14],[0,-115,42,18],[-62,42,26,9],[68,46,27,10]];
 const R_=genTerrain({S:150,dens:0,lake:false,deco:false,theme:'sakura',hillList:hl,seed:11});
 const gy=R_.gy,g=rnd(21);
 for(let i=0;i<22;i++){const z=2-i*2.4,x=Math.sin(i*.45)*1.8;mk('cyl',{p:[x,gy+.15,z],r:[0,0,Math.PI/2],s:[.3,2.4,2.4],n:'TG_Path'+i,c:hexn(['#9a9aa0','#8b8b92','#a5a5ab'][i%3]),m:'Slate'})}
 addModel('torii',{x:0,z:-14,prefix:'TG_Torii'});addModel('torii_w',{x:0,z:-32,k:.8,prefix:'TG_Torii'});
 [-6,-20,-38].forEach(z=>[-7.5,7.5].forEach(x=>addModel('lantern_p',{x,z,k:.9,yaw:x<0?.4:-.4,prefix:'TG_Lantern'})));
 addModel('pagoda',{x:0,z:-76,k:1.1,prefix:'TG_Pagoda'});
 addModel('house',{x:-32,z:-46,yaw:Math.PI/2,prefix:'TG_House'});addModel('house',{x:32,z:-46,yaw:-Math.PI/2,prefix:'TG_House'});
 addModel('stall',{x:-14,z:-8,yaw:Math.PI/2,prefix:'TG_Stall'});addModel('bridge',{x:30,z:12,yaw:Math.PI/2,prefix:'TG_Bridge'});addModel('pond',{x:30,z:12,prefix:'TG_Pond'});
 [[-9,-24],[9,-24],[-9,-44],[9,-44]].forEach(q=>addModel('fence',{x:q[0],z:q[1],yaw:Math.PI/2,prefix:'TG_Fence'}));
 [[-4,-4],[5,-18],[-5,-30],[4,-46]].forEach(q=>addModel('petals',{x:q[0],z:q[1],prefix:'TG_Petals'}));
 const inCorr=(x,z)=>Math.abs(x)<10&&z>-92&&z<12,nearB=(x,z)=>Math.hypot(x+32,z+46)<16||Math.hypot(x-32,z+46)<16||Math.hypot(x,z+76)<18||Math.hypot(x-30,z-12)<18||Math.hypot(x+14,z+8)<7;
 const hAt=R_.hAt,wT=[['sakura',.5],['sakura_w',.15],['sakura_p',.1],['weeping',.12],['maple',.06],['sakura_l',.07]],pick=w=>{let r=g(),a=0;for(const q of w){a+=q[1];if(r<=a)return q[0]}return w[0][0]};
 for(let i=0,t=0;i<26&&t<400;t++){const x=(g()*2-1)*72,z=(g()*2-1)*72-20;if(inCorr(x,z)||nearB(x,z)||Math.hypot(x,z)<9)continue;i++;const id=pick(wT);addModel(id,{x,z,y:gy+hAt(x,z)-.15,yaw:g()*6.283,k:.9+g()*.5,prefix:'TG_'+id})}
 const dec=['flowers','mushrooms','rock','bush','petals','tuft','flowers'];
 for(let i=0,t=0;i<30&&t<500;t++){const x=(g()*2-1)*72,z=(g()*2-1)*72-20;if(Math.abs(x)<5.5||nearB(x,z)||Math.hypot(x,z)<7)continue;i++;const id=dec[Math.floor(g()*dec.length)];addModel(id,{x,z,y:gy+hAt(x,z)-.1,yaw:g()*6.283,k:.8+g()*.4,prefix:'TG_'+id})}
 LT=mg(clone(DEF),PRE.sakura);LT.theme='sakura';applyLight();renderLight();saveLT();
 if(!SND.length){SND.push({name:'Music',sid:'',vol:.5,loop:true,play:true},{name:'Wind',sid:'',vol:.25,loop:true,play:true});saveSnd();renderSnd()}
 tg.set(0,6,-22);rad=95;th=.35;ph=.42;upCam();select(null);save();toast('✓ '+L('Sakura map built')+' · '+items.length+' '+L('parts'));log('Sakura map built ('+items.length+' parts)')}

/* ---------------- Lighting state ---------------- */
const DEF={theme:'classic',clock:14,sunI:.7,ambI:.9,sunC:'#ffffff',ambS:'#ffffff',ambG:'#778899',skyT:'#a5c8ee',skyH:'#a5c8ee',glow:0,stars:0,shadow:true,
 atm:{on:false,den:.1,haze:1,col:'#c9def2'},bloom:{on:false,int:.4,size:24,thr:.8},rays:{on:false,int:.3,spread:.9},cc:{on:false,bri:0,con:0,sat:0,tint:'#ffffff'},dof:{on:false,far:.6,near:0,focus:60,rad:40}};
const PRE={
 day:{clock:13,sunI:.8,ambI:.95,sunC:'#fff4e0',ambS:'#dbe9ff',ambG:'#8a8f7a',skyT:'#4f95e0',skyH:'#bfdcf5',glow:1,atm:{on:true,den:.12,haze:1,col:'#c9def2'},bloom:{on:true,int:.25,size:24,thr:.85},cc:{on:true,bri:0,con:.05,sat:.1,tint:'#ffffff'}},
 sakura:{clock:17.4,sunI:.85,ambI:1,sunC:'#ffb48a',ambS:'#ffd3e2',ambG:'#9a6f86',skyT:'#e8789f',skyH:'#ffc3ad',glow:1,atm:{on:true,den:.3,haze:3,col:'#f7b9c8'},bloom:{on:true,int:.65,size:30,thr:.72},rays:{on:true,int:.35,spread:.85},cc:{on:true,bri:.02,con:.08,sat:.18,tint:'#ffe6ee'}},
 night:{clock:0,sunI:.28,ambI:.55,sunC:'#8da4ff',ambS:'#2b3a6b',ambG:'#10131f',skyT:'#04061a',skyH:'#16224a',glow:0,stars:1,atm:{on:true,den:.2,haze:2,col:'#0f1a36'},bloom:{on:true,int:.9,size:34,thr:.6},cc:{on:true,bri:-.03,con:.1,sat:-.05,tint:'#dfe8ff'}},
 forest:{clock:9,sunI:.7,ambI:.85,sunC:'#fff0c8',ambS:'#c9dcc8',ambG:'#4e6a4a',skyT:'#8fb0b8',skyH:'#d3e0df',glow:1,atm:{on:true,den:.55,haze:5,col:'#bccdc8'},bloom:{on:true,int:.4,size:28,thr:.8},rays:{on:true,int:.6,spread:.9},cc:{on:true,bri:0,con:.1,sat:-.05,tint:'#f2fff2'}},
 neon:{clock:22,sunI:.4,ambI:.9,sunC:'#ff7ad9',ambS:'#ff6fd0',ambG:'#4a1b5a',skyT:'#2a0a3f',skyH:'#a0268f',glow:0,stars:.5,atm:{on:true,den:.25,haze:3,col:'#c042b0'},bloom:{on:true,int:1.1,size:36,thr:.55},cc:{on:true,bri:0,con:.15,sat:.3,tint:'#ffd9f5'}}};
let LT=clone(DEF),SND=[];
const THEMES=[['classic','Classic','◻'],['day','Day','☀'],['sakura','Sakura Dusk','🌸'],['night','Night','🌙'],['forest','Misty Forest','🌫'],['neon','Neon Pink','💗']];
const saveLT=(()=>{let t;return()=>{clearTimeout(t);t=setTimeout(()=>ls.s('ms_lt:'+MP.cur,LT),350)}})();
const saveSnd=()=>ls.s('ms_snd:'+MP.cur,SND);

/* ---------------- Scene: sky dome, sun, fog, shadows ---------------- */
const hemi=sc.children.find(o=>o.isHemisphereLight),skyDir=new T.Vector3(0,1,0),lightDir=new T.Vector3(0,1,0);
const skyMat=new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,
 uniforms:{top:{value:new T.Color()},hor:{value:new T.Color()},fogC:{value:new T.Color()},scol:{value:new T.Color()},sdir:{value:new T.Vector3(0,1,0)},fogA:{value:0},stars:{value:0},sunUp:{value:0}},
 vertexShader:'varying vec3 vD;void main(){vD=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:`uniform vec3 top,hor,fogC,scol,sdir;uniform float fogA,stars,sunUp;varying vec3 vD;
float h21(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
void main(){vec3 d=normalize(vD);float h=clamp(d.y,0.,1.);vec3 c=mix(hor,top,pow(h,.55));
 if(d.y<0.)c=mix(hor,hor*.7,clamp(-d.y*3.,0.,1.));
 float s=max(dot(d,normalize(sdir)),0.);float g=(pow(s,900.)*3.+pow(s,40.)*.45+pow(s,6.)*.18)*sunUp;c+=scol*g;
 if(stars>0.&&d.y>.02){vec2 uv=vec2(atan(d.x,d.z)*40.,d.y*90.);vec2 id=floor(uv*1.6);float r=h21(id);float tw=step(.9965,r)*(.6+.4*h21(id+7.));c+=vec3(tw)*stars*smoothstep(.02,.25,d.y);}
 c=mix(c,fogC,fogA*(1.-pow(h,.45)));gl_FragColor=vec4(c,1.);}`});
const sky=new T.Mesh(new T.SphereGeometry(1400,32,16),skyMat);sky.renderOrder=-100;sky.frustumCulled=false;sc.add(sky);
sc.add(sun.target);
const mobile=matchMedia('(pointer:coarse)').matches;
sun.castShadow=true;sun.shadow.mapSize.set(mobile?1024:2048,mobile?1024:2048);sun.shadow.bias=-.0006;sun.shadow.normalBias=.35;sun.shadow.camera.near=1;sun.shadow.camera.far=520;
let shHalf=0;
const _mk=mk;mk=function(t,o){const m=_mk(t,o);m.castShadow=true;m.receiveShadow=true;return m};
items.forEach(m=>{m.castShadow=m.receiveShadow=true});base.receiveShadow=true;
function matsDirty(){items.forEach(m=>m.material.needsUpdate=true);base.material.needsUpdate=true}
function applyLight(){const l=LT;
 hemi.color.set(l.ambS);hemi.groundColor.set(l.ambG);hemi.intensity=l.ambI;sun.color.set(l.sunC);sun.intensity=l.sunI;
 const a=(l.clock-6)/12*Math.PI,sy=Math.sin(a),dx=-Math.cos(a)*.9;
 skyDir.set(dx,sy,.35).normalize();lightDir.set(dx,Math.max(.22,Math.abs(sy)),.35).normalize();
 const u=skyMat.uniforms;u.top.value.set(l.skyT);u.hor.value.set(l.skyH);u.fogC.value.set(l.atm.col);u.scol.value.set(l.sunC);u.sdir.value.copy(skyDir);u.stars.value=l.stars;u.sunUp.value=sy>-.05?l.glow:0;
 const fd=l.atm.on?l.atm.den*.012*(1+l.atm.haze*.12):0;u.fogA.value=l.atm.on?Math.min(.9,l.atm.den*1.6):0;
 if(fd>0){if(!sc.fog)sc.fog=new T.FogExp2(0xffffff,fd);sc.fog.color.set(l.atm.col);sc.fog.density=fd}else sc.fog=null;
 sc.background=new T.Color(l.skyH);
 if(ren.shadowMap.enabled!=l.shadow){ren.shadowMap.enabled=l.shadow;ren.shadowMap.type=T.PCFSoftShadowMap;matsDirty()}
 sun.castShadow=l.shadow}
ren.shadowMap.enabled=false;

/* ---------------- Post-processing (Bloom · SunRays · ColorCorrection · DepthOfField) ---------------- */
const origRender=ren.render.bind(ren);
const Post=(function(){
 let W=0,H=0,rtS,rtD,rtR,B=[],bad=false;
 const VS='varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
 const sm=(fs,u)=>new T.ShaderMaterial({uniforms:u,vertexShader:VS,fragmentShader:fs,depthTest:false,depthWrite:false});
 const qs=new T.Scene(),qc=new T.OrthographicCamera(-1,1,1,-1,0,1),quad=new T.Mesh(new T.PlaneGeometry(2,2));quad.frustumCulled=false;qs.add(quad);
 const bright=sm('uniform sampler2D tD;uniform float thr;varying vec2 vUv;void main(){vec3 c=texture2D(tD,vUv).rgb;float l=dot(c,vec3(.299,.587,.114));float k=smoothstep(thr,thr+.2,l);gl_FragColor=vec4(c*k,1.);}',{tD:{value:null},thr:{value:.8}});
 const blur=sm('uniform sampler2D tD;uniform vec2 dir;varying vec2 vUv;void main(){vec3 s=texture2D(tD,vUv).rgb*.2270270270;s+=texture2D(tD,vUv+dir*1.3846153846).rgb*.3162162162;s+=texture2D(tD,vUv-dir*1.3846153846).rgb*.3162162162;s+=texture2D(tD,vUv+dir*3.2307692308).rgb*.0702702703;s+=texture2D(tD,vUv-dir*3.2307692308).rgb*.0702702703;gl_FragColor=vec4(s,1.);}',{tD:{value:null},dir:{value:new T.Vector2()}});
 const fin=sm(`uniform sampler2D tS,tB1,tB2,tR,tZ;uniform vec2 res;uniform float uBl,uBlW,uRay,uSpread,sunVis,uCC,dofOn,dofFar,dofNear,dofFocus,dofRad;uniform vec2 sunUV;uniform vec3 sunCol,cc,tint;varying vec2 vUv;
float getZ(vec2 uv){vec4 t=texture2D(tZ,uv);return(t.r+t.g/255.)*1024.;}
void main(){vec3 col=texture2D(tS,vUv).rgb;
 if(dofOn>.5){float z=getZ(vUv);float coc=0.;
  if(z>dofFocus+dofRad)coc=dofFar*clamp((z-dofFocus-dofRad)/(dofFocus*1.2+12.),0.,1.);
  else if(z<dofFocus-dofRad)coc=dofNear*clamp((dofFocus-dofRad-z)/(dofFocus*.7+6.),0.,1.);
  if(coc>.01){vec3 a=col;float ws=1.;float rad=coc*14.;
   for(int i=0;i<16;i++){float fi=float(i)+1.;float r=sqrt(fi/16.)*rad;float th=fi*2.39996;vec2 o=vec2(cos(th),sin(th))*r/res;a+=texture2D(tS,vUv+o).rgb;ws+=1.;}
   col=a/ws;}}
 col+=texture2D(tB1,vUv).rgb*uBl*uBlW+texture2D(tB2,vUv).rgb*uBl*(1.-uBlW);
 if(uRay>0.){vec2 d=sunUV-vUv;vec2 st=d*(uSpread/24.);vec2 uv=vUv;float dec=1.;vec3 acc=vec3(0.);
  for(int i=0;i<24;i++){uv+=st;acc+=texture2D(tR,uv).rgb*dec;dec*=.94;}
  float fall=clamp(1.2-length(d),0.,1.);col+=acc/24.*uRay*2.2*sunVis*fall*sunCol;}
 if(uCC>.5){col+=cc.x;col=(col-.5)*(1.+cc.y)+.5;float l=dot(col,vec3(.299,.587,.114));col=mix(vec3(l),col,1.+cc.z);col*=tint;}
 gl_FragColor=vec4(max(col,0.),1.);}`,{tS:{value:null},tB1:{value:null},tB2:{value:null},tR:{value:null},tZ:{value:null},res:{value:new T.Vector2(1,1)},uBl:{value:0},uBlW:{value:.55},uRay:{value:0},uSpread:{value:.9},sunVis:{value:0},uCC:{value:0},dofOn:{value:0},dofFar:{value:0},dofNear:{value:0},dofFocus:{value:50},dofRad:{value:30},sunUV:{value:new T.Vector2(.5,.5)},sunCol:{value:new T.Color()},cc:{value:new T.Vector3()},tint:{value:new T.Color()}});
 const depthMat=new T.ShaderMaterial({side:T.DoubleSide,vertexShader:'varying float vZ;void main(){vec4 mv=modelViewMatrix*vec4(position,1.);vZ=-mv.z;gl_Position=projectionMatrix*mv;}',fragmentShader:'varying float vZ;void main(){float d=clamp(vZ/1024.,0.,1.);float hi=floor(d*255.)/255.;float lo=fract(d*255.);gl_FragColor=vec4(hi,lo,0.,1.);}'});
 const mkRT=(w,h,ms)=>{const o={minFilter:T.LinearFilter,magFilter:T.LinearFilter,format:T.RGBAFormat};return ms&&ren.capabilities.isWebGL2?new T.WebGLMultisampleRenderTarget(w,h,o):new T.WebGLRenderTarget(w,h,o)};
 const dis=()=>{[rtS,rtD,rtR,...B].forEach(r=>r&&r.dispose())};
 function ensure(w,h){if(w==W&&h==H&&rtS)return;dis();W=w;H=h;const hw=Math.max(2,w>>1),hh=Math.max(2,h>>1),qw=Math.max(2,w>>2),qh=Math.max(2,h>>2),ew=Math.max(2,w>>3),eh=Math.max(2,h>>3);
  rtS=mkRT(w,h,true);rtD=new T.WebGLRenderTarget(w,h,{minFilter:T.NearestFilter,magFilter:T.NearestFilter});rtR=mkRT(qw,qh);
  B=[mkRT(hw,hh),mkRT(qw,qh),mkRT(qw,qh),mkRT(ew,eh),mkRT(ew,eh)]}
 const pass=(m,t)=>{quad.material=m;ren.setRenderTarget(t);origRender(qs,qc)};
 const v2=new T.Vector2(),fw=new T.Vector3(),sp=new T.Vector3();
 function render(){const l=LT;ren.getDrawingBufferSize(v2);ensure(v2.x,v2.y);
  ren.setRenderTarget(rtS);origRender(sc,cam);
  if(l.dof.on){const bg=sc.background,cc=new T.Color(),ca=ren.getClearAlpha(),gv=gz.visible,ov=items.map(m=>m.userData.ol.visible);ren.getClearColor(cc);
   sc.background=null;sc.overrideMaterial=depthMat;gz.visible=false;items.forEach(m=>m.userData.ol.visible=false);ren.setClearColor(0xffff00,1);
   ren.setRenderTarget(rtD);origRender(sc,cam);
   sc.overrideMaterial=null;sc.background=bg;gz.visible=gv;items.forEach((m,i)=>m.userData.ol.visible=ov[i]);ren.setClearColor(cc,ca)}
  const wantB=l.bloom.on,wantR=l.rays.on,u=fin.uniforms;
  if(wantB){bright.uniforms.tD.value=rtS.texture;bright.uniforms.thr.value=l.bloom.thr;pass(bright,B[0]);
   const st=l.bloom.size/24;
   blur.uniforms.tD.value=B[0].texture;blur.uniforms.dir.value.set(st/B[0].width,0);pass(blur,B[1]);
   blur.uniforms.tD.value=B[1].texture;blur.uniforms.dir.value.set(0,st/B[1].height);pass(blur,B[2]);
   blur.uniforms.tD.value=B[2].texture;blur.uniforms.dir.value.set(st/B[2].width,0);pass(blur,B[3]);
   blur.uniforms.tD.value=B[3].texture;blur.uniforms.dir.value.set(0,st/B[3].height);pass(blur,B[4])}
  if(wantR){bright.uniforms.tD.value=rtS.texture;bright.uniforms.thr.value=.72;pass(bright,rtR);
   sp.copy(cam.position).addScaledVector(skyDir,1000).project(cam);cam.getWorldDirection(fw);
   u.sunUV.value.set(sp.x*.5+.5,sp.y*.5+.5);u.sunVis.value=(skyDir.y>-.02&&sp.z<1)?Math.max(0,Math.min(1,fw.dot(skyDir)*4)):0;u.sunCol.value.set(l.sunC)}
  u.tS.value=rtS.texture;u.tB1.value=B[2].texture;u.tB2.value=B[4].texture;u.tR.value=rtR.texture;u.tZ.value=rtD.texture;u.res.value.set(W,H);
  u.uBl.value=wantB?l.bloom.int*1.2:0;u.uRay.value=wantR?l.rays.int:0;u.uSpread.value=l.rays.spread;
  u.uCC.value=l.cc.on?1:0;u.cc.value.set(l.cc.bri,l.cc.con,l.cc.sat);u.tint.value.set(l.cc.tint);
  u.dofOn.value=l.dof.on?1:0;u.dofFar.value=l.dof.far;u.dofNear.value=l.dof.near;u.dofFocus.value=l.dof.focus;u.dofRad.value=l.dof.rad;
  pass(fin,null)}
 return{active:()=>!bad&&(LT.bloom.on||LT.rays.on||LT.cc.on||LT.dof.on),render,fail(){bad=true;ren.setRenderTarget(null)},get bad(){return bad}}})();

/* ---------------- Render hook ---------------- */
function frameHook(c){sky.position.copy(c.position);
 if(c===cam){const half=Math.max(40,Math.min(170,rad*1.25));
  sun.target.position.copy(tg);sun.position.copy(tg).addScaledVector(lightDir,170);sun.target.updateMatrixWorld();
  if(Math.abs(half-shHalf)>2){shHalf=half;const s=sun.shadow.camera;s.left=-half;s.right=half;s.top=half;s.bottom=-half;s.updateProjectionMatrix()}}}
ren.render=function(s,c){
 if(s===sc&&c===cam&&PL.on)stepPlay();
 frameHook(c);
 if(s===sc&&c===cam&&Post.active()){try{Post.render();return}catch(e){Post.fail();log(L('Post effects are not supported on this device')+': '+(e&&e.message||e),'e')}}
 origRender(s,c)};

/* ---------------- Lighting panel ---------------- */
const gv=p=>p.split('.').reduce((o,k)=>o[k],LT),sv=(p,v)=>{const a=p.split('.'),k=a.pop();a.reduce((o,x)=>o[x],LT)[k]=v};
const lc=(p,lab,mn,mx,st)=>`<div class="r"><label>${esc(L(lab))}</label><div class="v"><input type="range" data-lt="${p}" min="${mn}" max="${mx}" step="${st}" value="${gv(p)}"><output>${fmt(gv(p))}</output></div></div>`;
const lk=(p,lab)=>`<div class="r"><label>${esc(L(lab))}</label><div class="v"><input type="color" data-lt="${p}" value="${gv(p)}"></div></div>`;
const lh=(p,ico,lab,k)=>`<div class="sec fx" data-sec="${k}"><span>${ico} ${esc(L(lab))}</span><input type="checkbox" data-lt="${p}"${gv(p)?' checked':''}></div>`;
function renderLight(){const p=$('light');if(!p)return;
 p.innerHTML=`<div class="chips">${THEMES.map(t=>`<button data-th="${t[0]}" class="${LT.theme==t[0]?'on':''}">${t[2]} ${esc(L(t[1]))}</button>`).join('')}</div>
<div class="sec" data-sec="sky">🌤 ${esc(L('Sky & Sun'))}</div>${lc('clock','Clock time',0,24,.1)}${lc('sunI','Sun brightness',0,2,.05)}${lc('ambI','Ambient',0,2,.05)}${lk('sunC','Sun color')}${lk('skyT','Sky top')}${lk('skyH','Sky horizon')}${lk('ambS','Ambient sky')}${lk('ambG','Ambient ground')}${lc('stars','Stars',0,1,.05)}
<div class="r"><label>${esc(L('Shadows'))}</label><div class="v"><input type="checkbox" data-lt="shadow"${LT.shadow?' checked':''}></div></div>
${lh('atm.on','🌫','Atmosphere','atm')}${lc('atm.den','Density',0,1,.01)}${lc('atm.haze','Haze',0,10,.1)}${lk('atm.col','Color')}
${lh('bloom.on','✨','Bloom','bloom')}${lc('bloom.int','Intensity',0,2,.05)}${lc('bloom.size','Size',4,56,1)}${lc('bloom.thr','Threshold',0,1.2,.01)}
${lh('rays.on','☀','SunRays','rays')}${lc('rays.int','Intensity',0,1,.01)}${lc('rays.spread','Spread',0,1,.01)}
${lh('cc.on','🎨','ColorCorrection','cc')}${lc('cc.bri','Brightness',-.5,.5,.01)}${lc('cc.con','Contrast',-.5,1,.01)}${lc('cc.sat','Saturation',-1,1,.01)}${lk('cc.tint','Tint')}
${lh('dof.on','🔍','DepthOfField','dof')}${lc('dof.far','Far blur',0,1,.01)}${lc('dof.near','Near blur',0,1,.01)}${lc('dof.focus','Focus distance',5,300,1)}${lc('dof.rad','In-focus radius',0,300,1)}`}
$('light').addEventListener('click',e=>{const b=e.target.closest('[data-th]');if(!b)return;const id=b.dataset.th;LT=mg(clone(DEF),PRE[id]||{});LT.theme=id;applyLight();renderLight();saveLT();sync();log('Lighting: '+id)});
$('light').addEventListener('input',e=>{const t=e.target,p=t.dataset.lt;if(!p)return;
 let v=t.type=='checkbox'?t.checked:t.type=='range'?parseFloat(t.value):t.value;sv(p,v);
 if(t.type=='range'){const o=t.parentElement.querySelector('output');if(o)o.textContent=fmt(v)}
 if(t.type=='checkbox')sync();
 applyLight();saveLT()});

/* ---------------- Sound panel ---------------- */
const SPRE=[['Background Music',true,.5],['Rain',true,.4],['Wind',true,.3],['Ambience',true,.3],['Gate',false,.6],['Reward',false,.7]];
function renderSnd(){const p=$('snd');if(!p)return;
 p.innerHTML=`<div class="em" style="padding:8px 10px;font-size:12px;opacity:.8">${esc(L('Paste the Roblox audio ID (Creator Store → Audio → Copy ID). Exported as Sound objects; the editor cannot preview Roblox audio.'))}</div>
<div class="sec">${esc(L('Add sound'))}</div><div class="chips">${SPRE.map((s,i)=>`<button data-sp="${i}">＋ ${esc(L(s[0]))}</button>`).join('')}</div>`+
 SND.map((s,i)=>`<div class="sd" data-i="${i}"><div class="r"><input type="text" data-f="name" value="${esc(s.name)}"><button class="sb" data-x>✕</button></div>
<div class="r"><label>SoundId</label><div class="v"><input type="text" inputmode="numeric" data-f="sid" placeholder="123456789" value="${esc(s.sid)}"></div></div>
<div class="r"><label>${esc(L('Volume'))}</label><div class="v"><input type="range" data-f="vol" min="0" max="2" step=".05" value="${s.vol}"><output>${fmt(s.vol)}</output></div></div>
<div class="r"><label>${esc(L('Looped'))}</label><input type="checkbox" data-f="loop"${s.loop?' checked':''}><label>${esc(L('Playing'))}</label><input type="checkbox" data-f="play"${s.play?' checked':''}></div></div>`).join('');
 }
$('snd').addEventListener('click',e=>{let b=e.target.closest('[data-sp]');if(b){const s=SPRE[+b.dataset.sp];SND.push({name:s[0],sid:'',vol:s[2],loop:s[1],play:s[1]});saveSnd();renderSnd();sync();return}
 b=e.target.closest('[data-x]');if(b){SND.splice(+b.closest('[data-i]').dataset.i,1);saveSnd();renderSnd();sync()}});
$('snd').addEventListener('input',e=>{const t=e.target,r=t.closest('[data-i]'),f=t.dataset.f;if(!r||!f)return;const s=SND[+r.dataset.i];
 if(f=='sid'){s.sid=t.value.replace(/\D/g,'').slice(0,19)}else if(f=='vol'){s.vol=parseFloat(t.value);const o=t.parentElement.querySelector('output');if(o)o.textContent=fmt(s.vol)}else if(f=='loop'||f=='play')s[f]=t.checked;else s[f]=t.value.slice(0,40);saveSnd()});

/* ---------------- Explorer services ---------------- */
function openTab(d){document.querySelectorAll('#tabs button').forEach(x=>x.classList.toggle('on',x.dataset.d==d));document.querySelectorAll('.pn').forEach(x=>x.classList.toggle('on',x.id==d));$('dock').classList.remove('min')}
const _sync=sync;sync=function(){_sync();try{svcTree()}catch(e){}};
function svcTree(){const e=$('exp');if(!e)return;const on=k=>LT[k]&&LT[k].on?' ✓':'';
 e.insertAdjacentHTML('beforeend',`<div class="sec">${esc(L('Services'))}</div><div class="n" data-sv="light">▾ 💡 ${esc(L('Lighting'))}</div>`+
 [['atm','Atmosphere','🌫'],['bloom','Bloom','✨'],['rays','SunRays','☀'],['cc','ColorCorrection','🎨'],['dof','DepthOfField','🔍']].map(x=>`<div class="n c" data-sv="light:${x[0]}"><span>${x[2]}</span>${x[1]}${on(x[0])}</div>`).join('')+
 `<div class="n" data-sv="snd">🔊 SoundService (${SND.length})</div><div class="n" data-sv="outp">▤ ${esc(L('Output'))}</div>`)}
$('exp').addEventListener('click',e=>{const n=e.target.closest('[data-sv]');if(!n)return;const a=n.dataset.sv.split(':');openTab(a[0]);if(a[1])setTimeout(()=>{const t=document.querySelector('#light [data-sec="'+a[1]+'"]');if(t)t.scrollIntoView({block:'start'})},40)});

/* ---------------- Export additions ---------------- */
const c3=h=>{const c=new T.Color(h);return[c.r,c.g,c.b]},rgb=h=>c3(h).map(v=>Math.round(v*255)).join(','),xc=(n,h)=>{const c=c3(h);return`<Color3 name="${n}"><R>${f(c[0])}</R><G>${f(c[1])}</G><B>${f(c[2])}</B></Color3>`};
const _luau=luau;luau=function(){const l=LT;let s=_luau();
 s+='\n-- ===== Lighting (preview-approximate: tweak in Studio) =====\nlocal L=game:GetService("Lighting")\nfor _,c in ipairs(L:GetChildren()) do if c:IsA("PostEffect") or c:IsA("Atmosphere") then c:Destroy() end end\n';
 s+=`L.ClockTime=${f(l.clock)} L.Brightness=${f(l.sunI*2.5)} L.Ambient=Color3.fromRGB(${rgb(l.ambG)}) L.OutdoorAmbient=Color3.fromRGB(${rgb(l.ambS)}) L.ColorShift_Top=Color3.fromRGB(${rgb(l.sunC)})\n`;
 if(l.atm.on)s+=`do local a=Instance.new("Atmosphere") a.Density=${f(l.atm.den)} a.Offset=0 a.Color=Color3.fromRGB(${rgb(l.atm.col)}) a.Decay=Color3.fromRGB(${rgb(l.atm.col)}) a.Glare=0 a.Haze=${f(l.atm.haze)} a.Parent=L end\n`;
 if(l.bloom.on)s+=`do local b=Instance.new("BloomEffect") b.Intensity=${f(l.bloom.int)} b.Size=${f(l.bloom.size)} b.Threshold=${f(l.bloom.thr*2)} b.Parent=L end\n`;
 if(l.rays.on)s+=`do local r=Instance.new("SunRaysEffect") r.Intensity=${f(l.rays.int)} r.Spread=${f(l.rays.spread)} r.Parent=L end\n`;
 if(l.cc.on)s+=`do local c=Instance.new("ColorCorrectionEffect") c.Brightness=${f(l.cc.bri)} c.Contrast=${f(l.cc.con)} c.Saturation=${f(l.cc.sat)} c.TintColor=Color3.fromRGB(${rgb(l.cc.tint)}) c.Parent=L end\n`;
 if(l.dof.on)s+=`do local d=Instance.new("DepthOfFieldEffect") d.FarIntensity=${f(l.dof.far)} d.NearIntensity=${f(l.dof.near)} d.FocusDistance=${f(l.dof.focus)} d.InFocusRadius=${f(l.dof.rad)} d.Parent=L end\n`;
 if(SND.length){s+='\n-- ===== Sounds (fill SoundId with your Roblox audio IDs) =====\n';SND.forEach(q=>{s+=`do local s=Instance.new("Sound") s.Name="${nm(q.name)}" ${q.sid?`s.SoundId="rbxassetid://${q.sid}" `:''}s.Volume=${f(q.vol)} s.Looped=${q.loop} s.Parent=workspace${q.play&&q.sid?' s:Play()':''} end\n`})}
 return s};
const _xml=xml;xml=function(){const l=LT;let n=1,sd='',lt=`<Item class="Lighting" referent="RBXL0"><Properties><string name="Name">Lighting</string><float name="ClockTime">${f(l.clock)}</float><float name="Brightness">${f(l.sunI*2.5)}</float>${xc('Ambient',l.ambG)}${xc('OutdoorAmbient',l.ambS)}${xc('ColorShift_Top',l.sunC)}</Properties>`;
 if(l.atm.on)lt+=`<Item class="Atmosphere" referent="RBXL${n++}"><Properties><string name="Name">Atmosphere</string><float name="Density">${f(l.atm.den)}</float><float name="Offset">0</float>${xc('Color',l.atm.col)}${xc('Decay',l.atm.col)}<float name="Glare">0</float><float name="Haze">${f(l.atm.haze)}</float></Properties></Item>`;
 if(l.bloom.on)lt+=`<Item class="BloomEffect" referent="RBXL${n++}"><Properties><string name="Name">Bloom</string><bool name="Enabled">true</bool><float name="Intensity">${f(l.bloom.int)}</float><int name="Size">${Math.round(l.bloom.size)}</int><float name="Threshold">${f(l.bloom.thr*2)}</float></Properties></Item>`;
 if(l.rays.on)lt+=`<Item class="SunRaysEffect" referent="RBXL${n++}"><Properties><string name="Name">SunRays</string><bool name="Enabled">true</bool><float name="Intensity">${f(l.rays.int)}</float><float name="Spread">${f(l.rays.spread)}</float></Properties></Item>`;
 if(l.cc.on)lt+=`<Item class="ColorCorrectionEffect" referent="RBXL${n++}"><Properties><string name="Name">ColorCorrection</string><bool name="Enabled">true</bool><float name="Brightness">${f(l.cc.bri)}</float><float name="Contrast">${f(l.cc.con)}</float><float name="Saturation">${f(l.cc.sat)}</float>${xc('TintColor',l.cc.tint)}</Properties></Item>`;
 if(l.dof.on)lt+=`<Item class="DepthOfFieldEffect" referent="RBXL${n++}"><Properties><string name="Name">DepthOfField</string><bool name="Enabled">true</bool><float name="FarIntensity">${f(l.dof.far)}</float><float name="NearIntensity">${f(l.dof.near)}</float><float name="FocusDistance">${f(l.dof.focus)}</float><float name="InFocusRadius">${f(l.dof.rad)}</float></Properties></Item>`;
 lt+='</Item>';
 SND.forEach((q,i)=>{sd+=`<Item class="Sound" referent="RBXS${i}"><Properties><string name="Name">${xe(q.name)}</string><Content name="SoundId">${q.sid?`<url>rbxassetid://${q.sid}</url>`:'<null></null>'}</Content><float name="Volume">${f(q.vol)}</float><bool name="Looped">${q.loop}</bool><bool name="Playing">${!!(q.play&&q.sid)}</bool></Properties></Item>`});
 return _xml().replace(/<\/Item><\/roblox>$/,sd+'</Item>'+lt+'</roblox>')};

/* ---------------- Play mode ---------------- */
const PL={on:false,pos:new T.Vector3(),spawn:new T.Vector3(),vy:0,yaw:0,face:0,grp:null,legs:[],arms:[],jx:0,jy:0,jump:false,keys:{},ground:false,t:0,last:0,saved:null,cols:[]};
const PR=new T.Raycaster(),RAD=.7,CH=5,STEP=1.4,SPEED=16,GRAV=170,JUMP=50;
vp.insertAdjacentHTML('beforeend',`<div id="pl"><button id="ps">■ <span></span></button><div id="jz"><i id="jk"></i></div><button id="jb"><span></span></button><div id="ph"></div></div>`);
document.querySelector('#rib .g').insertAdjacentHTML('afterend','<div class="g"><button class="tb" id="playb" style="background:#2e9b4f;color:#fff;border-color:#2e9b4f">▶<small>Play</small></button></div>');
function mkChar(){const g=new T.Group(),M=c=>new T.MeshStandardMaterial({color:c,flatShading:true}),B=(w,h,d,c,x,y,z,par)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),M(c));m.position.set(x,y,z);m.castShadow=true;(par||g).add(m);return m};
 const skin=0xf5cd9a;B(2,2,1,0x0d69ac,0,3,0);B(1.2,1.2,1.2,skin,0,4.6,0);B(.2,.25,.1,0x111111,-.3,4.7,.62);B(.2,.25,.1,0x111111,.3,4.7,.62);
 const lim=(x,y,c,arr)=>{const p=new T.Group();p.position.set(x,y,0);B(1,2,1,c,0,-1,0,p);g.add(p);arr.push(p)};
 lim(-1.5,4,skin,PL.arms=[]);lim(1.5,4,skin,PL.arms);lim(-.5,2,0x4b974b,PL.legs=[]);lim(.5,2,0x4b974b,PL.legs);return g}
function spawnPoint(){const sp=items.find(m=>m.userData.t=='spawn');if(sp){const b=new T.Box3().setFromObject(sp);return new T.Vector3(sp.position.x,b.max.y+.05,sp.position.z)}return new T.Vector3(0,groundY(0,0)+.05,0)}
function startPlay(){if(PL.on)return;select(null);PL.cols=items.filter(m=>m.userData.co);PL.cols.push(base);
 PL.spawn.copy(spawnPoint());PL.pos.copy(PL.spawn);PL.vy=0;PL.face=Math.PI;PL.grp=mkChar();sc.add(PL.grp);
 PL.saved={th,ph,rad,tg:tg.clone()};th=0;ph=.32;rad=16;tg.set(PL.pos.x,PL.pos.y+3.4,PL.pos.z);upCam();
 PL.on=true;PL.last=performance.now();document.body.classList.add('playing');$('pl').classList.add('on');$('ph').textContent=L('Walking in your map…');setTimeout(()=>{$('ph').textContent=''},3500);log('Play: '+PL.cols.length+' collidable parts')}
function stopPlay(){if(!PL.on)return;PL.on=false;sc.remove(PL.grp);PL.grp=null;th=PL.saved.th;ph=PL.saved.ph;rad=PL.saved.rad;tg.copy(PL.saved.tg);upCam();
 document.body.classList.remove('playing');$('pl').classList.remove('on');PL.jx=PL.jy=0;PL.keys={};$('jk').style.transform='translate(-50%,-50%)';log(L('Stopped'))}
function blocked(dx,dz){const l=Math.hypot(dx,dz);if(l<1e-6)return false;const d=new T.Vector3(dx/l,0,dz/l),sd=new T.Vector3(-d.z,0,d.x);
 for(const h of[STEP+.05,CH*.5])for(const so of[0,.6,-.6]){PR.set(new T.Vector3(PL.pos.x+sd.x*so*RAD,PL.pos.y+h,PL.pos.z+sd.z*so*RAD),d);PR.far=RAD+l;if(PR.intersectObjects(PL.cols,false).length)return true}return false}
function stepPlay(){const now=performance.now(),dt=Math.min(.05,(now-PL.last)/1000||0);PL.last=now;const k=PL.keys;
 let ix=PL.jx+((k.d||k.arrowright)?1:0)-((k.a||k.arrowleft)?1:0),iy=PL.jy+((k.w||k.arrowup)?1:0)-((k.s||k.arrowdown)?1:0);const len=Math.hypot(ix,iy);if(len>1){ix/=len;iy/=len}
 const fx=-Math.sin(th),fz=-Math.cos(th),mx=fx*iy+(-fz)*ix,mz=fz*iy+fx*ix,mv=len>.08;
 if(mv){const tgt=Math.atan2(mx,mz);let d=tgt-PL.face;d=Math.atan2(Math.sin(d),Math.cos(d));PL.face+=d*Math.min(1,dt*14);
  const dx=mx*SPEED*dt,dz=mz*SPEED*dt;if(!blocked(dx,dz)){PL.pos.x+=dx;PL.pos.z+=dz}else if(!blocked(dx,0))PL.pos.x+=dx;else if(!blocked(0,dz))PL.pos.z+=dz}
 PL.vy=Math.max(-150,PL.vy-GRAV*dt);
 if(PL.vy>0){PR.set(new T.Vector3(PL.pos.x,PL.pos.y+CH,PL.pos.z),new T.Vector3(0,1,0));PR.far=PL.vy*dt+.3;if(PR.intersectObjects(PL.cols,false).length)PL.vy=0}
 let ny=PL.pos.y+PL.vy*dt;PR.set(new T.Vector3(PL.pos.x,PL.pos.y+STEP,PL.pos.z),new T.Vector3(0,-1,0));PR.far=STEP+Math.max(.6,-PL.vy*dt)+.3;
 const h=PR.intersectObjects(PL.cols,false)[0],gy=h?h.point.y:-1e9;
 if(PL.vy<=0&&gy>-1e8&&(ny<=gy+.02||(PL.ground&&PL.pos.y-gy<=.7))){ny=gy;PL.vy=0;PL.ground=true}else PL.ground=false;
 if(PL.ground&&(k[' ']||PL.jump)){PL.vy=JUMP;PL.ground=false;PL.jump=false}
 PL.pos.y=ny;if(PL.pos.y<-120){PL.pos.copy(PL.spawn);PL.vy=0}
 PL.t+=dt*(mv?10:0);const sw=mv?Math.sin(PL.t)*.8:0;PL.legs[0].rotation.x=sw;PL.legs[1].rotation.x=-sw;PL.arms[0].rotation.x=-sw;PL.arms[1].rotation.x=sw;if(!PL.ground){PL.arms[0].rotation.x=PL.arms[1].rotation.x=-2.4}
 PL.grp.position.copy(PL.pos);PL.grp.rotation.y=PL.face;
 tg.lerp(new T.Vector3(PL.pos.x,PL.pos.y+3.4,PL.pos.z),1-Math.exp(-dt*12));rad=Math.max(6,Math.min(45,rad));upCam()}
$('playb').onclick=startPlay;$('ps').onclick=stopPlay;
const jz=$('jz'),jk=$('jk');let jid=null;
function joy(e){const r=jz.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,m=r.width/2*.7;let dx=e.clientX-cx,dy=e.clientY-cy;const l=Math.hypot(dx,dy);if(l>m){dx*=m/l;dy*=m/l}jk.style.transform='translate(calc(-50% + '+dx+'px),calc(-50% + '+dy+'px))';PL.jx=dx/m;PL.jy=-dy/m}
jz.addEventListener('pointerdown',e=>{e.preventDefault();jid=e.pointerId;jz.setPointerCapture(jid);joy(e)});
jz.addEventListener('pointermove',e=>{if(e.pointerId==jid)joy(e)});
['pointerup','pointercancel'].forEach(v=>jz.addEventListener(v,e=>{if(e.pointerId==jid){jid=null;PL.jx=PL.jy=0;jk.style.transform='translate(-50%,-50%)'}}));
$('jb').addEventListener('pointerdown',e=>{e.preventDefault();PL.jump=true});
const dr=new Map();let pd=0;
vp.addEventListener('pointerdown',e=>{if(!PL.on||e.target!==cv)return;e.stopPropagation();cv.setPointerCapture(e.pointerId);dr.set(e.pointerId,{x:e.clientX,y:e.clientY});if(dr.size==2){const a=[...dr.values()];pd=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)||1}},true);
vp.addEventListener('pointermove',e=>{if(!PL.on||!dr.has(e.pointerId))return;e.stopPropagation();const p=dr.get(e.pointerId),dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
 if(dr.size==1){th-=dx*.006;ph=Math.max(.05,Math.min(1.45,ph+dy*.006))}else if(dr.size==2){const a=[...dr.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y)||1;rad=Math.max(6,Math.min(45,rad*pd/d));pd=d}},true);
['pointerup','pointercancel'].forEach(v=>vp.addEventListener(v,e=>{if(dr.has(e.pointerId)){dr.delete(e.pointerId);if(PL.on)e.stopPropagation()}},true));
addEventListener('keydown',e=>{if(!PL.on||/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;const k=e.key.toLowerCase();PL.keys[k]=true;if(k==' '||k.startsWith('arrow'))e.preventDefault();if(k=='escape')stopPlay()},true);
addEventListener('keyup',e=>{delete PL.keys[e.key.toLowerCase()]},true);

/* ---------------- Labels, per-map state, boot ---------------- */
renderBox=function(){renderToolbox();renderLight();renderSnd();renderOut();const a=$('ps');if(a)a.querySelector('span').textContent=L('Stop');const j=$('jb');if(j)j.querySelector('span').textContent=L('Jump')};
const _loadMap=loadMap;loadMap=function(id){_loadMap(id);try{loadMapState()}catch(e){}};
function loadMapState(){const s=ls.g('ms_lt:'+MP.cur,null);LT=s?mg(clone(DEF),s):clone(DEF);SND=ls.g('ms_snd:'+MP.cur,[]);applyLight();renderLight();renderSnd();sync()}
loadMapState();applyLang();
window.MapStudioV9={addModel,genTerrain,sakuraMap,startPlay,stopPlay,get LT(){return LT},get PL(){return PL},log};
log('Map Studio v9 ready','i');
})();
