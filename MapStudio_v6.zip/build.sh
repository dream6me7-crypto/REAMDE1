#!/bin/bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
echo "sdk.dir=$HOME/android" > local.properties
~/gradle-8.7/bin/gradle assembleDebug --no-daemon && echo "DONE: app/build/outputs/apk/debug/app-debug.apk"
